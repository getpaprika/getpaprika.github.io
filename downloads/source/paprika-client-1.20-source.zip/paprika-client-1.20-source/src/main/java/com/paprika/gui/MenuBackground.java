package com.paprika.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.renderer.PanoramaRenderer;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.resources.ResourceLocation;

public final class MenuBackground {
    public static final PanoramaRenderer PANORAMA = new PanoramaRenderer(TitleScreen.CUBE_MAP);
    private static final ResourceLocation BLUR = new ResourceLocation("paprika", "shaders/post/menu_blur.json");

    private static PostChain blur;
    private static boolean blurBroken;
    private static int blurW, blurH;
    private static boolean drawnThisFrame;

    private MenuBackground() {}

    public static void panorama(float delta) {
        PANORAMA.render(delta, 1.0F);
    }

    public static void newFrame() {
        drawnThisFrame = false;
    }

    public static void ensure(GuiGraphics g) {
        if (drawnThisFrame) return;
        Minecraft mc = Minecraft.getInstance();
        render(g, mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight());
    }

    public static void render(GuiGraphics g, int width, int height) {
        drawnThisFrame = true;
        Minecraft mc = Minecraft.getInstance();
        panorama(mc.getDeltaFrameTime());
        g.flush();
        blur(mc);
        g.fill(0, 0, width, height, 0x40000000);
    }

    private static void blur(Minecraft mc) {
        if (blurBroken) return;
        try {
            int w = mc.getWindow().getWidth(), h = mc.getWindow().getHeight();
            if (blur == null) {
                blur = new PostChain(mc.getTextureManager(), mc.getResourceManager(), mc.getMainRenderTarget(), BLUR);
                blurW = -1;
            }
            if (w != blurW || h != blurH) {
                blur.resize(w, h);
                blurW = w;
                blurH = h;
            }
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            blur.process(mc.getFrameTime());
            mc.getMainRenderTarget().bindWrite(false);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
        } catch (Exception e) {
            blurBroken = true;
            if (blur != null) blur.close();
            blur = null;
            mc.getMainRenderTarget().bindWrite(false);
        }
    }
}
