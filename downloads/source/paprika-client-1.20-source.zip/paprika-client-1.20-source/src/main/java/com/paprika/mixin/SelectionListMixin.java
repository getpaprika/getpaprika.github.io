package com.paprika.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSelectionList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractSelectionList.class)
public abstract class SelectionListMixin {
    @Shadow protected int x0;
    @Shadow protected int x1;
    @Shadow protected int y0;
    @Shadow protected int y1;

    @Shadow public abstract void setRenderBackground(boolean renderBackground);

    @Shadow public abstract void setRenderTopAndBottom(boolean renderTopAndBottom);

    @Inject(method = "render", at = @At("HEAD"))
    private void paprika$noDirt(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (Minecraft.getInstance().level != null) return;
        setRenderBackground(false);
        setRenderTopAndBottom(false);
        com.paprika.gui.MenuBackground.ensure(g);
        g.fill(x0, y0, x1, y1, 0x60000000);
        g.fill(x0, y0, x1, y0 + 1, 0x40FFFFFF);
        g.fill(x0, y1 - 1, x1, y1, 0x40FFFFFF);
    }
}
