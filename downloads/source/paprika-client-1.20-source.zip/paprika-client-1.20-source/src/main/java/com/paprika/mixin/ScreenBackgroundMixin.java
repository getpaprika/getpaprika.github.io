package com.paprika.mixin;

import com.paprika.gui.MenuBackground;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class ScreenBackgroundMixin {
    @Shadow public int width;
    @Shadow public int height;

    @Inject(method = "renderDirtBackground", at = @At("HEAD"), cancellable = true)
    private void paprika$noDirt(GuiGraphics g, CallbackInfo ci) {
        if (Minecraft.getInstance().level != null) return;
        MenuBackground.render(g, width, height);
        ci.cancel();
    }
}
