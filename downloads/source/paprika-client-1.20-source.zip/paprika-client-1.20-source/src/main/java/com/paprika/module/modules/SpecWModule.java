package com.paprika.module.modules;

import com.mojang.blaze3d.systems.RenderSystem;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.level.GameType;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class SpecWModule extends Module {
    private static final int ANIM_TICKS = 40;

    private static final int FADE_IN = 5, STAY = 50, FADE_OUT = 10;
    private static final int TITLE_TICKS = FADE_IN + STAY + FADE_OUT;

    private final Set<UUID> known = new HashSet<>();
    private final Deque<Alert> queue = new ArrayDeque<>();
    private ClientPacketListener lastConnection;

    private Alert current;
    private int age;
    private int redTitleTicks;
    private int yellowTitleTicks;

    private record Alert(String name, ResourceLocation skin) {}

    public SpecWModule() {
        super("SpecW", "Warns you when someone is in spectator mode", Category.UTILITY);
    }

    @Override
    protected void onDisable() {
        known.clear();
        queue.clear();
        current = null;
        lastConnection = null;
        redTitleTicks = 0;
        yellowTitleTicks = 0;
    }

    @Override
    public void onTick() {
        ClientPacketListener connection = mc.getConnection();
        if (mc.player == null || connection == null) {
            known.clear();
            return;
        }

        if (connection != lastConnection) {
            known.clear();
            queue.clear();
            current = null;
            lastConnection = connection;
            redTitleTicks = 0;
            yellowTitleTicks = 0;
        }

        Set<UUID> spectatorsNow = new HashSet<>();
        for (PlayerInfo info : connection.getOnlinePlayers()) {
            UUID id = info.getProfile().getId();
            if (id.equals(mc.player.getUUID())) continue;
            if (info.getGameMode() != GameType.SPECTATOR) continue;
            spectatorsNow.add(id);
            if (!known.contains(id)) {
                queue.add(new Alert(info.getProfile().getName(), info.getSkinLocation()));
            }
        }

        for (UUID id : known) {
            if (spectatorsNow.contains(id)) continue;
            PlayerInfo info = connection.getPlayerInfo(id);
            if (info == null || info.getGameMode() == null) continue;
            mc.player.displayClientMessage(Component.literal("[SpecW] ").withStyle(ChatFormatting.RED)
                    .append(Component.literal(info.getProfile().getName() + " has changed back into "
                            + info.getGameMode().getName() + "...").withStyle(ChatFormatting.WHITE)), false);
        }

        known.clear();
        known.addAll(spectatorsNow);

        if (redTitleTicks > 0 && --redTitleTicks == 0) {
            showWatchOut();
            yellowTitleTicks = TITLE_TICKS;
        } else if (yellowTitleTicks > 0) {
            yellowTitleTicks--;
        }

        if (current != null) {
            age++;
            if (age >= ANIM_TICKS) {
                showText(current);
                current = null;
            }
        }
        if (current == null && redTitleTicks == 0 && yellowTitleTicks == 0 && !queue.isEmpty()) {
            current = queue.poll();
            age = 0;
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.ELDER_GUARDIAN_CURSE, 1.0F));
        }
    }

    private void showText(Alert alert) {
        mc.gui.setTimes(FADE_IN, STAY, FADE_OUT);
        mc.gui.setSubtitle(Component.literal("is spectating").withStyle(ChatFormatting.RED));
        mc.gui.setTitle(Component.literal(alert.name())
                .withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
        redTitleTicks = TITLE_TICKS;
    }

    private void showWatchOut() {
        mc.gui.setTimes(FADE_IN, STAY, FADE_OUT);
        mc.gui.setSubtitle(Component.empty());
        mc.gui.setTitle(Component.literal("Watch out...").withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD));
    }

    @Override
    public int onRender(GuiGraphics graphics, int x, int y) {
        if (current == null) return 0;

        float t = Mth.clamp((age + mc.getFrameTime()) / ANIM_TICKS, 0F, 1F);

        float alpha = Mth.sin(t * (float) Math.PI);

        int size = (int) Mth.lerp(t, 80, 220);

        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        int hx = (w - size) / 2;
        int hy = (h - size) / 2;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.setColor(1F, 1F, 1F, alpha * 0.8F);
        PlayerFaceRenderer.draw(graphics, current.skin(), hx, hy, size);
        graphics.setColor(1F, 1F, 1F, 1F);
        RenderSystem.disableBlend();
        return 0;
    }
}
