package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class PotionHudModule extends Module {
    public PotionHudModule() {
        super("PotionHUD", "Shows your potion effects and how long they last", Category.RENDER);
    }

    @Override
    public int onRender(GuiGraphics g, int x, int y) {
        if (mc.player == null) return 0;
        List<MobEffectInstance> effects = new ArrayList<>(mc.player.getActiveEffects());
        if (effects.isEmpty()) return 0;
        effects.sort(Comparator.comparingInt(MobEffectInstance::getDuration).reversed());

        int line = mc.font.lineHeight + 2;
        int h = 0;
        for (MobEffectInstance inst : effects) {
            MobEffect effect = inst.getEffect();
            String name = Component.translatable(effect.getDescriptionId()).getString();
            if (inst.getAmplifier() > 0) {
                name += " " + Component.translatable("enchantment.level." + (inst.getAmplifier() + 1)).getString();
            }
            String time;
            if (inst.isInfiniteDuration()) {
                time = "\u221e";
            } else {
                int seconds = inst.getDuration() / 20;
                time = (seconds / 60) + ":" + String.format("%02d", seconds % 60);
            }
            g.drawString(mc.font, name + " " + time, x, y + h, 0xFF000000 | effect.getColor(), true);
            h += line;
        }
        return h;
    }

    @Override
    public int onRenderPreview(GuiGraphics g, int x, int y) {
        if (mc.player != null && !mc.player.getActiveEffects().isEmpty()) return onRender(g, x, y);
        int line = mc.font.lineHeight + 2;
        g.drawString(mc.font, "Speed II 1:30", x, y, 0xFF33EBFF, true);
        g.drawString(mc.font, "Strength 0:45", x, y + line, 0xFFFFC700, true);
        return line * 2;
    }
}
