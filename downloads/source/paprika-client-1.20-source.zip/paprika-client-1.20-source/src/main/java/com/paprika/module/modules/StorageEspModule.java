package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.setting.BoolSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.world.Container;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.level.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class StorageEspModule extends Module {
    private static final int SCAN_EVERY_TICKS = 10;
    private static final int MAX_SHOWN = 1000;

    public static final int CHEST_COLOR = 0xFFFFAA00;
    public static final int ENDER_COLOR = 0xFFB040FF;
    public static final int SHULKER_COLOR = 0xFFFF55FF;
    public static final int OTHER_COLOR = 0xFFAAAAAA;

    public final BoolSetting tracers = bool("Tracers", "Also draw a line to every storage block", true);

    public record Storage(BlockPos pos, AABB box, int color) {}

    private List<Storage> shown = List.of();
    private int timer;

    public StorageEspModule() {
        super("StorageESP", "Boxes and tracers to every block that holds items (chests, barrels, shulkers, hoppers...)", Category.RENDER);
    }

    public List<Storage> shown() {
        return shown;
    }

    @Override
    protected void onDisable() {
        shown = List.of();
    }

    public static boolean holdsItems(BlockEntity be) {
        return be instanceof Container || be instanceof EnderChestBlockEntity;
    }

    private static int colorOf(BlockEntity be) {
        if (be instanceof ShulkerBoxBlockEntity) return SHULKER_COLOR;
        if (be instanceof EnderChestBlockEntity) return ENDER_COLOR;
        if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) return CHEST_COLOR;
        return OTHER_COLOR;
    }

    @Override
    public void onTick() {
        if (mc.level == null || mc.player == null) {
            shown = List.of();
            return;
        }
        if (timer-- > 0) return;
        timer = SCAN_EVERY_TICKS;
        int radius = mc.options.getEffectiveRenderDistance() + 1;
        ChunkPos center = mc.player.chunkPosition();
        List<Storage> list = new ArrayList<>();
        for (int cx = center.x - radius; cx <= center.x + radius; cx++) {
            for (int cz = center.z - radius; cz <= center.z + radius; cz++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (!holdsItems(be)) continue;
                    BlockPos p = be.getBlockPos();
                    BlockState state = mc.level.getBlockState(p);
                    VoxelShape shape = state.getShape(mc.level, p);
                    AABB box = shape.isEmpty() ? new AABB(p) : shape.bounds().move(p);
                    list.add(new Storage(p, box, colorOf(be)));
                }
            }
        }
        net.minecraft.world.phys.Vec3 me = mc.player.position();
        list.sort(Comparator.comparingDouble(s -> s.box().getCenter().distanceToSqr(me)));
        shown = list.size() > MAX_SHOWN ? new ArrayList<>(list.subList(0, MAX_SHOWN)) : list;
    }
}
