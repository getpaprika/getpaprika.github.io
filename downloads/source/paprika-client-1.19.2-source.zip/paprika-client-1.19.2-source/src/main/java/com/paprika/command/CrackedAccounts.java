package com.paprika.command;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.paprika.mixin.MinecraftUserAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import net.minecraft.client.multiplayer.ProfileKeyPairManager;
import net.minecraft.core.UUIDUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

public final class CrackedAccounts {
    private static final List<String> NAMES = new ArrayList<>();
    private static String active;
    private static User original;
    private static ProfileKeyPairManager originalKeys;

    private CrackedAccounts() {}

    public static List<String> all() { return new ArrayList<>(NAMES); }

    public static String active() { return active; }

    public static boolean validName(String name) {
        return name.matches("[A-Za-z0-9_]{3,16}");
    }

    public static boolean add(String name) {
        for (String n : NAMES) if (n.equalsIgnoreCase(name)) return false;
        NAMES.add(name);
        return true;
    }

    public static void remove(String name) {
        if (name.equals(active)) exit();
        NAMES.remove(name);
    }

    public static void use(String name) {
        Minecraft mc = Minecraft.getInstance();
        if (original == null) {
            original = mc.getUser();
            originalKeys = mc.getProfileKeyPairManager();
        }
        UUID uuid = UUIDUtil.createOfflinePlayerUUID(name);
        ((MinecraftUserAccessor) mc).paprika$setUser(new User(name, uuid.toString().replace("-", ""), "0", Optional.empty(), Optional.empty(), User.Type.LEGACY));

        active = name;
    }

    public static void exit() {
        if (original != null) {
            Minecraft mc = Minecraft.getInstance();
            ((MinecraftUserAccessor) mc).paprika$setUser(original);
            ((MinecraftUserAccessor) mc).paprika$setKeys(originalKeys);
        }
        active = null;
    }

    public static JsonArray save() {
        JsonArray arr = new JsonArray();
        for (String n : NAMES) arr.add(n);
        return arr;
    }

    public static void load(JsonArray arr) {
        NAMES.clear();
        for (JsonElement e : arr) {
            String n = e.getAsString();
            if (validName(n) && NAMES.stream().noneMatch(x -> x.toLowerCase(Locale.ROOT).equals(n.toLowerCase(Locale.ROOT)))) NAMES.add(n);
        }
    }
}
