package com.paprika.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.paprika.module.ModuleManager;
import com.paprika.module.modules.TNTCountdownModule;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.phys.Vec3;
import com.mojang.math.Matrix4f;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class TntTimerRenderer {
    private static final float SCALE = 0.03F;

    private static final Map<Integer, Integer> START_FUSE = new HashMap<>();

    private TntTimerRenderer() {}

    public static void clear() {
        START_FUSE.clear();
    }

    public static void render(WorldRenderContext ctx) {
        if (!ModuleManager.isOn(TNTCountdownModule.class)) return;
        double maxDistance = ModuleManager.get(TNTCountdownModule.class).maxDistance.get();
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        float pt = ctx.tickDelta();
        Vec3 cam = ctx.camera().getPosition();
        PoseStack pose = ctx.matrixStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        Font font = mc.font;
        boolean any = false;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof PrimedTnt tnt) || !tnt.isAlive()) continue;
            if (tnt.distanceToSqr(cam) > maxDistance * maxDistance) continue;

            int fuse = tnt.getFuse();
            int start = START_FUSE.computeIfAbsent(tnt.getId(), id -> Math.max(fuse, 1));

            double seconds = Math.max(0.0, (fuse - pt) / 20.0);
            String text = String.format(Locale.ROOT, "%.2fs", seconds);

            float ratio = Mth.clamp((float) ((fuse - pt) / start), 0.0F, 1.0F);
            int color = 0xFF000000 | Mth.hsvToRgb(ratio / 3.0F, 1.0F, 1.0F);

            double x = Mth.lerp(pt, tnt.xOld, tnt.getX()) - cam.x;
            double y = Mth.lerp(pt, tnt.yOld, tnt.getY()) - cam.y + tnt.getBbHeight() + 0.5;
            double z = Mth.lerp(pt, tnt.zOld, tnt.getZ()) - cam.z;

            pose.pushPose();
            pose.translate(x, y, z);
            pose.mulPose(ctx.camera().rotation());
            pose.scale(-SCALE, -SCALE, SCALE);
            Matrix4f matrix = pose.last().pose();
            float tx = -font.width(text) / 2.0F;
            font.drawInBatch(text, tx, 0, color, false, matrix, buffers,
                    false, 0x40000000, LightTexture.FULL_BRIGHT);
            pose.popPose();
            any = true;
        }

        if (any) buffers.endBatch();

        if (START_FUSE.size() > 256 || (!any && !START_FUSE.isEmpty())) {
            START_FUSE.keySet().removeIf(id -> !(mc.level.getEntity(id) instanceof PrimedTnt));
        }
    }
}
