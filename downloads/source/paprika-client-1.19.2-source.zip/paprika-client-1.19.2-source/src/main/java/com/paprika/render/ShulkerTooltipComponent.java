package com.paprika.render;

import net.minecraft.client.gui.Font;
import com.paprika.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.item.ItemStack;

public class ShulkerTooltipComponent implements ClientTooltipComponent {
    private static final int SLOT = 18;
    private static final int SLOT_BG = 0x80000000;
    private static final int SLOT_BORDER = 0x40FFFFFF;

    private final ShulkerTooltipData data;

    public ShulkerTooltipComponent(ShulkerTooltipData data) {
        this.data = data;
    }

    @Override
    public int getHeight() {
        return SLOT * 3 + 4;
    }

    @Override
    public int getWidth(Font font) {
        return SLOT * 9;
    }

    @Override
    public void renderImage(Font font, int x, int y, com.mojang.blaze3d.vertex.PoseStack paprika$ps, net.minecraft.client.renderer.entity.ItemRenderer paprika$items, int paprika$z) {
        com.paprika.gui.GuiGraphics g = new com.paprika.gui.GuiGraphics(paprika$ps);
        for (int i = 0; i < 27; i++) {
            int sx = x + (i % 9) * SLOT;
            int sy = y + (i / 9) * SLOT;
            g.fill(sx, sy, sx + SLOT, sy + SLOT, SLOT_BORDER);
            g.fill(sx + 1, sy + 1, sx + SLOT - 1, sy + SLOT - 1, SLOT_BG);

            ItemStack stack = data.items().get(i);
            if (!stack.isEmpty()) {
                g.renderItem(stack, sx + 1, sy + 1);
                g.renderItemDecorations(font, stack, sx + 1, sy + 1);
            }
        }
    }
}
