package com.paprika.util;

import net.minecraft.client.Minecraft;

public final class Fps {
    private Fps() {}

    public static int get() {
        String s = Minecraft.getInstance().fpsString;
        int space = s.indexOf(' ');
        try {
            return Integer.parseInt(space > 0 ? s.substring(0, space) : s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
