package com.paprika.gui;

import com.mojang.blaze3d.platform.InputConstants;
import com.paprika.Config;
import com.paprika.PaprikaClient;
import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClickGuiScreen extends Screen {
    private static final int PANEL_BG  = 0x66000000;
    private static final int TAB_BG    = 0x40FFFFFF;
    private static final int TAB_HOVER = 0x60FFFFFF;
    private static final int KEY_BG    = 0x60000000;
    private static final int WHITE     = 0xFFFFFFFF;
    private static final int GRAY      = 0xFF888888;

    private static final int GAP = 6;
    private static final int PANEL_W = 420;
    private static final int PANEL_H = 220;
    private static final int HEADER_H = 22;
    private static final int TAB_H = 16;
    private static final int COLUMNS = 3;
    private static final int MOD_W = (PANEL_W - GAP * 4 - GAP * (COLUMNS - 1)) / COLUMNS;
    private static final int MOD_H = 20;
    private static final int FOOTER_H = 18;
    private static final int KEY_H = 12;
    private static final int KEY_W = 32;

    private static int selectedTab = Category.UTILITY.ordinal();

    private static ItemStack redDye;

    private static ItemStack redDye() {
        if (redDye == null) {
            try {
                redDye = new ItemStack(Items.RED_DYE);
            } catch (RuntimeException e) {
                return ItemStack.EMPTY;
            }
        }
        return redDye;
    }

    private int px, py;
    private int scroll;
    private EditBox search;
    private Module listening;
    private final KeyCapture capture = new KeyCapture();

    public ClickGuiScreen() {
        super(Component.literal(PaprikaClient.NAME));
    }

    private static int tabCount() {
        return Category.values().length + 3;
    }

    private static boolean configsTab() {
        return selectedTab == Category.values().length + 1;
    }

    private static boolean configTab() {
        return selectedTab == Category.values().length;
    }

    private static boolean themesTab() {
        return selectedTab == Category.values().length + 2;
    }

    private static String tabName(int i) {
        int n = Category.values().length;
        return i < n ? Category.values()[i].displayName : i == n ? "Config" : i == n + 1 ? "Presets" : "Themes";
    }

    @Override
    protected void init() {
        px = (width - PANEL_W) / 2;
        py = (height - PANEL_H) / 2;
        String old = search == null ? "" : search.getValue();
        search = new EditBox(font, px + PANEL_W - 126, py + 5, 120, 12, Component.literal("Search"));
        search.setMaxLength(32);
        search.setValue(old);
        search.setSuggestion(search.getValue().isEmpty() ? "Search..." : "");
        search.setResponder(text -> { scroll = 0; search.setSuggestion(text.isEmpty() ? "Search..." : ""); });
        addRenderableWidget(search);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(com.mojang.blaze3d.vertex.PoseStack paprika$ps) {
        GuiGraphics graphics = new GuiGraphics(paprika$ps);
    }

    private boolean searching() {
        return search != null && !search.getValue().isBlank();
    }

    private List<Module> shownModules() {
        if (searching()) {
            String q = search.getValue().trim().toLowerCase(Locale.ROOT);
            List<Module> list = new ArrayList<>();
            for (Module m : ModuleManager.getModules()) {
                if (m.getName().toLowerCase(Locale.ROOT).contains(q)) list.add(m);
            }
            return list;
        }
        if (themesTab() || configTab() || configsTab()) return List.of();
        return ModuleManager.getByCategory(Category.values()[selectedTab]);
    }

    private int itemCount() {
        if (!searching() && configTab()) return GlobalToggles.all().size();
        if (!searching() && configsTab()) return com.paprika.ConfigProfiles.list().size() + COLUMNS;
        return (!searching() && themesTab()) ? Theme.ALL.size() : shownModules().size();
    }

    @Override
    public void render(com.mojang.blaze3d.vertex.PoseStack paprika$ps, int mouseX, int mouseY, float partialTick) {
        GuiGraphics g = new GuiGraphics(paprika$ps);
        Theme theme = Theme.current();

        g.fill(px, py, px + PANEL_W, py + PANEL_H, PANEL_BG);
        outline(g, px, py, PANEL_W, PANEL_H, theme.accentArgb(0x88));
        g.renderItem(redDye(), px + 4, py + 3);
        g.drawString(font, PaprikaClient.NAME, px + 22, py + 7, theme.accentArgb(0xFF), true);
        g.fill(px, py + HEADER_H, px + PANEL_W, py + HEADER_H + 1, theme.accentArgb(0x88));

        int tabW = (PANEL_W - GAP * (tabCount() + 1)) / tabCount();
        int tabY = py + HEADER_H + GAP;
        for (int i = 0; i < tabCount(); i++) {
            int tx = px + GAP + i * (tabW + GAP);
            boolean hover = inside(mouseX, mouseY, tx, tabY, tabW, TAB_H);
            boolean selected = i == selectedTab && !searching();
            g.fill(tx, tabY, tx + tabW, tabY + TAB_H, selected ? theme.accentArgb(0x90) : hover ? TAB_HOVER : TAB_BG);
            drawFitted(g, tabName(i), tx + tabW / 2, tabY + TAB_H / 2, tabW - 4);
        }

        int startY = listTop();
        int listBottom = py + PANEL_H - FOOTER_H;
        clampScroll();
        String tooltip = null;

        g.enableScissor(px + 1, startY - 2, px + PANEL_W - 1, listBottom);
        if (!searching() && themesTab()) {
            for (int i = 0; i < Theme.ALL.size(); i++) {
                Theme t = Theme.ALL.get(i);
                int mx = itemX(i), my = itemY(i);
                boolean hover = inList(mouseX, mouseY) && inside(mouseX, mouseY, mx, my, MOD_W, MOD_H);
                g.fill(mx, my, mx + MOD_W, my + MOD_H, t.offArgb(hover));
                if (t == theme) outline(g, mx, my, MOD_W, MOD_H, t.accentArgb(0xFF));
                g.drawString(font, (t == theme ? "✔ " : "") + t.name(), mx + 6, my + 6, WHITE, true);

                int sx = mx + MOD_W - 38;
                g.fill(sx, my + 6, sx + 8, my + 14, t.accentArgb(0xFF));
                g.fill(sx + 10, my + 6, sx + 18, my + 14, 0xFF000000 | t.off());
                g.fill(sx + 20, my + 6, sx + 28, my + 14, 0xFF000000 | t.on());
            }

            int sy = styleTop();
            g.fill(px + GAP * 2, sy, px + PANEL_W - GAP * 2, sy + 1, theme.accentArgb(0x90));
            g.drawCenteredString(font, "Style", px + PANEL_W / 2, sy + 5, theme.accentArgb(0xFF));
            String[] styles = {"Menu", "List"};
            for (int i = 0; i < 2; i++) {
                int bx = itemX(i), by = sy + 17;
                boolean selected = (i == 1) == GuiStyle.list;
                boolean hover = inList(mouseX, mouseY) && inside(mouseX, mouseY, bx, by, MOD_W, MOD_H);
                g.fill(bx, by, bx + MOD_W, by + MOD_H, theme.offArgb(hover));
                if (selected) outline(g, bx, by, MOD_W, MOD_H, theme.accentArgb(0xFF));
                g.drawString(font, (selected ? "✔ " : "") + styles[i], bx + 6, by + 6, WHITE, true);
                if (hover) tooltip = i == 0 ? "This menu, with tabs" : "Every tab as a column, like other clients";
            }
        } else if (!searching() && configsTab()) {
            int nx = itemX(0), ny = itemY(0), nw = MOD_W * COLUMNS + GAP * (COLUMNS - 1);
            boolean overNew = inList(mouseX, mouseY) && inside(mouseX, mouseY, nx, ny, nw, MOD_H);
            g.fill(nx, ny, nx + nw, ny + MOD_H, theme.onArgb(overNew));
            g.drawCenteredString(font, "+ New preset", nx + nw / 2, ny + 6, WHITE);
            List<String> configs = com.paprika.ConfigProfiles.list();
            String active = com.paprika.ConfigProfiles.active();
            if (configs.isEmpty()) {
                g.drawCenteredString(font, "No presets yet. Save one with New preset.", px + PANEL_W / 2, itemY(COLUMNS) + 6, 0xFFAAAAAA);
            }
            for (int i = 0; i < configs.size(); i++) {
                String name = configs.get(i);
                int mx = itemX(i + COLUMNS), my = itemY(i + COLUMNS);
                boolean overTrash = inList(mouseX, mouseY) && inside(mouseX, mouseY, mx + MOD_W - 16, my + 4, 12, 12);
                boolean hover = inList(mouseX, mouseY) && inside(mouseX, mouseY, mx, my, MOD_W, MOD_H) && !overTrash;
                boolean inUse = name.equals(active);
                g.fill(mx, my, mx + MOD_W, my + MOD_H, inUse ? theme.onArgb(hover) : theme.offArgb(hover));
                drawFitted(g, name, mx + (MOD_W - 16) / 2, my + MOD_H / 2, MOD_W - 24);
                Ui.trash(g, mx + MOD_W - 16, my + 4, overTrash);
                if (hover) tooltip = inUse ? name + " is in use" : "Click to use " + name;
                if (overTrash) tooltip = "Delete " + name;
            }
        } else if (!searching() && configTab()) {
            List<GlobalToggles.Toggle> toggles = GlobalToggles.all();
            for (int i = 0; i < toggles.size(); i++) {
                GlobalToggles.Toggle t = toggles.get(i);
                int mx = itemX(i), my = itemY(i);
                boolean hover = inList(mouseX, mouseY) && inside(mouseX, mouseY, mx, my, MOD_W, MOD_H);
                boolean on = t.get().getAsBoolean();
                g.fill(mx, my, mx + MOD_W, my + MOD_H, on ? theme.onArgb(hover) : theme.offArgb(hover));
                drawFitted(g, t.name(), mx + MOD_W / 2, my + MOD_H / 2, MOD_W - 8);
                if (hover) tooltip = t.desc() + (on ? "  (ON)" : "  (OFF)");
            }
        } else {
            List<Module> mods = shownModules();
            if (mods.isEmpty()) {
                g.drawCenteredString(font, searching() ? "No mods found" : "No mods in this tab yet",
                        px + PANEL_W / 2, startY + 6, 0xFFAAAAAA);
            }
            for (int i = 0; i < mods.size(); i++) {
                Module m = mods.get(i);
                int mx = itemX(i), my = itemY(i);
                boolean inList = inList(mouseX, mouseY);
                String key = keyLabel(m);
                int keyW = keyWidth(key);
                int kx = mx + MOD_W - keyW - 4, ky = my + (MOD_H - KEY_H) / 2;
                boolean overKey = inList && inside(mouseX, mouseY, kx, ky, keyW, KEY_H);

                boolean pencil = m.hasSettings();
                int ex = kx - KEY_H - 2;
                boolean overPencil = pencil && inList && inside(mouseX, mouseY, ex, ky, KEY_H, KEY_H);
                boolean hover = inList && inside(mouseX, mouseY, mx, my, MOD_W, MOD_H) && !overKey && !overPencil;

                g.fill(mx, my, mx + MOD_W, my + MOD_H, m.isEnabled() ? theme.onArgb(hover) : theme.offArgb(hover));
                int nameSpace = MOD_W - keyW - 4 - (pencil ? KEY_H + 2 : 0);
                drawFitted(g, m.getName(), mx + nameSpace / 2, my + MOD_H / 2, nameSpace - 6);

                if (pencil) {
                    g.fill(ex, ky, ex + KEY_H, ky + KEY_H, KEY_BG);
                    outline(g, ex, ky, KEY_H, KEY_H, overPencil ? theme.accentArgb(0xFF) : 0x80FFFFFF);
                    drawPencil(g, ex, ky);
                    if (overPencil) tooltip = "Settings for " + m.getName();
                }

                g.fill(kx, ky, kx + keyW, ky + KEY_H, KEY_BG);
                outline(g, kx, ky, keyW, KEY_H, overKey || m == listening ? theme.accentArgb(0xFF) : 0x80FFFFFF);
                if (!key.isEmpty()) drawFitted(g, key, kx + keyW / 2, ky + KEY_H / 2 + 1, keyW - 4);

                if (overPencil) {
                } else if (overKey) {
                    tooltip = m == listening ? "Hold the keys (e.g. Shift + R), let go to set it  |  ESC = none"
                            : m.getKeybind() == -1 ? "Click, then press a key (or Shift/Ctrl/Alt + a key) to bind " + m.getName()
                            : KeyCapture.name(m.getKeybind()) + " - click to change it";
                } else if (hover) {
                    tooltip = m.getDescription();
                }
            }
        }
        g.disableScissor();

        if (maxScroll() > 0) g.drawString(font, "↕", px + PANEL_W - 136, py + 7, GRAY, false);

        String footer = listening != null ? "Hold the keys for " + listening.getName() + ", let go to set  |  ESC = none"
                : (!searching() && themesTab()) ? "Click a theme to use it"
                : (!searching() && configTab()) ? "Click to turn on / off  (same colors as mods: on / off)"
                : (!searching() && configsTab()) ? "Click a preset to use it  |  trash = delete"
                : "Click a mod to toggle  |  pencil = settings  |  box = keybind  |  ESC to close";
        g.drawCenteredString(font, footer, px + PANEL_W / 2, py + PANEL_H - 12, GRAY);

        super.render(g.pose(), mouseX, mouseY, partialTick);

        if (tooltip != null) g.renderTooltip(font, Component.literal(tooltip), mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int tabW = (PANEL_W - GAP * (tabCount() + 1)) / tabCount();
            int tabY = py + HEADER_H + GAP;
            for (int i = 0; i < tabCount(); i++) {
                int tx = px + GAP + i * (tabW + GAP);
                if (inside(mouseX, mouseY, tx, tabY, tabW, TAB_H)) {
                    if (selectedTab != i) scroll = 0;
                    selectedTab = i;
                    search.setValue("");
                    search.setFocus(false);
                    listening = null;
                    click();
                    return true;
                }
            }

            if (inList(mouseX, mouseY)) {
                if (!searching() && themesTab()) {
                    for (int i = 0; i < Theme.ALL.size(); i++) {
                        if (inside(mouseX, mouseY, itemX(i), itemY(i), MOD_W, MOD_H)) {
                            Theme.set(Theme.ALL.get(i));
                            Config.save();
                            click();
                            return true;
                        }
                    }
                    int sy = styleTop() + 17;
                    if (inside(mouseX, mouseY, itemX(0), sy, MOD_W, MOD_H)) {
                        GuiStyle.list = false;
                        Config.save();
                        click();
                        return true;
                    }
                    if (inside(mouseX, mouseY, itemX(1), sy, MOD_W, MOD_H)) {
                        GuiStyle.list = true;
                        Config.save();
                        click();
                        minecraft.setScreen(new ListGuiScreen());
                        return true;
                    }
                } else if (!searching() && configsTab()) {
                    int nw = MOD_W * COLUMNS + GAP * (COLUMNS - 1);
                    if (inside(mouseX, mouseY, itemX(0), itemY(0), nw, MOD_H)) {
                        click();
                        minecraft.setScreen(new NewConfigScreen(this));
                        return true;
                    }
                    List<String> configs = com.paprika.ConfigProfiles.list();
                    for (int i = 0; i < configs.size(); i++) {
                        int mx = itemX(i + COLUMNS), my = itemY(i + COLUMNS);
                        if (inside(mouseX, mouseY, mx + MOD_W - 16, my + 4, 12, 12)) {
                            com.paprika.ConfigProfiles.delete(configs.get(i));
                            click();
                            return true;
                        }
                        if (inside(mouseX, mouseY, mx, my, MOD_W, MOD_H)) {
                            com.paprika.ConfigProfiles.load(configs.get(i));
                            click();
                            return true;
                        }
                    }
                } else if (!searching() && configTab()) {
                    List<GlobalToggles.Toggle> toggles = GlobalToggles.all();
                    for (int i = 0; i < toggles.size(); i++) {
                        if (inside(mouseX, mouseY, itemX(i), itemY(i), MOD_W, MOD_H)) {
                            toggles.get(i).flip().run();
                            Config.save();
                            click();
                            return true;
                        }
                    }
                } else {
                    List<Module> mods = shownModules();
                    for (int i = 0; i < mods.size(); i++) {
                        Module m = mods.get(i);
                        int mx = itemX(i), my = itemY(i);
                        int keyW = keyWidth(keyLabel(m));
                        int kx = mx + MOD_W - keyW - 4, ky = my + (MOD_H - KEY_H) / 2;
                        if (inside(mouseX, mouseY, kx, ky, keyW, KEY_H)) {
                            listening = listening == m ? null : m;
                            capture.reset();
                            search.setFocus(false);
                            click();
                            return true;
                        }
                        if (m.hasSettings() && inside(mouseX, mouseY, kx - KEY_H - 2, ky, KEY_H, KEY_H)) {
                            click();
                            minecraft.setScreen(new ModSettingsScreen(m, this));
                            return true;
                        }
                        if (inside(mouseX, mouseY, mx, my, MOD_W, MOD_H)) {
                            m.toggle();
                            Config.save();
                            click();
                            return true;
                        }
                    }
                }
            }
        }
        boolean handled = super.mouseClicked(mouseX, mouseY, button);
        if (!search.isMouseOver(mouseX, mouseY)) search.setFocus(false);
        return handled;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        scroll -= (int) (delta * (MOD_H + GAP));
        clampScroll();
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                listening.setKeybind(-1);
                listening = null;
                Config.save();
            } else {
                capture.press(keyCode);
            }
            return true;
        }

        if (search.isFocused()) {
            return super.keyPressed(keyCode, scanCode, modifiers);
        }
        if (PaprikaClient.menuKey.matches(keyCode, scanCode) || PaprikaClient.menuKey2.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            Integer bind = capture.release(keyCode);
            if (bind != null) {
                listening.setKeybind(bind);
                listening = null;
                Config.save();
            }
            return true;
        }
        return super.keyReleased(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char c, int modifiers) {
        if (!search.isFocused() && listening == null && Character.isLetterOrDigit(c)) {
            setFocused(search);
            search.setFocus(true);
            search.insertText(String.valueOf(c));
            return true;
        }
        return super.charTyped(c, modifiers);
    }

    private int listTop() {
        return py + HEADER_H + GAP + TAB_H + GAP * 2;
    }

    private boolean inList(double mouseX, double mouseY) {
        return mouseY >= listTop() - 2 && mouseY < py + PANEL_H - FOOTER_H;
    }

    private int itemX(int index) {
        return px + GAP * 2 + (index % COLUMNS) * (MOD_W + GAP);
    }

    private int itemY(int index) {
        return listTop() + (index / COLUMNS) * (MOD_H + GAP) - scroll;
    }

    private int styleTop() {
        int rows = (Theme.ALL.size() + COLUMNS - 1) / COLUMNS;
        return listTop() + rows * (MOD_H + GAP) - scroll;
    }

    private int maxScroll() {
        int rows = (itemCount() + COLUMNS - 1) / COLUMNS;
        int contentH = rows * (MOD_H + GAP) - GAP;
        if (!searching() && themesTab()) contentH += GAP + 17 + MOD_H;
        int visibleH = (py + PANEL_H - FOOTER_H) - listTop();
        return Math.max(0, contentH - visibleH);
    }

    private void clampScroll() {
        scroll = Math.max(0, Math.min(scroll, maxScroll()));
    }

    private String keyLabel(Module m) {
        if (m == listening) {
            Integer held = capture.current();
            if (held != null) return KeyCapture.name(held) + "...";
            return (System.currentTimeMillis() / 400) % 2 == 0 ? "..." : "";
        }
        if (m.getKeybind() == -1) return "";
        return keyName(m.getKeybind());
    }

    public static String keyName(int key) {
        return KeyCapture.name(key);
    }

    private void drawFitted(GuiGraphics g, String text, int cx, int cy, int maxW) {
        int w = font.width(text);
        float scale = w > maxW ? Math.max(0.5F, maxW / (float) w) : 1.0F;
        if (scale >= 1.0F) {
            g.drawCenteredString(font, text, cx, cy - 4, WHITE);
            return;
        }
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(scale, scale, 1.0F);
        g.drawString(font, text, -w / 2, -4, WHITE, true);
        g.pose().popPose();
    }

    private static void drawPencil(GuiGraphics g, int x, int y) {
        for (int k = 0; k < 5; k++) {
            g.fill(x + 3 + k, y + 7 - k, x + 5 + k, y + 9 - k, 0xFFBBBBBB);
        }
        g.fill(x + 2, y + 9, x + 4, y + 10, 0xFF777777);
        g.fill(x + 8, y + 2, x + 10, y + 4, 0xFF999999);
    }

    private int keyWidth(String label) {
        return KEY_W;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private void click() {
        if (minecraft != null) {
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
        }
    }
}
