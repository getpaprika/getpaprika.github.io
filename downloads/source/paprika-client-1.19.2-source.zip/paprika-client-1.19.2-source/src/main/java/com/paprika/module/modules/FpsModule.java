package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.gui.GuiGraphics;

public class FpsModule extends Module {
    public FpsModule() {
        super("FPS", "Shows your FPS on screen", Category.RENDER);
    }

    @Override
    public int onRender(GuiGraphics graphics, int x, int y) {
        graphics.drawString(mc.font, "FPS: " + com.paprika.util.Fps.get(), x, y, 0xFFFFFFFF, true);
        return mc.font.lineHeight + 2;
    }
}
