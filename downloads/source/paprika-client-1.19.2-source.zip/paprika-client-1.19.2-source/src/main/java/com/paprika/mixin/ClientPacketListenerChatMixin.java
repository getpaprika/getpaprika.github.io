package com.paprika.mixin;

import com.paprika.command.Commands;
import net.minecraft.client.gui.screens.ChatScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ChatScreen.class)
public abstract class ClientPacketListenerChatMixin {
    @Inject(method = "handleChatInput(Ljava/lang/String;Z)Z", at = @At("HEAD"), cancellable = true, require = 0)
    private void paprika$commands(String message, boolean addToHistory, CallbackInfoReturnable<Boolean> cir) {
        if (Commands.onChat(message)) cir.setReturnValue(true);
    }

    @Inject(method = "handleChatInput(Ljava/lang/String;Z)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void paprika$commandsOld(String message, boolean addToHistory, CallbackInfo ci) {
        if (Commands.onChat(message)) ci.cancel();
    }
}
