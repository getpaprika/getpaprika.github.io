package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.AntiSpamModule;
import net.minecraft.ChatFormatting;
import net.minecraft.client.GuiMessage;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.List;

@Mixin(ChatComponent.class)
public abstract class ChatComponentMixin {
    @Shadow @Final private List<GuiMessage> allMessages;

    @Shadow public abstract void rescaleChat();

    @Unique private String paprika$lastText;
    @Unique private int paprika$count = 1;

    @ModifyVariable(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/GuiMessageTag;)V",
            at = @At("HEAD"), argsOnly = true, require = 0)
    private Component paprika$antiSpam(Component message) {
        return paprika$merge(message);
    }

    @ModifyVariable(method = "addMessage(Lnet/minecraft/network/chat/Component;I)V",
            at = @At("HEAD"), argsOnly = true, require = 0)
    private Component paprika$antiSpamOld(Component message) {
        return paprika$merge(message);
    }

    @Unique
    private Component paprika$merge(Component message) {
        if (!ModuleManager.isOn(AntiSpamModule.class)) {
            paprika$lastText = null;
            return message;
        }
        String text = message.getString();
        if (text.equals(paprika$lastText) && !allMessages.isEmpty()) {
            paprika$count++;
            allMessages.remove(0);
            rescaleChat();
            return message.copy().append(Component.literal(" (x" + paprika$count + ")").withStyle(ChatFormatting.GRAY));
        }
        paprika$lastText = text;
        paprika$count = 1;
        return message;
    }
}
