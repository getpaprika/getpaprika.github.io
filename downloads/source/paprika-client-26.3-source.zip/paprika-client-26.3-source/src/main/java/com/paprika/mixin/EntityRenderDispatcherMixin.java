package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.EntityCullingModule;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void paprika$cull(Entity entity, Frustum frustum, double camX, double camY, double camZ, float partialTicks,
                              CallbackInfoReturnable<Boolean> cir) {
        if (ModuleManager.isOn(EntityCullingModule.class) && !EntityCullingModule.isEntityVisible(entity)) {
            cir.setReturnValue(false);
        }
    }
}
