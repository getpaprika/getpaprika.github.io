package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class ChestStealerModule extends Module {
    public ChestStealerModule() {
        super("ChestStealer", "Buttons to take all blocks or all items from a chest", Category.PLAYER);
    }
}
