package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class ItemEspModule extends Module {
    public ItemEspModule() {
        super("ItemESP", "Purple boxes around dropped items, through walls", Category.RENDER);
    }
}
