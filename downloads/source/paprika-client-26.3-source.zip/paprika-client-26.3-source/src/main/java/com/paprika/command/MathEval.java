package com.paprika.command;

import java.math.BigDecimal;
import java.math.MathContext;

public final class MathEval {
    public static final class MathException extends RuntimeException {
        public MathException(String message) { super(message); }
    }

    private final String s;
    private int i;

    private MathEval(String s) {
        this.s = s.replace(" ", "").toLowerCase();
    }

    public static double eval(String expression) {
        MathEval e = new MathEval(expression);
        if (e.s.isEmpty()) throw new MathException("empty equation");
        double v = e.expr();
        if (e.i < e.s.length()) throw new MathException("unexpected '" + e.s.charAt(e.i) + "'");
        if (Double.isNaN(v) || Double.isInfinite(v)) throw new MathException("the answer is too big or not a number");
        return v;
    }

    public static String format(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return String.valueOf((long) v);
        return new BigDecimal(v).round(new MathContext(12)).stripTrailingZeros().toPlainString();
    }

    private double expr() {
        double v = term();
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '+') { i++; v += term(); }
            else if (c == '-') { i++; v -= term(); }
            else break;
        }
        return v;
    }

    private double term() {
        double v = unary();
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == 'x' || c == '*') { i++; v *= unary(); }
            else if (c == '/') {
                i++;
                double d = unary();
                if (d == 0) throw new MathException("can't divide by zero");
                v /= d;
            } else break;
        }
        return v;
    }

    private double unary() {
        if (i < s.length() && s.charAt(i) == '-') { i++; return -unary(); }
        if (i < s.length() && s.charAt(i) == '+') { i++; return unary(); }
        return power();
    }

    private double power() {
        double base = atom();
        if (i < s.length() && (s.charAt(i) == '^' || s.charAt(i) == '@')) {
            i++;
            double exp = unary();
            return Math.pow(base, exp);
        }
        return base;
    }

    private double atom() {
        if (i >= s.length()) throw new MathException("the equation ends too early");
        char c = s.charAt(i);
        if (c == '(') {
            i++;
            double v = expr();
            if (i >= s.length() || s.charAt(i) != ')') throw new MathException("missing ')'");
            i++;
            return v;
        }
        int start = i;
        while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.' || s.charAt(i) == ',')) i++;
        if (start == i) throw new MathException("unexpected '" + c + "'");
        try {
            return Double.parseDouble(s.substring(start, i).replace(',', '.'));
        } catch (NumberFormatException e) {
            throw new MathException("bad number '" + s.substring(start, i) + "'");
        }
    }
}
