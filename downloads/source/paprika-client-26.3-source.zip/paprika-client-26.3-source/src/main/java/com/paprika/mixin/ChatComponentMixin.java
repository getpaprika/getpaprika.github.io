package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.AntiSpamModule;
import net.minecraft.ChatFormatting;
import net.minecraft.client.multiplayer.chat.GuiMessage;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.List;

@Mixin(ChatComponent.class)
public abstract class ChatComponentMixin {
    @Shadow @Final private List<GuiMessage> allMessages;

    @Shadow public abstract void rescaleChat();

    @Unique private String paprika$lastText;
    @Unique private int paprika$count = 1;

    @ModifyVariable(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V",
            at = @At("HEAD"), argsOnly = true)
    private Component paprika$antiSpam(Component message) {
        if (!ModuleManager.isOn(AntiSpamModule.class)) {
            paprika$lastText = null;
            return message;
        }
        String text = message.getString();
        if (text.equals(paprika$lastText) && !allMessages.isEmpty()) {
            paprika$count++;
            allMessages.remove(0);
            rescaleChat();
            return message.copy().append(Component.literal(" (x" + paprika$count + ")").withStyle(ChatFormatting.GRAY));
        }
        paprika$lastText = text;
        paprika$count = 1;
        return message;
    }
}
