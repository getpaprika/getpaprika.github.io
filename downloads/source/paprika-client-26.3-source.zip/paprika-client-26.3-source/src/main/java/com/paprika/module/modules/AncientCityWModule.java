package com.paprika.module.modules;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class AncientCityWModule extends StructureWModule {
    private static final Map<Block, String> TYPES = new LinkedHashMap<>();
    private static final String[] ORDER = {"reinforced", "shrieker", "catalyst", "tiles", "soul"};

    static {
        TYPES.put(Blocks.REINFORCED_DEEPSLATE, "reinforced");
        TYPES.put(Blocks.SCULK_SHRIEKER, "shrieker");
        TYPES.put(Blocks.SCULK_CATALYST, "catalyst");
        TYPES.put(Blocks.DEEPSLATE_TILES, "tiles");
        TYPES.put(Blocks.CRACKED_DEEPSLATE_TILES, "tiles");
        TYPES.put(Blocks.SOUL_LANTERN, "soul");
    }

    public AncientCityWModule() {
        super("AncientCityW", "Finds ancient cities in loaded chunks and shows them in teal");
    }

    @Override protected Map<Block, String> types() { return TYPES; }
    @Override protected String[] order() { return ORDER; }
    @Override protected Set<String> sureTypes() { return Set.of("reinforced"); }
    @Override protected String specialType() { return "reinforced"; }
    @Override protected String specialMessage(BlockPos p) { return "Ancient city portal frame at " + p.getX() + ", " + p.getY() + ", " + p.getZ() + "!"; }
    @Override protected int minBlocks() { return 80; }
    @Override protected String structureName() { return "Ancient City"; }
    @Override protected boolean scanHere() { return mc.level.dimension() == Level.OVERWORLD; }
    @Override public int fillColor() { return 0x4D1ABC9C; }
    @Override public int outlineColor() { return 0xFF1ABC9C; }
    @Override public int labelColor() { return 0xFF55E0C0; }

    @Override
    protected String nice(String type, int n) {
        return n + " " + switch (type) {
            case "reinforced" -> "reinforced deepslate";
            case "shrieker" -> n == 1 ? "sculk shrieker" : "sculk shriekers";
            case "catalyst" -> n == 1 ? "sculk catalyst" : "sculk catalysts";
            case "tiles" -> "deepslate tiles";
            case "soul" -> n == 1 ? "soul lantern" : "soul lanterns";
            default -> type;
        };
    }
}
