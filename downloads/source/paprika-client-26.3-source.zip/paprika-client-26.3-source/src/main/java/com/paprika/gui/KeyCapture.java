package com.paprika.gui;

import com.mojang.blaze3d.platform.InputConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class KeyCapture {
    public static final int SHIFT = 1 << 16, CTRL = 1 << 17, ALT = 1 << 18, SUPER = 1 << 19;
    private static final int KEY_MASK = 0xFFFF;

    private final List<Integer> pressed = new ArrayList<>();

    public void reset() {
        pressed.clear();
    }

    public void press(int key) {
        if (!pressed.contains(key)) pressed.add(key);
    }

    public Integer release(int key) {
        if (!pressed.contains(key)) return null;
        Integer bind = current();
        reset();
        return bind;
    }

    public Integer current() {
        if (pressed.isEmpty()) return null;
        int main = -1, mods = 0;
        for (int k : pressed) {
            int bit = modBit(k);
            if (bit != 0) mods |= bit;
            else main = k;
        }
        if (main == -1) {
            main = pressed.get(pressed.size() - 1);
            mods &= ~modBit(main);
        }
        return main | mods;
    }

    private static int modBit(int key) {
        return switch (key) {
            case InputConstants.KEY_LSHIFT, InputConstants.KEY_RSHIFT -> SHIFT;
            case InputConstants.KEY_LCONTROL, InputConstants.KEY_RCONTROL -> CTRL;
            case InputConstants.KEY_LALT, InputConstants.KEY_RALT -> ALT;
            case InputConstants.KEY_LGUI, InputConstants.KEY_RGUI -> SUPER;
            default -> 0;
        };
    }

    public static boolean isDown(long window, int bind) {
        if (bind < 0) return false;
        int key = bind & KEY_MASK, need = bind & ~KEY_MASK;
        if (!InputConstants.isKeyDown(key)) return false;
        int have = 0;
        if (down(window, InputConstants.KEY_LSHIFT) || down(window, InputConstants.KEY_RSHIFT)) have |= SHIFT;
        if (down(window, InputConstants.KEY_LCONTROL) || down(window, InputConstants.KEY_RCONTROL)) have |= CTRL;
        if (down(window, InputConstants.KEY_LALT) || down(window, InputConstants.KEY_RALT)) have |= ALT;
        if (down(window, InputConstants.KEY_LGUI) || down(window, InputConstants.KEY_RGUI)) have |= SUPER;
        return (have & need) == need;
    }

    private static boolean down(long window, int key) {
        return InputConstants.isKeyDown(key);
    }

    public static String name(int bind) {
        if (bind < 0) return "None";
        StringBuilder sb = new StringBuilder();
        if ((bind & CTRL) != 0) sb.append("Ctrl+");
        if ((bind & SHIFT) != 0) sb.append("Shift+");
        if ((bind & ALT) != 0) sb.append("Alt+");
        if ((bind & SUPER) != 0) sb.append("Win+");
        return sb.append(keyName(bind & KEY_MASK)).toString();
    }

    private static String keyName(int key) {
        String name = InputConstants.Type.KEYBOARD.getOrCreate(key).getDisplayName().getString();
        return name.replace("Left ", "L").replace("Right ", "R").replace("Keypad ", "KP");
    }
}
