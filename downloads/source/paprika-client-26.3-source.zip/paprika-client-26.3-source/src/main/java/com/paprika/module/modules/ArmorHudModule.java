package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public class ArmorHudModule extends Module {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public ArmorHudModule() {
        super("ArmorHUD", "Shows your armor next to the off-hand slot", Category.RENDER);
    }

    @Override
    public int onRender(GuiGraphicsExtractor g, int x, int y) {
        if (mc.player == null) return 0;
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();
        int offhandX = width / 2 - 91 - 29;
        int startX = offhandX - 4 - SLOTS.length * 18;
        int iy = height - 19;

        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack stack = mc.player.getItemBySlot(SLOTS[i]);
            int ix = startX + i * 18;
            g.fill(ix - 1, iy - 1, ix + 17, iy + 17, 0x60000000);
            if (stack.isEmpty()) continue;
            g.item(stack, ix, iy);
            g.itemDecorations(mc.font, stack, ix, iy);

            if (stack.isDamageableItem() && stack.getMaxDamage() - stack.getDamageValue() <= stack.getMaxDamage() * 0.1
                    && (System.currentTimeMillis() / 400) % 2 == 0) {
                g.fill(ix - 1, iy - 1, ix + 17, iy + 17, 0x60FF0000);
            }
        }
        return 0;
    }

    @Override
    public int onRenderPreview(GuiGraphicsExtractor g, int x, int y) {
        if (mc.player != null) for (EquipmentSlot s : SLOTS) if (!mc.player.getItemBySlot(s).isEmpty()) return onRender(g, x, y);

        String[] example = {"diamond_helmet", "diamond_chestplate", "diamond_leggings", "diamond_boots"};
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();
        int startX = width / 2 - 91 - 29 - 4 - SLOTS.length * 18;
        int iy = height - 19;
        for (int i = 0; i < example.length; i++) {
            int ix = startX + i * 18;
            g.fill(ix - 1, iy - 1, ix + 17, iy + 17, 0x60000000);
            g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,
                    net.minecraft.resources.Identifier.withDefaultNamespace("textures/item/" + example[i] + ".png"), ix, iy, 0, 0, 16, 16, 16, 16);
        }
        return 0;
    }
}
