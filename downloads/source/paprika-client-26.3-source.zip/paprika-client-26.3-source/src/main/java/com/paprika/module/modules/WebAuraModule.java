package com.paprika.module.modules;

import com.paprika.command.Friends;
import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class WebAuraModule extends Module {
    public final NumberSetting range = number("Range", "How far away a player can be", 4.5, 2, 6, 0.5, " blocks");
    public final NumberSetting delay = number("Delay", "Time between cobwebs", 0.5, 0.1, 3, 0.1, " s");

    private int cooldown;

    public WebAuraModule() {
        super("WebAura", "Places a cobweb in players near you, then switches back to what you were holding", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.gui.screen() != null) return;
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        int web = webSlot();
        if (web < 0) return;

        Player target = null;
        double best = range.get() * range.get();
        for (Player p : mc.level.players()) {
            if (com.paprika.module.modules.BlinkModule.isClone(p)) continue;
            if (p == mc.player || !p.isAlive() || p.isSpectator() || p.isCreative() || Friends.is(p)) continue;
            double d = mc.player.getEyePosition().distanceToSqr(p.position());
            if (d > best) continue;
            if (placeHit(p.blockPosition()) == null) continue;
            best = d;
            target = p;
        }
        if (target == null) return;

        BlockHitResult hit = placeHit(target.blockPosition());
        int before = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(web);
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
        mc.player.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
        mc.player.getInventory().setSelectedSlot(before);
        cooldown = (int) Math.round(delay.get() * 20);
    }

    private BlockHitResult placeHit(BlockPos pos) {
        if (!mc.level.getBlockState(pos).canBeReplaced() || mc.level.getBlockState(pos).is(Blocks.COBWEB)) return null;
        if (new AABB(pos).intersects(mc.player.getBoundingBox())) return null;
        for (Direction d : new Direction[] {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.UP}) {
            BlockPos against = pos.relative(d);
            if (mc.level.getBlockState(against).canBeReplaced()) continue;
            Direction face = d.getOpposite();
            Vec3 at = Vec3.atCenterOf(against).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
            if (mc.player.getEyePosition().distanceToSqr(at) > 4.5 * 4.5 + 1) continue;
            return new BlockHitResult(at, face, against, false);
        }
        return null;
    }

    private int webSlot() {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getItem(i).is(Items.COBWEB)) return i;
        return -1;
    }
}
