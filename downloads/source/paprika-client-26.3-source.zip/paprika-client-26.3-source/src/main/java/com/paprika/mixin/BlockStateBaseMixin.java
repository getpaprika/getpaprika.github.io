package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.XrayModule;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockBehaviour.BlockStateBase.class)
public abstract class BlockStateBaseMixin {
    @Inject(method = "getShadeBrightness", at = @At("HEAD"), cancellable = true)
    private void paprika$noShade(BlockGetter level, BlockPos pos, CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.isOn(XrayModule.class)) {
            cir.setReturnValue(1.0F);
        }
    }
}
