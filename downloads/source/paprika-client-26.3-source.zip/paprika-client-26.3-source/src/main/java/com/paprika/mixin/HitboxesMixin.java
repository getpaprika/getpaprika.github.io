package com.paprika.mixin;

import com.paprika.module.modules.HitboxesModule;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class HitboxesMixin {
    @Inject(method = "getPickRadius", at = @At("HEAD"), cancellable = true)
    private void paprika$bigger(CallbackInfoReturnable<Float> cir) {
        float extra = HitboxesModule.extra((Entity) (Object) this);
        if (extra >= 0) cir.setReturnValue(extra);
    }
}
