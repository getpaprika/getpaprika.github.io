package com.paprika.module.modules;

import com.google.gson.JsonObject;
import com.paprika.Config;
import net.minecraft.world.level.block.CropBlock;
import com.paprika.command.Areas;
import com.paprika.baritone.Goal;
import com.paprika.baritone.Pathfinder;
import com.paprika.gui.BaritoneTutorialScreen;
import com.paprika.gui.ClickGuiScreen;
import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class BaritoneModule extends Module {
    private static boolean avoidDanger = false;
    private static boolean autoEat = false;
    private static boolean tutorialSeen = false;

    private static final int MAX_NODES = 15000;
    private static final int STUCK_TICKS = 100;
    private static final int MAX_FAILURES = 5;
    private static final int NO_GAIN_TICKS = 300;
    private static final int MAX_NO_GAIN = 3;
    private static final double DANGER_RANGE = 10.0;
    private static final double MELEE_RANGE = 3.0;

    private enum Task { NONE, GOTO_POS, GOTO_ENTITY, FOLLOW, MINE, FARM, MINE_AREA, FILL_AREA, CROP_FARM }

    private Task task = Task.NONE;
    private BlockPos gotoPos;
    private Entity targetEntity;
    private String targetName;
    private Block mineBlock;
    private final List<BlockPos> mineCandidates = new ArrayList<>();
    private BlockPos mineTarget;
    private boolean announcedNone;
    private int rescanTimer;

    private List<String> farmTypes = List.of();
    private Entity farmTarget;
    private Vec3 farmLastPos;
    private BlockPos lootPos;
    private int lootTicks;

    private static final long MAX_AREA_BLOCKS = 200_000;
    private List<Areas.Area> workAreas = List.of();
    private final Set<BlockPos> areaSkipped = new HashSet<>();
    private Block fillBlock;
    private Item fillItem;
    private final List<BlockPos> fillCandidates = new ArrayList<>();
    private BlockPos fillTarget;
    private int fillAttempts;
    private int fillPicks;
    private int fillCooldown;

    private enum FarmPhase { PLANT, BONEMEAL, HARVEST, COLLECT }
    private static final int FARM_RADIUS = 64;
    private static final Item[] SEEDS = {Items.WHEAT_SEEDS, Items.CARROT, Items.POTATO, Items.BEETROOT_SEEDS};
    private FarmPhase farmPhase = FarmPhase.PLANT;
    private BlockPos farmCenter;
    private final List<BlockPos> farmland = new ArrayList<>();
    private BlockPos cropTarget;
    private int farmCooldown;
    private int farmRescan;
    private int collectTicks;
    private boolean warnedNoBoneMeal;
    private final Set<BlockPos> farmSkipped = new HashSet<>();

    private int placeCooldown;
    private int collideTicks;
    private final Set<BlockPos> placedBlocks = new HashSet<>();

    private List<BlockPos> path = List.of();
    private int index;
    private BlockPos plannedFor;
    private int ticksSinceProgress;
    private int failures;
    private BlockPos pickupPos;
    private int pickupTicks;

    private Goal watchGoal;
    private double watchBestH;
    private int noGainTicks;
    private int noGainTimes;
    private final java.util.ArrayDeque<BlockPos> recentFeet = new java.util.ArrayDeque<>();
    private final java.util.Set<Long> avoidSpots = new java.util.HashSet<>();
    private int replanCooldown;
    private int mismatchTicks;
    private int miningTicks;

    private boolean retreating;
    private int retreatTicks;
    private boolean eating;
    private int eatTicks;

    private boolean pendingTutorial;

    private final Set<KeyMapping> pressed = new HashSet<>();
    private final Set<KeyMapping> desired = new HashSet<>();

    public BaritoneModule() {
        super("Baritone", "Pathfinding bot - type #b commands in chat", Category.MOVEMENT);
    }

    public static JsonObject saveSettings() {
        JsonObject o = new JsonObject();
        o.addProperty("avoidDanger", avoidDanger);
        o.addProperty("autoEat", autoEat);
        o.addProperty("tutorialSeen", tutorialSeen);
        return o;
    }

    public static void loadSettings(JsonObject o) {
        if (o.has("avoidDanger")) avoidDanger = o.get("avoidDanger").getAsBoolean();
        if (o.has("autoEat")) autoEat = o.get("autoEat").getAsBoolean();
        if (o.has("tutorialSeen")) tutorialSeen = o.get("tutorialSeen").getAsBoolean();
    }

    public static boolean avoidDanger() { return avoidDanger; }
    public static void setAvoidDanger(boolean v) { avoidDanger = v; }
    public static boolean autoEat() { return autoEat; }
    public static void setAutoEat(boolean v) { autoEat = v; }

    public static void markTutorialSeen() {
        tutorialSeen = true;
    }

    @Override
    protected void onEnable() {
        if (!tutorialSeen) pendingTutorial = true;
    }

    @Override
    protected void onDisable() {
        stopTask();
        retreating = false;
        eating = false;
        desired.clear();
        applyKeys();
        pendingTutorial = false;
    }

    @Override
    public void onTick() {
        desired.clear();
        try {
            tickLogic();
        } finally {
            applyKeys();
        }
    }

    private void tickLogic() {
        if (mc.player == null || mc.level == null || mc.gameMode == null) {
            if (task != Task.NONE) stopTask();
            return;
        }

        if (pendingTutorial && (mc.gui.screen() == null || mc.gui.screen() instanceof ClickGuiScreen)) {
            pendingTutorial = false;
            mc.gui.setScreen(new BaritoneTutorialScreen());
            return;
        }
        if (mc.gui.screen() != null) return;

        if (avoidDanger && handleDanger()) return;
        if (handleEat(false)) return;
        if (task == Task.NONE) return;

        if (busyMoving()) {
            stepAlongPath();
            return;
        }

        switch (task) {
            case GOTO_POS -> tickGotoPos();
            case GOTO_ENTITY, FOLLOW -> tickEntity();
            case MINE, MINE_AREA -> tickMine();
            case FILL_AREA -> tickFill();
            case CROP_FARM -> tickCropFarm();
            case FARM -> tickFarm();
            default -> { }
        }
    }

    public static boolean onChat(String message) {
        BaritoneModule b = ModuleManager.get(BaritoneModule.class);
        if (b == null || !b.isEnabled()) return false;
        String trimmed = message.trim();
        if (!(trimmed.equalsIgnoreCase("#b") || trimmed.toLowerCase(Locale.ROOT).startsWith("#b "))) return false;
        b.handleCommand(trimmed);
        return true;
    }

    private void handleCommand(String msg) {
        String[] a = msg.split("\\s+");
        if (a.length < 2) {
            say("Commands: goto, gotomarker, follow, stop, mine, minea, fillawith, farm, avoidDanger, autoEat, tutorial");
            return;
        }
        String cmd = a[1].toLowerCase(Locale.ROOT);
        switch (cmd) {
            case "gotomarker" -> {
                if (a.length != 3) {
                    invalid("#b gotomarker [name]");
                    return;
                }
                com.paprika.command.Markers.Marker marker = null, elsewhere = null;
                for (com.paprika.command.Markers.Marker m : com.paprika.command.Markers.all()) {
                    if (!m.name().equalsIgnoreCase(a[2])) continue;
                    if (m.dim().equals(com.paprika.command.Areas.currentDim())) marker = m;
                    else elsewhere = m;
                }
                if (marker == null) {
                    invalid(elsewhere != null ? "'" + a[2] + "' is in another dimension"
                            : "there is no marker called '" + a[2] + "' (press M to see your markers)");
                    return;
                }
                startTask(Task.GOTO_POS);
                gotoPos = BlockPos.containing(marker.x(), marker.y(), marker.z());
                say("Started gotomarker for " + marker.name());
            }
            case "goto" -> {
                if (a.length == 5) {
                    try {
                        int x = Mth.floor(Double.parseDouble(a[2]));
                        int y = Mth.floor(Double.parseDouble(a[3]));
                        int z = Mth.floor(Double.parseDouble(a[4]));
                        startTask(Task.GOTO_POS);
                        gotoPos = new BlockPos(x, y, z);
                        say("Started goto for " + x + " " + y + " " + z);
                    } catch (NumberFormatException e) {
                        invalid("#b goto x y z");
                    }
                } else if (a.length == 3) {
                    startEntityTask(Task.GOTO_ENTITY, a[2]);
                } else {
                    invalid("#b goto x y z  or  #b goto [player/entity]");
                }
            }
            case "follow" -> {
                if (a.length == 3) startEntityTask(Task.FOLLOW, a[2]);
                else invalid("#b follow [player/entity]");
            }
            case "stop" -> {
                stopTask();
                retreating = false;
                eating = false;
                say("Stopped.");
            }
            case "mine" -> {
                if (a.length != 3) {
                    invalid("#b mine [block]");
                    return;
                }
                String id = a[2].toLowerCase(Locale.ROOT);
                Identifier rl = Identifier.tryParse(id.contains(":") ? id : "minecraft:" + id);
                Block block = rl == null ? null : BuiltInRegistries.BLOCK.getOptional(rl).orElse(null);
                if (block == null || block == Blocks.AIR) {
                    invalid("there is no block called '" + a[2] + "'");
                    return;
                }
                startTask(Task.MINE);
                mineBlock = block;
                say("Started mine for " + BuiltInRegistries.BLOCK.getKey(block).getPath());
            }
            case "minea" -> {
                List<Areas.Area> areas = Areas.current();
                if (areas.isEmpty()) {
                    invalid("there are no areas here, make one with #a");
                    return;
                }
                if (totalVolume(areas) > MAX_AREA_BLOCKS) {
                    invalid("the areas are too big, max " + MAX_AREA_BLOCKS + " blocks in total");
                    return;
                }
                startTask(Task.MINE_AREA);
                say("Started minea for " + areas.size() + (areas.size() == 1 ? " area" : " areas"));
            }
            case "fillawith" -> {
                if (a.length != 3) {
                    invalid("#b fillawith [block]");
                    return;
                }
                String id = a[2].toLowerCase(Locale.ROOT);
                Identifier rl = Identifier.tryParse(id.contains(":") ? id : "minecraft:" + id);
                Block block = rl == null ? null : BuiltInRegistries.BLOCK.getOptional(rl).orElse(null);
                if (block == null || block == Blocks.AIR || block.asItem() == Items.AIR) {
                    invalid("there is no placeable block called '" + a[2] + "'");
                    return;
                }
                if (countItem(block.asItem()) == 0) {
                    invalid("you don't have any " + a[2] + " in your inventory");
                    return;
                }
                List<Areas.Area> areas = Areas.current();
                if (areas.isEmpty()) {
                    invalid("there are no areas here, make one with #a");
                    return;
                }
                if (totalVolume(areas) > MAX_AREA_BLOCKS) {
                    invalid("the areas are too big, max " + MAX_AREA_BLOCKS + " blocks in total");
                    return;
                }
                startTask(Task.FILL_AREA);
                fillBlock = block;
                fillItem = block.asItem();
                say("Started fillawith for " + BuiltInRegistries.BLOCK.getKey(block).getPath());
            }
            case "farm" -> {
                if (a.length == 2) {
                    startCropFarm();
                    return;
                }

                String joined = String.join(" ", java.util.Arrays.copyOfRange(a, 2, a.length));
                List<String> types = new ArrayList<>();
                for (String t : joined.toLowerCase(Locale.ROOT).split("[,\\s]+")) {
                    if (t.isEmpty()) continue;
                    if (t.startsWith("minecraft:")) t = t.substring("minecraft:".length());
                    Identifier rl = Identifier.tryParse("minecraft:" + t);
                    if (rl == null || !BuiltInRegistries.ENTITY_TYPE.containsKey(rl) || t.equals("player")) {
                        invalid("there is no mob called '" + t + "'");
                        return;
                    }
                    if (!types.contains(t)) types.add(t);
                }
                if (types.isEmpty()) {
                    invalid("#b farm [mob]  or  #b farm [mob], [mob], ...");
                    return;
                }
                startTask(Task.FARM);
                farmTypes = types;
                say("Started farm for " + String.join(", ", types));
            }
            case "avoiddanger" -> {
                avoidDanger = !avoidDanger;
                say("avoidDanger is " + (avoidDanger ? "ON" : "OFF"));
                Config.save();
            }
            case "autoeat" -> {
                autoEat = !autoEat;
                say("autoEat is " + (autoEat ? "ON" : "OFF"));
                Config.save();
            }
            case "tutorial" -> pendingTutorial = true;
            default -> invalid("unknown command, type #b tutorial for help");
        }
    }

    private void startEntityTask(Task t, String name) {
        Entity e = findEntity(name);
        if (e == null) {
            invalid("couldn't find '" + name + "' nearby");
            return;
        }
        startTask(t);
        targetEntity = e;
        targetName = name;
        say("Started " + (t == Task.FOLLOW ? "follow" : "goto") + " for " + e.getName().getString());
    }

    private void startTask(Task t) {
        stopTask();
        task = t;
    }

    private void stopTask() {
        task = Task.NONE;
        gotoPos = null;
        targetEntity = null;
        targetName = null;
        mineBlock = null;
        mineTarget = null;
        mineCandidates.clear();
        pickupPos = null;
        announcedNone = false;
        rescanTimer = 0;
        farmTypes = List.of();
        farmTarget = null;
        farmLastPos = null;
        lootPos = null;
        lootTicks = 0;
        placedBlocks.clear();
        workAreas = List.of();
        areaSkipped.clear();
        fillBlock = null;
        fillItem = null;
        fillCandidates.clear();
        fillTarget = null;
        fillAttempts = 0;
        fillPicks = 0;
        fillCooldown = 0;
        farmPhase = FarmPhase.PLANT;
        farmCenter = null;
        farmland.clear();
        cropTarget = null;
        farmCooldown = 0;
        farmRescan = 0;
        collectTicks = 0;
        warnedNoBoneMeal = false;
        farmSkipped.clear();
        clearPath();
        failures = 0;
        watchGoal = null;
        noGainTimes = 0;
        recentFeet.clear();
        avoidSpots.clear();
    }

    private static void invalid(String hint) {
        if (mc.player == null) return;
        mc.player.sendSystemMessage(Component.literal("[Baritone] ").withStyle(ChatFormatting.RED)
                .append(Component.literal("Invalid argument").withStyle(ChatFormatting.WHITE))
                .append(Component.literal(" (" + hint + ")").withStyle(ChatFormatting.GRAY)));
    }

    private static void say(String text) {
        if (mc.player == null) return;
        mc.player.sendSystemMessage(Component.literal("[Baritone] ").withStyle(ChatFormatting.RED)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE)));
    }

    private void tickGotoPos() {
        if (feet().equals(gotoPos)) {
            say("Arrived at " + gotoPos.getX() + " " + gotoPos.getY() + " " + gotoPos.getZ());
            stopTask();
            return;
        }
        followPath(new Goal.Block(gotoPos));
    }

    private void tickEntity() {
        if (targetEntity == null || !targetEntity.isAlive() || targetEntity.isRemoved()
                || targetEntity.level() != mc.level) {
            targetEntity = targetName == null ? null : findEntity(targetName);
            if (targetEntity == null) {
                say("Lost track of " + targetName);
                stopTask();
                return;
            }
        }

        if (mc.player.distanceTo(targetEntity) <= 2.5) {
            if (task == Task.GOTO_ENTITY) {
                say("Arrived at " + targetEntity.getName().getString());
                stopTask();
            } else {
                clearPath();
            }
            return;
        }

        if (plannedFor != null && targetEntity.blockPosition().distSqr(plannedFor) > 9) clearPath();
        if (path.isEmpty()) plannedFor = targetEntity.blockPosition();
        followPath(new Goal.Near(targetEntity.blockPosition(), 2));
    }

    private void tickMine() {
        if (pickupPos != null && pickupDrop()) return;

        if (mineTarget != null && !isMineTarget(mineTarget)) {
            if (mc.level.getBlockState(mineTarget).isAir() && mc.player.getInventory().getFreeSlot() >= 0) {
                pickupPos = mineTarget;
                pickupTicks = 0;
            }
            mineCandidates.remove(mineTarget);
            mineTarget = null;
            clearPath();
        }

        if (mineTarget == null) {
            mineCandidates.removeIf(p -> !isMineTarget(p));
            if (mineCandidates.isEmpty() && task == Task.MINE_AREA) {
                scanAreasForMining();
                if (mineCandidates.isEmpty()) {
                    say("Finished mining the areas" + (areaSkipped.isEmpty() ? ""
                            : " (" + areaSkipped.size() + " blocks couldn't be reached)"));
                    stopTask();
                    return;
                }
            }
            if (mineCandidates.isEmpty()) {
                if (rescanTimer-- > 0) return;
                rescanTimer = 100;
                scanForBlocks();
                if (mineCandidates.isEmpty()) {
                    if (!announcedNone) say("No " + blockName() + " found in loaded chunks, waiting...");
                    announcedNone = true;
                    return;
                }
            }
            announcedNone = false;
            Vec3 me = mc.player.position();
            if (task == Task.MINE_AREA) {
                mineCandidates.sort(Comparator.comparingInt((BlockPos p) -> -p.getY())
                        .thenComparingDouble(p -> Vec3.atCenterOf(p).distanceToSqr(me)));
            } else {
                mineCandidates.sort(Comparator.comparingDouble(p -> Vec3.atCenterOf(p).distanceToSqr(me)));
            }
            mineTarget = mineCandidates.get(0);
            clearPath();
            failures = 0;
        }

        if (Goal.isAdjacent(feet(), mineTarget)) {
            clearPath();
            mine(mineTarget);
            return;
        }
        followPath(new Goal.Adjacent(mineTarget));
    }

    private boolean pickupDrop() {
        pickupTicks++;
        ItemEntity item = nearestItem(pickupPos, 4);
        if (item == null) {
            if (pickupTicks < 10) return true;
            pickupPos = null;
            clearPath();
            return false;
        }
        if (pickupTicks > 120) {
            pickupPos = null;
            clearPath();
            return false;
        }
        double d = mc.player.position().distanceTo(item.position());
        if (d < 1.5) {
            clearPath();
            lookAt(new Vec3(item.getX(), mc.player.getEyeY(), item.getZ()));
            desired.add(mc.options.keyUp);
            if (mc.player.onGround() && mc.player.horizontalCollision) desired.add(mc.options.keyJump);
        } else {
            followPath(new Goal.Near(item.blockPosition(), 0));
            if (path.isEmpty()) walkToward(item.position());
        }
        return true;
    }

    private void tickFarm() {
        if (lootPos != null) {
            ItemEntity item = nearestItem(lootPos, 6);
            if (item == null || ++lootTicks > 200) {
                lootPos = null;
                clearPath();
            } else {
                double d = mc.player.position().distanceTo(item.position());
                if (d < 2.0) {
                    clearPath();
                    lookAt(new Vec3(item.getX(), mc.player.getEyeY(), item.getZ()));
                    desired.add(mc.options.keyUp);
                    if (mc.player.onGround() && mc.player.horizontalCollision) desired.add(mc.options.keyJump);
                } else {
                    followPath(new Goal.Near(item.blockPosition(), 1));
                }
                return;
            }
        }

        if (farmTarget != null && (!farmTarget.isAlive() || farmTarget.isRemoved())) {
            if (farmLastPos != null) {
                lootPos = BlockPos.containing(farmLastPos);
                lootTicks = 0;
            }
            farmTarget = null;
            farmLastPos = null;
            clearPath();
            return;
        }

        if (farmTarget == null || farmTarget.level() != mc.level) {
            farmTarget = nearestOfTypes(farmTypes);
            if (farmTarget == null || farmTarget instanceof Player) {
                farmTarget = null;
                if (!announcedNone) say("No " + String.join(", ", farmTypes) + " nearby, waiting...");
                announcedNone = true;
                return;
            }
            announcedNone = false;
            clearPath();
            failures = 0;
        }
        farmLastPos = farmTarget.position();

        if (mc.player.distanceTo(farmTarget) <= MELEE_RANGE) {
            clearPath();
            selectWeapon();
            lookAt(farmTarget.getBoundingBox().getCenter());
            if (mc.player.getAttackStrengthScale(0.5F) >= 0.95F) {
                mc.gameMode.attack(mc.player, farmTarget);
                mc.player.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
            }
            return;
        }

        if (plannedFor != null && farmTarget.blockPosition().distSqr(plannedFor) > 9) clearPath();
        if (path.isEmpty()) plannedFor = farmTarget.blockPosition();
        followPath(new Goal.Near(farmTarget.blockPosition(), 2));
    }

    private ItemEntity nearestItem(BlockPos around, double radius) {
        ItemEntity best = null;
        double bestDist = radius * radius;
        Vec3 center = Vec3.atCenterOf(around);
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof ItemEntity item) || !item.isAlive()) continue;
            double d = item.position().distanceToSqr(center);
            if (d < bestDist) {
                bestDist = d;
                best = item;
            }
        }
        return best;
    }

    private void startCropFarm() {
        if (seedItem() == null) {
            invalid("you need seeds (wheat seeds, carrots, potatoes or beetroot seeds)");
            return;
        }
        if (countItem(Items.BONE_MEAL) == 0) {
            invalid("you need bone meal");
            return;
        }
        BlockPos center = mc.player.blockPosition();
        startTask(Task.CROP_FARM);
        farmCenter = center;
        scanFarmland();
        if (farmland.isEmpty()) {
            stopTask();
            invalid("there's no farmland within " + FARM_RADIUS + " blocks");
            return;
        }
        say("Started farm for " + farmland.size() + " farmland");
    }

    private void scanFarmland() {
        farmland.clear();
        int chunks = (FARM_RADIUS >> 4) + 1;
        ChunkPos c = ChunkPos.containing(farmCenter);
        for (int cx = c.x() - chunks; cx <= c.x() + chunks; cx++) {
            for (int cz = c.z() - chunks; cz <= c.z() + chunks; cz++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;
                LevelChunkSection[] sections = chunk.getSections();
                for (int i = 0; i < sections.length; i++) {
                    LevelChunkSection section = sections[i];
                    if (section == null || section.hasOnlyAir() || !section.maybeHas(s -> s.is(Blocks.FARMLAND))) continue;
                    int baseY = SectionPos.sectionToBlockCoord(chunk.getSectionYFromSectionIndex(i));
                    for (int y = 0; y < 16; y++) {
                        for (int z = 0; z < 16; z++) {
                            for (int x = 0; x < 16; x++) {
                                if (!section.getBlockState(x, y, z).is(Blocks.FARMLAND)) continue;
                                BlockPos p = new BlockPos((cx << 4) + x, baseY + y, (cz << 4) + z);
                                double dx = p.getX() - farmCenter.getX(), dz = p.getZ() - farmCenter.getZ();
                                if (dx * dx + dz * dz <= FARM_RADIUS * FARM_RADIUS) farmland.add(p);
                            }
                        }
                    }
                }
            }
        }
    }

    private Item seedItem() {
        for (Item seed : SEEDS) if (countItem(seed) > 0) return seed;
        return null;
    }

    private boolean isCrop(BlockState state) {
        return state.getBlock() instanceof CropBlock;
    }

    private boolean isMature(BlockState state) {
        return state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state);
    }

    private void farmSay(FarmPhase phase, String text) {
        if (farmPhase != phase) say(text);
        farmSkipped.clear();
        farmPhase = phase;
        cropTarget = null;
        clearPath();
    }

    private void tickCropFarm() {
        if (farmCooldown > 0) farmCooldown--;
        if (++farmRescan > 200) {
            farmRescan = 0;
            scanFarmland();
        }
        farmland.removeIf(p -> !mc.level.getBlockState(p).is(Blocks.FARMLAND) && mc.level.hasChunkAt(p));

        switch (farmPhase) {
            case PLANT -> {
                Item seed = seedItem();
                if (cropTarget == null || !mc.level.getBlockState(cropTarget).isAir()) {
                    cropTarget = seed == null ? null : nearest(p -> mc.level.getBlockState(p.above()).isAir(), true);
                }
                if (cropTarget == null) {
                    if (seed == null) say("Out of seeds, moving on with what's planted");
                    farmSay(FarmPhase.BONEMEAL, "Planting done, using bone meal");
                    return;
                }
                useOn(cropTarget.below(), Direction.UP, seed);
            }
            case BONEMEAL -> {
                if (cropTarget == null || !isCrop(mc.level.getBlockState(cropTarget)) || isMature(mc.level.getBlockState(cropTarget))) {
                    cropTarget = nearest(p -> {
                        BlockState s = mc.level.getBlockState(p.above());
                        return isCrop(s) && !isMature(s);
                    }, true);
                }
                if (cropTarget == null) {
                    farmSay(FarmPhase.HARVEST, "Everything is grown, harvesting");
                    return;
                }
                if (countItem(Items.BONE_MEAL) == 0) {
                    if (!warnedNoBoneMeal) say("Out of bone meal, waiting for the crops to grow");
                    warnedNoBoneMeal = true;
                    clearPath();
                    return;
                }
                useOn(cropTarget, Direction.UP, Items.BONE_MEAL);
            }
            case HARVEST -> {
                if (cropTarget == null || !isMature(mc.level.getBlockState(cropTarget))) {
                    cropTarget = nearest(p -> isMature(mc.level.getBlockState(p.above())), true);
                }
                if (cropTarget == null) {
                    collectTicks = 0;
                    farmSay(FarmPhase.COLLECT, "Harvested, collecting the drops");
                    return;
                }
                if (mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(cropTarget)) <= 4.5) {
                    clearPath();
                    mine(cropTarget);
                } else {
                    followPath(new Goal.Reach(cropTarget));
                    if (path.isEmpty()) walkToward(Vec3.atCenterOf(cropTarget));
                }
            }
            case COLLECT -> {
                ItemEntity item = nearestItem(farmCenter, FARM_RADIUS + 4);
                if (item == null || ++collectTicks > 900) {
                    farmSay(FarmPhase.PLANT, "Replanting");
                    return;
                }
                if (mc.player.position().distanceTo(item.position()) < 2.0) {
                    clearPath();
                    lookAt(new Vec3(item.getX(), mc.player.getEyeY(), item.getZ()));
                    desired.add(mc.options.keyUp);
                    if (mc.player.onGround() && mc.player.horizontalCollision) desired.add(mc.options.keyJump);
                } else {
                    followPath(new Goal.Near(item.blockPosition(), 1));
                }
            }
        }
    }

    private void walkToward(Vec3 target) {
        lookAt(new Vec3(target.x, mc.player.getEyeY(), target.z));
        desired.add(mc.options.keyUp);
        if (mc.player.onGround() && mc.player.horizontalCollision) desired.add(mc.options.keyJump);
    }

    private BlockPos nearest(java.util.function.Predicate<BlockPos> test, boolean above) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        Vec3 me = mc.player.position();
        for (BlockPos p : farmland) {
            if (!mc.level.hasChunkAt(p) || farmSkipped.contains(p.above()) || !test.test(p)) continue;
            double d = Vec3.atCenterOf(p).distanceToSqr(me);
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best == null ? null : (above ? best.above() : best);
    }

    private void useOn(BlockPos block, Direction face, Item item) {
        Vec3 hit = Vec3.atCenterOf(block).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
        if (mc.player.getEyePosition().distanceTo(hit) > 4.5) {
            followPath(new Goal.Reach(block.above()));
            if (path.isEmpty()) walkToward(hit);
            return;
        }
        clearPath();
        lookAt(hit);
        if (farmCooldown > 0) return;
        if (!selectItem(item)) return;
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, block, false));
        mc.player.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
        farmCooldown = item == Items.BONE_MEAL ? 4 : 2;
    }

    private static long totalVolume(List<Areas.Area> areas) {
        long v = 0;
        for (Areas.Area a : areas) v += a.volume();
        return v;
    }

    private boolean isMineTarget(BlockPos p) {
        BlockState state = mc.level.getBlockState(p);
        if (task == Task.MINE_AREA) return canMineInArea(p, state);
        return state.is(mineBlock) && !DangerousNetherrackModule.isDangerous(mc.level, p)
                && !Pathfinder.touchesFluid(mc.level, p);
    }

    private boolean canMineInArea(BlockPos p, BlockState state) {
        if (state.isAir() || state.getBlock() instanceof LiquidBlock) return false;
        if (state.getDestroySpeed(mc.level, p) < 0) return false;
        if (DangerousNetherrackModule.isDangerous(mc.level, p)) return false;
        if (Pathfinder.touchesFluid(mc.level, p)) return false;
        return Pathfinder.breakTicks(mc.level, p, state, mc.player) <= 1200;
    }

    private void scanAreasForMining() {
        mineCandidates.clear();
        workAreas = Areas.current();
        for (Areas.Area area : workAreas) {
            for (int x = area.minX(); x <= area.maxX(); x++) {
                for (int y = area.minY(); y <= area.maxY(); y++) {
                    for (int z = area.minZ(); z <= area.maxZ(); z++) {
                        BlockPos p = new BlockPos(x, y, z);
                        if (!mc.level.hasChunkAt(p) || areaSkipped.contains(p)) continue;
                        if (canMineInArea(p, mc.level.getBlockState(p))) mineCandidates.add(p);
                    }
                }
            }
        }
    }

    private void tickFill() {
        if (countItem(fillItem) == 0) {
            say("Out of " + BuiltInRegistries.BLOCK.getKey(fillBlock).getPath() + ", stopped filling");
            stopTask();
            return;
        }

        if (fillTarget != null && !Pathfinder.isReplaceable(mc.level, fillTarget)) {
            fillCandidates.remove(fillTarget);
            fillTarget = null;
            clearPath();
        }

        if (fillTarget == null) {
            fillCandidates.removeIf(p -> !Pathfinder.isReplaceable(mc.level, p));
            if (fillCandidates.isEmpty() || ++fillPicks > 100) {
                fillPicks = 0;
                scanAreasForFilling();
            }
            if (fillCandidates.isEmpty()) {
                say("Finished filling the areas" + (areaSkipped.isEmpty() ? ""
                        : " (" + areaSkipped.size() + " spots couldn't be filled)"));
                stopTask();
                return;
            }
            fillTarget = pickFillTarget();
            if (fillTarget == null) {
                say("There's nothing to place the blocks against, stopped filling");
                stopTask();
                return;
            }
            fillAttempts = 0;
            failures = 0;
            clearPath();
        }

        BlockPos support = null;
        Direction face = null;
        for (Direction d : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP}) {
            BlockPos n = fillTarget.relative(d);
            if (isSolid(n)) {
                support = n;
                face = d.getOpposite();
                break;
            }
        }
        if (support == null) {
            fillCandidates.remove(fillTarget);
            fillTarget = null;
            return;
        }

        Vec3 hit = Vec3.atCenterOf(support).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
        boolean inReach = mc.player.getEyePosition().distanceTo(hit) <= 4.5 && !insidePlayer(fillTarget);
        if (!inReach) {
            followPath(new Goal.Reach(fillTarget));
            if (path.isEmpty() && !insidePlayer(fillTarget)) walkToward(hit);
            return;
        }

        clearPath();
        lookAt(hit);
        if (fillCooldown > 0) {
            fillCooldown--;
            return;
        }
        if (!selectItem(fillItem)) return;

        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, support, false));
        mc.player.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
        fillCooldown = 2;
        if (++fillAttempts > 10) {
            areaSkipped.add(fillTarget);
            fillCandidates.remove(fillTarget);
            fillTarget = null;
        }
    }

    private void scanAreasForFilling() {
        fillCandidates.clear();
        workAreas = Areas.current();
        for (Areas.Area area : workAreas) {
            for (int x = area.minX(); x <= area.maxX(); x++) {
                for (int y = area.minY(); y <= area.maxY(); y++) {
                    for (int z = area.minZ(); z <= area.maxZ(); z++) {
                        BlockPos p = new BlockPos(x, y, z);
                        if (!mc.level.hasChunkAt(p) || areaSkipped.contains(p)) continue;
                        if (Pathfinder.isReplaceable(mc.level, p)) fillCandidates.add(p);
                    }
                }
            }
        }
        Vec3 me = mc.player.position();
        fillCandidates.sort(Comparator.comparingInt((BlockPos p) -> p.getY())
                .thenComparingDouble(p -> Vec3.atCenterOf(p).distanceToSqr(me)));
    }

    private BlockPos pickFillTarget() {
        BlockPos fallback = null;
        for (BlockPos p : fillCandidates) {
            if (!hasSupport(p)) continue;
            if (insidePlayer(p)) {
                if (fallback == null) fallback = p;
                continue;
            }
            return p;
        }
        return fallback;
    }

    private boolean hasSupport(BlockPos p) {
        for (Direction d : Direction.values()) if (isSolid(p.relative(d))) return true;
        return false;
    }

    private boolean isSolid(BlockPos p) {
        return !Pathfinder.isReplaceable(mc.level, p) && !mc.level.getBlockState(p).getCollisionShape(mc.level, p).isEmpty();
    }

    private boolean insidePlayer(BlockPos p) {
        return mc.player.getBoundingBox().intersects(new AABB(p));
    }

    private int countItem(Item item) {
        int count = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (stack.is(item)) count += stack.getCount();
        }
        return count;
    }

    private boolean selectItem(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getItem(i).is(item)) {
                mc.player.getInventory().setSelectedSlot(i);
                return true;
            }
        }
        if (mc.player.containerMenu != mc.player.inventoryMenu) return false;
        for (int i = 9; i < 36; i++) {
            if (mc.player.getInventory().getItem(i).is(item)) {
                mc.gameMode.handleContainerInput(mc.player.inventoryMenu.containerId, i,
                        mc.player.getInventory().getSelectedSlot(), ContainerInput.SWAP, mc.player);
                return false;
            }
        }
        return false;
    }

    private String blockName() {
        return mineBlock == null ? "?" : BuiltInRegistries.BLOCK.getKey(mineBlock).getPath();
    }

    private void scanForBlocks() {
        mineCandidates.clear();
        int radius = mc.options.getEffectiveRenderDistance() + 1;
        ChunkPos center = mc.player.chunkPosition();
        for (int cx = center.x() - radius; cx <= center.x() + radius; cx++) {
            for (int cz = center.z() - radius; cz <= center.z() + radius; cz++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;
                LevelChunkSection[] sections = chunk.getSections();
                for (int i = 0; i < sections.length; i++) {
                    LevelChunkSection section = sections[i];
                    if (section == null || section.hasOnlyAir()) continue;
                    if (!section.maybeHas(s -> s.is(mineBlock))) continue;
                    int baseX = cx << 4;
                    int baseY = SectionPos.sectionToBlockCoord(chunk.getSectionYFromSectionIndex(i));
                    int baseZ = cz << 4;
                    for (int y = 0; y < 16; y++) {
                        for (int z = 0; z < 16; z++) {
                            for (int x = 0; x < 16; x++) {
                                if (section.getBlockState(x, y, z).is(mineBlock)) {
                                    mineCandidates.add(new BlockPos(baseX + x, baseY + y, baseZ + z));
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private Entity nearestOfTypes(List<String> types) {
        if (mc.level == null || mc.player == null) return null;
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || e instanceof Player || !e.isAlive()) continue;
            if (!types.contains(BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath())) continue;
            double d = e.distanceToSqr(mc.player);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    private Entity findEntity(String name) {
        if (mc.level == null || mc.player == null) return null;
        String wanted = name.toLowerCase(Locale.ROOT);
        if (wanted.startsWith("minecraft:")) wanted = wanted.substring("minecraft:".length());

        for (Player p : mc.level.players()) {
            if (com.paprika.module.modules.BlinkModule.isClone(p)) continue;
            if (p != mc.player && p.getName().getString().equalsIgnoreCase(name)) return p;
        }
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || !e.isAlive()) continue;
            String type = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
            boolean match = type.equals(wanted)
                    || (e.hasCustomName() && e.getCustomName().getString().equalsIgnoreCase(name));
            if (!match) continue;
            double d = e.distanceToSqr(mc.player);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    private BlockPos feet() {
        return BlockPos.containing(mc.player.getX(), mc.player.getY() + 0.5, mc.player.getZ());
    }

    private void clearPath() {
        path = List.of();
        index = 0;
        plannedFor = null;
        ticksSinceProgress = 0;
        mismatchTicks = 0;
        miningTicks = 0;
    }

    private void progress() {
        ticksSinceProgress = 0;
        failures = 0;
        mismatchTicks = 0;
        miningTicks = 0;
    }

    private void followPath(Goal goal) {
        if (!watchProgress(goal)) return;
        if (path.isEmpty() || index >= path.size() - 1) {
            if (!plan(goal)) return;
        }
        stepAlongPath();
    }

    private boolean watchProgress(Goal goal) {
        BlockPos feet = feet();
        double h = goal.heuristic(feet);
        if (!goal.equals(watchGoal)) {
            watchGoal = goal;
            watchBestH = h;
            noGainTicks = 0;
            noGainTimes = 0;
            recentFeet.clear();
            return true;
        }
        if (recentFeet.isEmpty() || !recentFeet.peekLast().equals(feet)) {
            recentFeet.add(feet.immutable());
            if (recentFeet.size() > 40) recentFeet.poll();
        }
        if (h < watchBestH - 0.5) {
            watchBestH = h;
            noGainTicks = 0;
            noGainTimes = 0;
            return true;
        }

        if (mc.gameMode.isDestroying() || !(mc.player.onGround() || mc.player.isInWater())) return true;
        if (++noGainTicks < NO_GAIN_TICKS) return true;

        noGainTicks = 0;
        noGainTimes++;
        if (avoidSpots.size() > 2000) avoidSpots.clear();
        for (BlockPos p : recentFeet) avoidSpots.add(p.asLong());
        recentFeet.clear();
        clearPath();
        replanCooldown = 0;
        if (noGainTimes >= MAX_NO_GAIN) {
            noGainTimes = 0;
            watchGoal = null;
            giveUp(true);
            return false;
        }
        say("Stuck going back and forth, trying another way");
        return true;
    }

    private boolean plan(Goal goal) {
        if (replanCooldown > 0) {
            replanCooldown--;
            return false;
        }
        Pathfinder.Result r = Pathfinder.find(mc.level, mc.player, feet(), goal, MAX_NODES, avoidSpots);
        if (r.path().size() < 2 && r.complete()) return false;
        if (r.path().size() < 2) {
            failures++;
            replanCooldown = 20;
            giveUp(false);
            return false;
        }
        path = r.path();
        index = 0;
        ticksSinceProgress = 0;
        return true;
    }

    private void giveUp(boolean now) {
        {
            if (task == Task.FARM && (farmTarget != null || lootPos != null)) {
                farmTarget = null;
                farmLastPos = null;
                lootPos = null;
                failures = 0;
                return;
            }
            if (task == Task.CROP_FARM && cropTarget != null) {
                farmSkipped.add(cropTarget);
                cropTarget = null;
                failures = 0;
                return;
            }
            if (task == Task.FILL_AREA && fillTarget != null) {
                areaSkipped.add(fillTarget);
                fillCandidates.remove(fillTarget);
                fillTarget = null;
                failures = 0;
                return;
            }
            if ((task == Task.MINE || task == Task.MINE_AREA) && mineTarget != null) {
                if (task == Task.MINE_AREA) areaSkipped.add(mineTarget);

                mineCandidates.remove(mineTarget);
                mineTarget = null;
                failures = 0;
                return;
            }
            if (now || failures >= MAX_FAILURES) {
                say("Can't find a path there");
                stopTask();
            }
        }
    }

    private void stepAlongPath() {
        BlockPos feet = feet();
        boolean inWater = mc.player.isInWater();
        if (placeCooldown > 0) placeCooldown--;

        for (int j = Math.min(path.size() - 1, index + 6); j > index; j--) {
            if (path.get(j).equals(feet) && (mc.player.onGround() || inWater)) {
                index = j;
                progress();
                break;
            }
        }
        if (index >= path.size() - 1) {
            clearPath();
            return;
        }

        BlockPos cur = path.get(index);
        BlockPos next = path.get(index + 1);

        if (feet.distSqr(cur) > 9 && feet.distSqr(next) > 9) {
            clearPath();
            return;
        }
        if (++ticksSinceProgress > STUCK_TICKS) {
            failures++;
            clearPath();
            return;
        }

        List<BlockPos> toClear = new ArrayList<>(3);
        if (next.getY() > cur.getY()) toClear.add(cur.above(2));
        toClear.add(next.above());
        toClear.add(next);
        for (BlockPos b : toClear) {
            if (!Pathfinder.isPassable(mc.level, b)) {
                mine(b);
                return;
            }
        }

        boolean waterHere = Pathfinder.isWater(mc.level, cur);

        if (next.equals(cur.above()) && !waterHere) {
            pillar(cur, next);
            return;
        }

        if (next.getY() == cur.getY()
                && !Pathfinder.isStandable(mc.level, next.below())
                && !Pathfinder.isWater(mc.level, next)) {
            if (!bridge(cur, next)) return;
        }

        boolean up = next.getY() > cur.getY();
        Vec3 target = Vec3.atBottomCenterOf(next);
        double hDist = horizontalDistance(mc.player.position(), target);
        lookAt(new Vec3(target.x, mc.player.getEyeY(), target.z));
        if (!(feet.equals(next) && hDist < 0.15)) desired.add(mc.options.keyUp);

        if (inWater) {
            desired.add(mc.options.keyJump);
        } else if (mc.player.onGround() && up && hDist < 1.3) {
            desired.add(mc.options.keyJump);
        }

        if (mc.player.horizontalCollision && mc.player.onGround()) {
            collideTicks++;
            if (collideTicks >= 4 && collideTicks <= 6 && !up) desired.add(mc.options.keyJump);
            if (collideTicks > 10) {
                BlockPos blocker = blockingBlock(target);
                if (blocker != null) {
                    desired.remove(mc.options.keyUp);
                    desired.remove(mc.options.keyJump);
                    mine(blocker);
                    return;
                }
            }
        } else {
            collideTicks = 0;
        }

        if (!inWater && next.getY() == cur.getY() && placedBlocks.contains(next.below())) {
            desired.add(mc.options.keyShift);
        }

        boolean passed = (next.getX() - cur.getX()) * (mc.player.getX() - target.x)
                + (next.getZ() - cur.getZ()) * (mc.player.getZ() - target.z) > 0;
        if (feet.equals(next) && (hDist < 0.35 || passed)
                && (mc.player.onGround() || inWater || next.getY() < cur.getY())) {
            index++;
            progress();
        }
    }

    private void pillar(BlockPos cur, BlockPos next) {
        int slot = Pathfinder.throwawaySlot(mc.player);
        if (slot < 0) {
            say("Out of blocks to pillar with (cobblestone, dirt, netherrack, planks...)");
            failures++;
            clearPath();
            return;
        }
        mc.player.getInventory().setSelectedSlot(slot);
        mc.player.setXRot(90.0F);

        Vec3 center = Vec3.atBottomCenterOf(cur);
        if (horizontalDistance(mc.player.position(), center) > 0.25 && mc.player.onGround()) {
            lookAt(new Vec3(center.x(), mc.player.getEyeY(), center.z()));
            mc.player.setXRot(90.0F);
            desired.add(mc.options.keyUp);
            return;
        }

        if (mc.player.onGround() && feet().equals(cur)) desired.add(mc.options.keyJump);

        if (mc.player.getY() > cur.getY() + 1.0 && placeCooldown <= 0
                && Pathfinder.isReplaceable(mc.level, cur)) {
            BlockHitResult hit = new BlockHitResult(
                    new Vec3(cur.getX() + 0.5, cur.getY(), cur.getZ() + 0.5), Direction.UP, cur.below(), false);
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
            mc.player.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
            placedBlocks.add(cur.immutable());
            placeCooldown = 4;
        }

        if (feet().equals(next) && mc.player.onGround()) {
            index++;
            progress();
        }
    }

    private boolean bridge(BlockPos cur, BlockPos next) {
        BlockPos spot = next.below();
        if (Pathfinder.isStandable(mc.level, spot)) return true;

        int slot = Pathfinder.throwawaySlot(mc.player);
        if (slot < 0) {
            say("Out of blocks to bridge with (cobblestone, dirt, netherrack, planks...)");
            failures++;
            clearPath();
            return false;
        }
        mc.player.getInventory().setSelectedSlot(slot);
        desired.add(mc.options.keyShift);

        Direction dir = Direction.getApproximateNearest(next.getX() - cur.getX(), 0, next.getZ() - cur.getZ());
        BlockPos support = cur.below();
        Vec3 face = Vec3.atCenterOf(support).add(dir.getStepX() * 0.5, 0, dir.getStepZ() * 0.5);
        lookAt(face);

        if (placeCooldown <= 0) {
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(face, dir, support, false));
            mc.player.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
            placedBlocks.add(spot.immutable());
            placeCooldown = 4;
        }
        return false;
    }

    private boolean busyMoving() {
        if (path.isEmpty() || index >= path.size() - 1) return !(mc.player.onGround() || mc.player.isInWater());
        BlockPos cur = path.get(index), next = path.get(index + 1);
        boolean pillar = next.equals(cur.above()) && !Pathfinder.isWater(mc.level, cur);
        boolean bridge = next.getY() == cur.getY() && !Pathfinder.isStandable(mc.level, next.below())
                && !Pathfinder.isWater(mc.level, next);
        return pillar || bridge || !(mc.player.onGround() || mc.player.isInWater());
    }

    private BlockPos blockingBlock(Vec3 target) {
        Vec3 pos = mc.player.position();
        Vec3 dir = new Vec3(target.x - pos.x, 0, target.z - pos.z);
        if (dir.lengthSqr() < 1.0E-4) return null;
        dir = dir.normalize();
        Vec3 side = new Vec3(-dir.z, 0, dir.x).scale(0.3);
        for (double h : new double[]{0.2, 1.4, 1.9}) {
            for (Vec3 off : new Vec3[]{Vec3.ZERO, side, side.reverse()}) {
                BlockPos b = BlockPos.containing(pos.x + dir.x * 0.65 + off.x, pos.y + h, pos.z + dir.z * 0.65 + off.z);
                if (Pathfinder.isPassable(mc.level, b)) continue;
                BlockState state = mc.level.getBlockState(b);
                if (state.getDestroySpeed(mc.level, b) < 0 || DangerousNetherrackModule.isDangerous(mc.level, b)) continue;
                if (Pathfinder.touchesFluid(mc.level, b)) continue;
                if (!state.getFluidState().isEmpty()) continue;
                return b;
            }
        }
        return null;
    }

    private static double horizontalDistance(Vec3 a, Vec3 b) {
        double dx = a.x - b.x, dz = a.z - b.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private void mine(BlockPos pos) {
        if (Pathfinder.touchesFluid(mc.level, pos)) {
            mc.gameMode.stopDestroyBlock();
            if ((task == Task.MINE || task == Task.MINE_AREA) && pos.equals(mineTarget)) {
                if (task == Task.MINE_AREA) areaSkipped.add(mineTarget);
                mineCandidates.remove(mineTarget);
                mineTarget = null;
            }
            if (task == Task.CROP_FARM && pos.equals(cropTarget)) {
                farmSkipped.add(cropTarget);
                cropTarget = null;
            }
            clearPath();
            return;
        }
        BlockState state = mc.level.getBlockState(pos);
        mc.player.getInventory().setSelectedSlot(Pathfinder.bestToolSlot(mc.level, pos, state, mc.player));
        lookAt(Vec3.atCenterOf(pos));

        Vec3 fromBlock = mc.player.getEyePosition().subtract(Vec3.atCenterOf(pos));
        Direction face = Direction.getApproximateNearest(fromBlock.x, fromBlock.y, fromBlock.z);
        mc.gameMode.continueDestroyBlock(pos, face);
        mc.player.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);

        mismatchTicks = 0;
        ticksSinceProgress = 0;
        if (++miningTicks > 1200) {
            miningTicks = 0;
            if ((task == Task.MINE || task == Task.MINE_AREA) && pos.equals(mineTarget)) {
                if (task == Task.MINE_AREA) areaSkipped.add(mineTarget);
                mineCandidates.remove(mineTarget);
                mineTarget = null;
            }
            clearPath();
        }
    }

    private boolean handleDanger() {
        Player p = mc.player;

        if (retreating) {
            retreatTicks++;
            Mob near = nearestHostile(16, false);
            if (near != null && retreatTicks < 200) {
                runAwayFrom(near);
                return true;
            }
            if (handleEat(true)) return true;
            retreating = false;
            clearPath();
            say("Done eating, back to it");
            return false;
        }

        Mob target = nearestHostile(DANGER_RANGE, true);
        if (target == null) return false;

        boolean low = p.getHealth() <= 8 || p.getFoodData().getFoodLevel() <= 6;
        if (low && hasFood()) {
            retreating = true;
            retreatTicks = 0;
            say("Low on health/hunger - running away to eat");
            runAwayFrom(target);
            return true;
        }

        clearPath();

        Creeper creeper = nearestDangerousCreeper();
        if (creeper != null) {
            lookAt(creeper.getBoundingBox().getCenter());
            if (selectShield()) {
                desired.add(mc.options.keyUse);
            } else {
                runAwayFrom(creeper);
            }
            return true;
        }

        selectWeapon();
        lookAt(target.getBoundingBox().getCenter());
        double dist = p.distanceTo(target);
        if (dist > MELEE_RANGE) {
            desired.add(mc.options.keyUp);
            if (p.onGround() && p.horizontalCollision) desired.add(mc.options.keyJump);
        } else if (p.getAttackStrengthScale(0.5F) >= 0.95F) {
            mc.gameMode.attack(p, target);
            p.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
        }
        return true;
    }

    private Mob nearestHostile(double range, boolean needSight) {
        Mob best = null;
        double bestDist = range;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Mob mob) || !(mob instanceof Enemy) || !mob.isAlive()) continue;
            double d = mob.distanceTo(mc.player);
            if (d > bestDist) continue;
            if (needSight && !mc.player.hasLineOfSight(mob)) continue;
            bestDist = d;
            best = mob;
        }
        return best;
    }

    private Creeper nearestDangerousCreeper() {
        Creeper best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Creeper c) || !c.isAlive()) continue;
            double d = c.distanceTo(mc.player);
            if (d > 7) continue;
            if (c.getSwelling(1.0F) <= 0 && d > 3.5) continue;
            if (d < bestDist) {
                bestDist = d;
                best = c;
            }
        }
        return best;
    }

    private void runAwayFrom(Entity danger) {
        Vec3 me = mc.player.position();
        Vec3 away = me.subtract(danger.position());
        if (away.lengthSqr() < 1.0E-4) away = new Vec3(1, 0, 0);
        Vec3 point = me.add(away.normalize().scale(5));
        lookAt(new Vec3(point.x, mc.player.getEyeY(), point.z));
        desired.add(mc.options.keyUp);
        if (mc.player.onGround() && mc.player.horizontalCollision) desired.add(mc.options.keyJump);
    }

    private boolean selectShield() {
        if (mc.player.getOffhandItem().getItem() instanceof ShieldItem) {
            selectWeapon();
            return true;
        }
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getItem(i).getItem() instanceof ShieldItem) {
                mc.player.getInventory().setSelectedSlot(i);
                return true;
            }
        }
        return false;
    }

    private void selectWeapon() {
        int bestSlot = -1;
        double best = 0;
        for (int i = 0; i < 9; i++) {
            net.minecraft.world.item.ItemStack stack = mc.player.getInventory().getItem(i);
            double score = 0;
            if (com.paprika.util.ItemKinds.isSword(stack)) score = 100 + com.paprika.util.ItemKinds.attackDamage(stack);
            else if (com.paprika.util.ItemKinds.isAxe(stack)) score = 50 + com.paprika.util.ItemKinds.attackDamage(stack);
            if (score > best) {
                best = score;
                bestSlot = i;
            }
        }
        if (bestSlot >= 0) mc.player.getInventory().setSelectedSlot(bestSlot);
    }

    private boolean handleEat(boolean force) {
        if (!force && !autoEat && !eating) return false;
        FoodData food = mc.player.getFoodData();
        int stopAt = force ? 20 : 18;

        if (eating) {
            eatTicks++;
            if (food.getFoodLevel() >= stopAt || eatTicks > 300 || !selectFood()) {
                eating = false;
                return false;
            }
            desired.add(mc.options.keyUse);
            return true;
        }

        int startAt = force ? 19 : 14;
        if (food.getFoodLevel() <= startAt && selectFood()) {
            eating = true;
            eatTicks = 0;
            desired.add(mc.options.keyUse);
            return true;
        }
        return false;
    }

    private static boolean isGoodFood(ItemStack stack) {
        if (stack.isEmpty() || !stack.has(net.minecraft.core.component.DataComponents.FOOD)) return false;
        return !(stack.is(Items.ROTTEN_FLESH) || stack.is(Items.SPIDER_EYE) || stack.is(Items.POISONOUS_POTATO)
                || stack.is(Items.PUFFERFISH) || stack.is(Items.SUSPICIOUS_STEW) || stack.is(Items.CHORUS_FRUIT));
    }

    private boolean hasFood() {
        if (isGoodFood(mc.player.getOffhandItem())) return true;
        for (int i = 0; i < 9; i++) if (isGoodFood(mc.player.getInventory().getItem(i))) return true;
        return false;
    }

    private boolean selectFood() {
        for (int i = 0; i < 9; i++) {
            if (isGoodFood(mc.player.getInventory().getItem(i))) {
                mc.player.getInventory().setSelectedSlot(i);
                return true;
            }
        }
        if (isGoodFood(mc.player.getOffhandItem())) {
            ItemStack main = mc.player.getMainHandItem();
            if (main.has(net.minecraft.core.component.DataComponents.FOOD) || main.getItem() instanceof ShieldItem) return false;
            return true;
        }
        return false;
    }

    private void lookAt(Vec3 target) {
        Vec3 eye = mc.player.getEyePosition();
        double dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90.0F;
        float pitch = (float) -(Mth.atan2(dy, h) * Mth.RAD_TO_DEG);
        mc.player.setYRot(yaw);
        mc.player.setXRot(Mth.clamp(pitch, -90.0F, 90.0F));
        mc.player.setYHeadRot(yaw);
    }

    private void applyKeys() {
        for (KeyMapping k : pressed) {
            if (!desired.contains(k)) k.setDown(false);
        }
        for (KeyMapping k : desired) k.setDown(true);
        pressed.clear();
        pressed.addAll(desired);
    }

    public List<AABB> espBlocks() {
        List<AABB> list = new ArrayList<>();
        if ((task == Task.MINE || task == Task.MINE_AREA) && mineTarget != null) list.add(new AABB(mineTarget));
        if (task == Task.FILL_AREA && fillTarget != null) list.add(new AABB(fillTarget));
        if (task == Task.CROP_FARM && cropTarget != null) list.add(new AABB(cropTarget));
        if (task == Task.GOTO_POS && gotoPos != null) list.add(new AABB(gotoPos));
        return list;
    }

    public Entity espEntity() {
        if (task == Task.FARM) return farmTarget;
        return (task == Task.GOTO_ENTITY || task == Task.FOLLOW) ? targetEntity : null;
    }
}
