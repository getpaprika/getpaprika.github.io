package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import net.minecraft.client.Minecraft;

public class NoFallModule extends Module {
    public NoFallModule() {
        super("NoFall", "Disables fall damage", Category.PLAYER);
    }

    public static boolean shouldSpoof() {
        if (!ModuleManager.isOn(NoFallModule.class)) return false;
        Minecraft mc = Minecraft.getInstance();
        if (!mc.isSameThread() || mc.player == null) return false;
        if (mc.player.isFallFlying()) return false;
        return mc.player.fallDistance > 0.5F;
    }
}
