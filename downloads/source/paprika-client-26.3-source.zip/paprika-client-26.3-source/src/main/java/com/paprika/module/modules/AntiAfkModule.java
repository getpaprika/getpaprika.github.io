package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class AntiAfkModule extends Module {
    private boolean holding;

    public AntiAfkModule() {
        super("AntiAfk", "Keeps jumping so you don't get kicked for AFK", Category.PLAYER);
    }

    @Override
    protected void onDisable() {
        if (holding) mc.options.keyJump.setDown(false);
        holding = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        boolean hold = mc.gui.screen() == null;
        if (hold != holding) {
            mc.options.keyJump.setDown(hold);
            holding = hold;
        }
    }
}
