package com.paprika.mixin;

import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.paprika.render.MarkerRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererCaptureMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void paprika$capture(GraphicsResourceAllocator allocator, boolean outline, CameraRenderState camera,
                                 GpuBufferSlice fog, Vector4f fogColor, boolean sky, boolean consistentDepth,
                                 CallbackInfo ci) {
        MarkerRenderer.capture(camera.viewRotationMatrix, camera.projectionMatrix, camera.pos);
    }
}
