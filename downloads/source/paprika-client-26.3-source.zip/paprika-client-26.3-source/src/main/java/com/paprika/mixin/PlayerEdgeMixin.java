package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.AntiEdgeFallModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public abstract class PlayerEdgeMixin {
    @Inject(method = "isStayingOnGroundSurface", at = @At("HEAD"), cancellable = true)
    private void paprika$antiEdgeFall(CallbackInfoReturnable<Boolean> cir) {
        if (ModuleManager.isOn(AntiEdgeFallModule.class) && (Object) this == Minecraft.getInstance().player) {
            cir.setReturnValue(true);
        }
    }
}
