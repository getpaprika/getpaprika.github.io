package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.XrayModule;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public abstract class BlockMixin {
    @Inject(method = "shouldRenderFace", at = @At("HEAD"), cancellable = true)
    private static void paprika$xray(BlockState state, BlockState neighbor, Direction face,
                                     CallbackInfoReturnable<Boolean> cir) {
        if (ModuleManager.isOn(XrayModule.class)) {
            cir.setReturnValue(XrayModule.isVisible(state));
        }
    }
}
