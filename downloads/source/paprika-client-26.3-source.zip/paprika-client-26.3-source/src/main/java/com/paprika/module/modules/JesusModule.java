package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class JesusModule extends Module {
    public JesusModule() {
        super("Jesus", "Walk on water (sneak to go under)", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        if (mc.player.isInWater() && !mc.player.isShiftKeyDown()) {
            Vec3 v = mc.player.getDeltaMovement();
            mc.player.setDeltaMovement(v.x, 0.11, v.z);
        }
    }

    public static boolean shouldWalkOn(BlockState state, BlockGetter level, BlockPos pos) {
        if (mc.player == null) return false;
        if (!state.getFluidState().is(FluidTags.WATER)) return false;
        if (mc.player.isShiftKeyDown() || mc.player.isInWater()) return false;
        return level.getFluidState(pos.above()).isEmpty();
    }
}
