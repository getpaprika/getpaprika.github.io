package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class AntiSpamModule extends Module {
    public AntiSpamModule() {
        super("AntiSpam", "Repeated chat messages show once with a counter (x2, x3...)", Category.UTILITY);
    }
}
