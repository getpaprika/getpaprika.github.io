package com.paprika.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.math.BigDecimal;
import java.util.Locale;

public class NumberSetting extends Setting {
    private final double def, min, max, step;
    private final String unit;
    private double value;

    public NumberSetting(String name, String description, double def, double min, double max, double step, String unit) {
        super(name, description);
        this.def = def;
        this.min = min;
        this.max = max;
        this.step = step;
        this.unit = unit;
        this.value = def;
    }

    public double get() { return value; }
    public int getInt() { return (int) Math.round(value); }
    public double min() { return min; }
    public double max() { return max; }

    public void set(double v) {
        v = Math.max(min, Math.min(max, v));
        if (step > 0) v = min + Math.round((v - min) / step) * step;
        value = Math.max(min, Math.min(max, v));
    }

    public double fraction() { return max == min ? 0 : (value - min) / (max - min); }

    public void setFraction(double f) { set(min + f * (max - min)); }

    public String display() {
        String n = step >= 1 && Math.abs(value - Math.round(value)) < 1e-9
                ? String.valueOf(Math.round(value))
                : new BigDecimal(String.format(Locale.ROOT, "%.2f", value)).stripTrailingZeros().toPlainString();
        return n + unit;
    }

    @Override public void reset() { value = def; }
    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement json) { set(json.getAsDouble()); }
}
