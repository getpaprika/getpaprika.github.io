package com.paprika.mixin;

import com.paprika.module.modules.ReachModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public abstract class ReachMixin {
    @Inject(method = "blockInteractionRange", at = @At("RETURN"), cancellable = true, require = 0)
    private void paprika$blockReach(CallbackInfoReturnable<Double> cir) {
        ReachModule r = ReachModule.active();
        if (r != null && (Object) this == Minecraft.getInstance().player) cir.setReturnValue(Math.max(cir.getReturnValue(), r.block.get()));
    }

    @Inject(method = "entityInteractionRange", at = @At("RETURN"), cancellable = true, require = 0)
    private void paprika$entityReach(CallbackInfoReturnable<Double> cir) {
        ReachModule r = ReachModule.active();
        if (r != null && (Object) this == Minecraft.getInstance().player) cir.setReturnValue(Math.max(cir.getReturnValue(), r.entity.get()));
    }
}
