package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.EntityCullingModule;
import com.paprika.module.modules.XrayModule;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockEntityRenderDispatcher.class)
public abstract class BlockEntityRenderDispatcherMixin {
    @Inject(method = "tryExtractRenderState", at = @At("HEAD"), cancellable = true)
    private void paprika$hideBlockEntities(BlockEntity blockEntity, float partialTick,
                                           net.minecraft.client.renderer.feature.ModelFeatureRenderer.CrumblingOverlay crumbling,
                                           boolean globallyRendered,
                                           org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Object> cir) {
        if (ModuleManager.isOn(XrayModule.class)) {
            if (!XrayModule.isVisible(blockEntity.getBlockState())) cir.setReturnValue(null);
            return;
        }
        if (ModuleManager.isOn(EntityCullingModule.class)
                && !EntityCullingModule.isBlockEntityVisible(blockEntity.getBlockPos())) {
            cir.setReturnValue(null);
        }
    }
}
