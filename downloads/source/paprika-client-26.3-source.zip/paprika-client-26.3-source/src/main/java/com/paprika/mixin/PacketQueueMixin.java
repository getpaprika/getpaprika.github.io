package com.paprika.mixin;

import com.paprika.network.PacketQueue;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Connection.class)
public abstract class PacketQueueMixin {
    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void paprika$hold(Packet<?> packet, CallbackInfo ci) {
        if (PacketQueue.intercept((Connection) (Object) this, packet)) ci.cancel();
    }
}
