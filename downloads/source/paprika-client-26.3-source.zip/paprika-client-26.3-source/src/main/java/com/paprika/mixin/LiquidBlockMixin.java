package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.JesusModule;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LiquidBlock.class)
public abstract class LiquidBlockMixin {
    @Unique
    private static final VoxelShape PAPRIKA_WATER_TOP = Shapes.box(0, 0, 0, 1, 0.9, 1);

    @Inject(method = "getCollisionShape", at = @At("HEAD"), cancellable = true)
    private void paprika$jesus(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context,
                               CallbackInfoReturnable<VoxelShape> cir) {
        if (!ModuleManager.isOn(JesusModule.class)) return;
        if (!(context instanceof EntityCollisionContext ec)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || ec.getEntity() != mc.player) return;
        if (JesusModule.shouldWalkOn(state, level, pos)) {
            cir.setReturnValue(PAPRIKA_WATER_TOP);
        }
    }
}
