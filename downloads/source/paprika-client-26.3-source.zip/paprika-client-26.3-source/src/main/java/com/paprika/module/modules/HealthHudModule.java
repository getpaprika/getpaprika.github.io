package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class HealthHudModule extends Module {
    public HealthHudModule() {
        super("HealthHUD", "Shows other players' health next to their name tag", Category.RENDER);
    }
}
