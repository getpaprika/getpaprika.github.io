package com.paprika.mixin;

import com.paprika.module.modules.NewChunksModule;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public abstract class NewChunksMixin {
    @Inject(method = "handleBlockUpdate", at = @At("TAIL"))
    private void paprika$blockUpdate(ClientboundBlockUpdatePacket packet, CallbackInfo ci) {
        NewChunksModule.onBlockUpdate(packet.getPos(), packet.getBlockState());
    }

    @Inject(method = "handleChunkBlocksUpdate", at = @At("TAIL"))
    private void paprika$sectionUpdate(ClientboundSectionBlocksUpdatePacket packet, CallbackInfo ci) {
        packet.runUpdates(NewChunksModule::onBlockUpdate);
    }

    @Inject(method = "handleLevelChunkWithLight", at = @At("TAIL"))
    private void paprika$chunkLoad(ClientboundLevelChunkWithLightPacket packet, CallbackInfo ci) {
        NewChunksModule.onChunkLoad(packet.x(), packet.z());
    }
}
