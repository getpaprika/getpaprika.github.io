package com.paprika.module.modules;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

public final class AimSmoother {
    private static final Random RANDOM = new Random();

    private static LivingEntity target;
    private static double strength;
    private static double offeredAngle;
    private static long offeredAt;
    private static long lastFrame;
    private static double time;
    private static double seedA = RANDOM.nextDouble() * 100, seedB = RANDOM.nextDouble() * 100, seedC = RANDOM.nextDouble() * 100;
    private static LivingEntity lastTarget;

    private static double spotX, spotY, spotZ;
    private static long spotPickedAt;
    private static final long SPOT_EVERY_MS = 2000;

    private AimSmoother() {}

    public static void offer(LivingEntity e, double str, double angle) {
        long now = System.currentTimeMillis();
        boolean fresh = now - offeredAt > 40;
        if (fresh || angle < offeredAngle) {
            target = e;
            strength = str;
            offeredAngle = angle;
            offeredAt = now;
        }
    }

    private static double wave(double speed, double seed) {
        return Math.sin(time * speed + seed);
    }

    public static void frame() {
        long now = System.nanoTime();
        double dt = lastFrame == 0 ? 0 : Math.min(0.05, (now - lastFrame) / 1.0E9);
        lastFrame = now;
        time += dt;

        Minecraft mc = Minecraft.getInstance();
        LivingEntity t = target;
        if (t == null || mc.player == null || mc.gui.screen() != null || dt <= 0) return;
        if (System.currentTimeMillis() - offeredAt > 120 || !t.isAlive()) {
            target = null;
            return;
        }
        long nowMs = System.currentTimeMillis();
        if (t != lastTarget || nowMs - spotPickedAt >= SPOT_EVERY_MS) {
            if (t != lastTarget) {
                lastTarget = t;
                seedA = RANDOM.nextDouble() * 100;
                seedB = RANDOM.nextDouble() * 100;
                seedC = RANDOM.nextDouble() * 100;
            }

            spotX = RANDOM.nextDouble() * 1.6 - 0.8;
            spotZ = RANDOM.nextDouble() * 1.6 - 0.8;
            spotY = 0.15 + RANDOM.nextDouble() * 0.8;
            spotPickedAt = nowMs;
        }

        double h = t.getBbHeight(), w = t.getBbWidth() / 2.0;
        Vec3 aim = new Vec3(
                t.getX() + w * (spotX + 0.05 * wave(1.3, seedA)),
                t.getY() + h * (spotY + 0.03 * wave(0.9, seedB)),
                t.getZ() + w * (spotZ + 0.05 * wave(1.1, seedC)));
        Vec3 eye = mc.player.getEyePosition();
        Vec3 to = aim.subtract(eye);
        float wantYaw = (float) (Mth.atan2(to.z, to.x) * Mth.RAD_TO_DEG) - 90.0F;
        float wantPitch = (float) -(Mth.atan2(to.y, Math.sqrt(to.x * to.x + to.z * to.z)) * Mth.RAD_TO_DEG);
        double dYaw = Mth.wrapDegrees(wantYaw - mc.player.getYRot());
        double dPitch = wantPitch - mc.player.getXRot();
        double dist = Math.sqrt(dYaw * dYaw + dPitch * dPitch);
        if (dist < 0.8 + 0.6 * (0.5 + 0.5 * wave(2.3, seedB))) return;

        double drift = 0.7 + 0.3 * (0.5 + 0.5 * wave(2.1, seedA)) + 0.2 * (0.5 + 0.5 * wave(3.7, seedC));
        double speed = strength * 2.3 * Math.pow(dist, 0.75) * drift;
        double step = Math.min(dist, speed * dt);
        double stepYaw = dYaw / dist * step;
        double stepPitch = dPitch / dist * step * (0.75 + 0.1 * wave(1.7, seedC));

        double f = mc.options.sensitivity().get() * 0.6 + 0.2;
        double gcd = f * f * f * 8.0 * 0.15;
        stepYaw = Math.round(stepYaw / gcd) * gcd;
        stepPitch = Math.round(stepPitch / gcd) * gcd;
        if (stepYaw == 0 && stepPitch == 0) return;
        mc.player.turn(stepYaw / 0.15, stepPitch / 0.15);
    }
}
