package com.paprika.module.modules;

import com.paprika.module.ModuleManager;
import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;

public class BoatFlyModule extends Module {
    public final NumberSetting speed = number("Speed", "How fast the boat flies", 25, 1, 200, 1, " blocks/s");

    public static double speedPerTick() {
        BoatFlyModule m = ModuleManager.get(BoatFlyModule.class);
        return (m == null ? 25 : m.speed.get()) / 20.0;
    }

    public BoatFlyModule() {
        super("BoatFly", "Fly your boat where you look by holding W", Category.MOVEMENT);
    }
}
