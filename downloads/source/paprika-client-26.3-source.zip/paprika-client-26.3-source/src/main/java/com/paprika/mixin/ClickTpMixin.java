package com.paprika.mixin;

import com.paprika.module.modules.ClickTpModule;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public abstract class ClickTpMixin {
    @Inject(method = "startAttack", at = @At("HEAD"), cancellable = true)
    private void paprika$clickTp(CallbackInfoReturnable<Boolean> cir) {
        ClickTpModule tp = ClickTpModule.active();
        if (tp != null) {
            tp.teleport();
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "continueAttack", at = @At("HEAD"), cancellable = true)
    private void paprika$noMining(boolean leftClick, CallbackInfo ci) {
        if (ClickTpModule.active() != null) ci.cancel();
    }
}
