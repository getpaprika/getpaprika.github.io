package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.NumberSetting;

public class BlockOutlineModule extends Module {
    public final NumberSetting red = number("Red", "Red part of the color", 255, 0, 255, 1, "");
    public final NumberSetting green = number("Green", "Green part of the color", 43, 0, 255, 1, "");
    public final NumberSetting blue = number("Blue", "Blue part of the color", 43, 0, 255, 1, "");
    public final BoolSetting fill = bool("Fill", "Fill the block with the color at 50% see-through", true);

    public BlockOutlineModule() {
        super("BlockOutline", "Colored outline + fill on the block you look at (pick the color yourself)", Category.RENDER);
    }

    public int rgb() {
        return (red.getInt() << 16) | (green.getInt() << 8) | blue.getInt();
    }
}
