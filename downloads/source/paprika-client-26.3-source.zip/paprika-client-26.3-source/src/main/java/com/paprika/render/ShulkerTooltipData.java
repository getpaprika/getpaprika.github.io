package com.paprika.render;

import net.minecraft.core.NonNullList;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;

public record ShulkerTooltipData(NonNullList<ItemStack> items) implements TooltipComponent {
}
