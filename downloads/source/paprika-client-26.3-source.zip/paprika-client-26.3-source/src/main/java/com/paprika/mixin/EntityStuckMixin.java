package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.AntiCobwebModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityStuckMixin {
    @Inject(method = "makeStuckInBlock", at = @At("HEAD"), cancellable = true)
    private void paprika$antiCobweb(BlockState state, Vec3 motionMultiplier, CallbackInfo ci) {
        if (!ModuleManager.isOn(AntiCobwebModule.class)) return;
        if ((Object) this != Minecraft.getInstance().player) return;
        if (state.is(Blocks.COBWEB)) ci.cancel();
    }
}
