package com.paprika.module.modules;

import com.paprika.module.setting.ModeSetting;
import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.entity.player.Player;

public class PKillAuraModule extends Module {
    public final NumberSetting reach = number("Reach", "How far you hit (normal survival reach is 3)", 3, 1, 6, 0.1, " blocks");
    public final ModeSetting mode = mode("Mode", "Obvious: hits through walls without looking. Legit: only what you can see, turns your head/body to it (camera stays)", KillAura.OBVIOUS, KillAura.OBVIOUS, KillAura.LEGIT);
    public final NumberSetting randomDelay = number("Random delay", "Waits a random time before each hit, from 0 up to this (so hits are never evenly timed)", 0, 0, 1000, 5, " ms");
    private final RandomDelay delay = new RandomDelay();

    public PKillAuraModule() {
        super("PKillAura", "Automatically hits players in reach when your attack is recharged", Category.COMBAT);
    }

    @Override
    public void onTick() {
        KillAura.tick(e -> e instanceof Player p && !com.paprika.module.modules.BlinkModule.isClone(p) && !p.isSpectator() && !p.isCreative() && !com.paprika.command.Friends.is(p), reach.get(), mode.is(KillAura.LEGIT), delay, randomDelay.get());
    }
}
