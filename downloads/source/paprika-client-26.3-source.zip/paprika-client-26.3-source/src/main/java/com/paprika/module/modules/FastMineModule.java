package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.NumberSetting;

public class FastMineModule extends Module {
    public final NumberSetting speed = number("Speed", "Mining speed multiplier. Above 1x blocks may come back on normal servers", 1.0, 1.0, 3.0, 0.1, "x");
    public final BoolSetting safe = bool("Safe break", "Break at 70% mined - the most normal servers accept (about 1.4x faster)", true);

    public FastMineModule() {
        super("FastMine", "Mine blocks faster in survival (like Haste)", Category.PLAYER);
    }

    @Override
    public String warning() {
        return "MAY NOT WORK!";
    }

    public static FastMineModule active() {
        FastMineModule f = ModuleManager.get(FastMineModule.class);
        return f != null && f.isEnabled() ? f : null;
    }
}
