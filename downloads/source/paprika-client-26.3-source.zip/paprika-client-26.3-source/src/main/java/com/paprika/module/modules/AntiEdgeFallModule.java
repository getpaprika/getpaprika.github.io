package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class AntiEdgeFallModule extends Module {
    public AntiEdgeFallModule() {
        super("AntiEdgeFall", "Stops you walking off edges without crouching", Category.MOVEMENT);
    }
}
