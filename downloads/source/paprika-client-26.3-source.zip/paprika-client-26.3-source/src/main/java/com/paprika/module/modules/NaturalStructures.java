package com.paprika.module.modules;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

final class NaturalStructures {
    private NaturalStructures() {}

    record Structure(String name, Predicate<Map<String, Integer>> signature, List<String> palette) {}

    record Result(boolean base, boolean guaranteed, String structure, List<String> clues) {}

    static final List<String> HOME_BLOCKS = List.of("crafting_table", "furnace", "*_bed", "anvil", "chipped_anvil",
            "damaged_anvil", "*_door", "ladder", "hopper", "piston", "sticky_piston", "observer");

    static final String VILLAGER = "#villager";

    private static final List<String> WOOD = List.of("*_planks", "*_log", "*_wood", "*_stairs", "*_slab", "*_fence",
            "*_fence_gate", "*_trapdoor", "*_door");

    private static List<String> with(List<String> a, String... more) {
        List<String> l = new ArrayList<>(a);
        l.addAll(List.of(more));
        return l;
    }

    private static int c(Map<String, Integer> m, String pattern) {
        int n = 0;
        for (Map.Entry<String, Integer> e : m.entrySet()) if (match(e.getKey(), pattern)) n += e.getValue();
        return n;
    }

    private static final String[] JOB_BLOCKS = {"composter", "lectern", "smoker", "blast_furnace", "cartography_table",
            "fletching_table", "grindstone", "loom", "smithing_table", "stonecutter", "brewing_stand", "barrel"};

    static final List<Structure> ALL = List.of(
            new Structure("mineshaft", m -> c(m, "rail") >= 3 || c(m, "cobweb") >= 3,
                    List.of("rail", "cobweb", "*_planks", "*_fence", "*_log", "spawner", "chain")),
            new Structure("dungeon", m -> c(m, "spawner") >= 1 && (c(m, "mossy_cobblestone") >= 1 || c(m, "cobblestone") >= 5),
                    List.of("cobblestone", "mossy_cobblestone", "spawner")),
            new Structure("desert temple", m -> c(m, "orange_terracotta") >= 1 || (c(m, "chiseled_sandstone") >= 1 && c(m, "cut_sandstone") >= 1),
                    List.of("*sandstone*", "orange_terracotta", "blue_terracotta", "tnt", "stone_pressure_plate", "chest", "suspicious_sand")),
            new Structure("jungle temple", m -> c(m, "mossy_cobblestone") >= 5
                    && (c(m, "tripwire_hook") + c(m, "sticky_piston") + c(m, "chiseled_stone_bricks")) >= 1,
                    List.of("cobblestone", "mossy_cobblestone", "*cobblestone_stairs", "*cobblestone_wall", "*stone_brick*",
                            "chiseled_stone_bricks", "lever", "tripwire", "tripwire_hook", "dispenser", "redstone_wire",
                            "sticky_piston", "piston", "piston_head", "repeater", "vine", "chest")),
            new Structure("village", m -> {
                int jobs = 0;
                for (String j : JOB_BLOCKS) jobs += c(m, j) > 0 ? 1 : 0;
                return c(m, "bell") >= 1 || jobs >= 2 || (c(m, "dirt_path") >= 10 && c(m, "*_bed") >= 1)
                        || (c(m, VILLAGER) >= 1 && c(m, "dirt_path") >= 3);
            }, with(WOOD, "*_bed", "glass", "glass_pane", "*stained_glass*", "torch", "wall_torch", "lantern", "crafting_table",
                    "furnace", "chest", "barrel", "bell", "composter", "lectern", "smoker", "blast_furnace", "cartography_table",
                    "fletching_table", "grindstone", "loom", "smithing_table", "stonecutter", "brewing_stand", "cauldron",
                    "water_cauldron", "hay_block", "farmland", "wheat", "carrots", "potatoes", "beetroots", "cobblestone*",
                    "mossy_cobblestone*", "*stone_brick*", "*_wool", "*_carpet", "*terracotta", "bookshelf", "flower_pot",
                    "potted_*", "dirt_path", "*_wall", "bricks", "brick_*", "smooth_stone*", "*_sign", "*_wall_sign",
                    "*_banner", "*_wall_banner", "ladder", "jack_o_lantern", "carved_pumpkin", "*sandstone*", "*_pressure_plate",
                    "*_button", "anvil", "chipped_anvil", "damaged_anvil", "lever", "*_glazed_terracotta")),
            new Structure("witch hut", m -> c(m, "cauldron") + c(m, "water_cauldron") >= 1 && c(m, "spruce_planks") >= 5,
                    List.of("spruce_*", "oak_log", "crafting_table", "cauldron", "water_cauldron", "flower_pot", "potted_*",
                            "*_fence", "glass_pane")),
            new Structure("ruined portal", m -> c(m, "crying_obsidian") >= 1
                    || (c(m, "obsidian") >= 1 && (c(m, "gold_block") + c(m, "magma_block") + c(m, "netherrack")) >= 1),
                    List.of("obsidian", "crying_obsidian", "netherrack", "magma_block", "gold_block", "*stone_brick*", "chest",
                            "iron_bars", "*blackstone*", "vine", "*_stairs", "*_slab", "*_wall")),
            new Structure("shipwreck", m -> c(m, "water") >= 20 && (c(m, "*_planks") + c(m, "*_log") + c(m, "*_stairs")
                    + c(m, "*_slab") + c(m, "*_fence") + c(m, "*_trapdoor")) >= 10,
                    with(WOOD, "chest", "seagrass", "tall_seagrass", "kelp", "kelp_plant")),
            new Structure("igloo", m -> (c(m, "snow_block") >= 10 && c(m, "*_carpet") >= 1)
                    || (c(m, "brewing_stand") >= 1 && c(m, "iron_bars") >= 1 && c(m, "cauldron") >= 1),
                    List.of("snow_block", "white_carpet", "red_carpet", "light_gray_carpet", "*_carpet", "red_bed", "furnace",
                            "crafting_table", "redstone_torch", "redstone_wall_torch", "*stone_brick*", "iron_bars", "cauldron",
                            "water_cauldron", "brewing_stand", "chest", "ladder", "polished_andesite", "cobweb", "*_trapdoor",
                            "spruce_planks", "*_sign", "*_wall_sign", "*_stairs", "*_slab")),
            new Structure("pillager outpost / mansion", m -> c(m, "dark_oak_log") >= 5 && (c(m, "dark_oak_fence") + c(m, "dark_oak_planks")) >= 5,
                    with(WOOD, "cobblestone*", "chest", "*_banner", "*_wall_banner", "torch", "wall_torch", "pumpkin",
                            "carved_pumpkin", "*_wool", "*_carpet", "*_bed", "bookshelf", "glass", "glass_pane", "*stained_glass*",
                            "crafting_table", "furnace", "lantern", "cauldron", "flower_pot", "potted_*", "*_wall", "*terracotta",
                            "smooth_stone*", "cobweb", "ladder", "*_sign", "*_wall_sign", "scaffolding", "target", "*_pressure_plate",
                            "lever", "*_button", "chest")),
            new Structure("stronghold", m -> c(m, "end_portal_frame") >= 1 || c(m, "infested_*brick*") >= 1
                    || (c(m, "mossy_stone_bricks") + c(m, "cracked_stone_bricks")) >= 10,
                    List.of("*stone_brick*", "chiseled_stone_bricks", "infested_*", "iron_bars", "iron_door", "oak_door",
                            "bookshelf", "oak_planks", "cobweb", "torch", "wall_torch", "ladder", "oak_fence", "oak_slab",
                            "smooth_stone_slab", "stone_button", "end_portal_frame", "end_portal", "chest", "spawner",
                            "cobblestone*", "*_stairs", "stone_slab")),
            new Structure("nether fortress", m -> c(m, "nether_bricks") >= 20,
                    List.of("nether_brick*", "nether_wart", "chest", "spawner")),
            new Structure("bastion", m -> c(m, "polished_blackstone_bricks") >= 20 || c(m, "gilded_blackstone") >= 1,
                    List.of("*blackstone*", "gilded_blackstone", "chain", "lantern", "soul_lantern", "gold_block", "chest",
                            "*basalt", "crying_obsidian", "obsidian")),
            new Structure("end city", m -> c(m, "purpur_block") >= 20,
                    List.of("purpur*", "end_stone_brick*", "end_rod", "magenta_stained_glass*", "brewing_stand", "chest",
                            "ladder", "dragon_head", "dragon_wall_head")),
            new Structure("ocean ruin / monument", m -> c(m, "prismarine*") >= 10
                    || (c(m, "water") >= 30 && (c(m, "*stone_brick*") + c(m, "*sandstone*")) >= 5),
                    List.of("prismarine*", "dark_prismarine*", "sea_lantern", "wet_sponge", "sponge", "gold_block",
                            "*stone_brick*", "*sandstone*", "magma_block", "chest", "seagrass", "tall_seagrass", "kelp", "kelp_plant",
                            "suspicious_gravel", "suspicious_sand")),
            new Structure("ancient city", m -> c(m, "reinforced_deepslate") >= 1 || c(m, "sculk_shrieker") >= 1
                    || c(m, "deepslate_tiles") >= 20,
                    List.of("*deepslate*", "sculk*", "soul_lantern", "soul_fire", "*candle*", "*_wool", "*_carpet", "chest",
                            "skeleton_skull", "skeleton_wall_skull", "*basalt", "soul_sand", "lantern", "dark_oak_*", "*_ladder",
                            "ladder", "redstone_lamp", "comparator", "redstone_wire", "*_trapdoor", "*_fence", "*_stairs", "*_slab")),
            new Structure("trial chambers", m -> c(m, "trial_spawner") >= 1 || c(m, "vault") >= 1 || c(m, "tuff_bricks") >= 20,
                    List.of("*tuff*", "*copper*", "trial_spawner", "vault", "decorated_pot", "chest", "barrel", "dispenser",
                            "dropper", "hopper", "redstone*", "*candle*", "heavy_core", "*_wool", "*_carpet", "*_stairs", "*_slab",
                            "glass", "*_bulb", "*_grate", "*_trapdoor", "*_door", "scaffolding", "ladder")),
            new Structure("buried treasure", m -> c(m, "chest") == 1 && (c(m, "sand") + c(m, "sandstone") + c(m, "gravel")) >= 8,
                    List.of("chest"))
    );

    static boolean match(String path, String pattern) {
        boolean start = pattern.startsWith("*"), end = pattern.endsWith("*");
        if (start && end && pattern.length() > 2) return path.contains(pattern.substring(1, pattern.length() - 1));
        if (start) return path.endsWith(pattern.substring(1));
        if (end) return path.startsWith(pattern.substring(0, pattern.length() - 1));
        return path.equals(pattern);
    }

    private static final List<String> TERRAIN = List.of("*_ore", "air", "cave_air", "void_air", "water", "lava", "bedrock",
            "obsidian", "gravel", "clay", "sandstone", "red_sandstone", "calcite", "dripstone_block", "pointed_dripstone",
            "amethyst_block", "budding_amethyst", "*amethyst_bud", "amethyst_cluster", "smooth_basalt", "glow_lichen", "vine",
            "hanging_roots", "spore_blossom", "*dripleaf*", "moss_block", "moss_carpet", "azalea", "flowering_azalea",
            "*_mushroom", "*mushroom_block", "mushroom_stem", "*grass*", "*fern", "dead_bush", "sugar_cane", "cactus",
            "bamboo*", "kelp*", "*seagrass", "sea_pickle", "lily_pad", "pumpkin", "melon", "sweet_berry_bush", "fire",
            "soul_fire", "bubble_column", "sculk", "sculk_vein", "sculk_sensor", "mud", "*mangrove_roots", "*_stem",
            "weeping_vines*", "twisting_vines*", "nether_sprouts", "*_roots", "*_fungus", "shroomlight", "*wart_block",
            "glowstone", "magma_block", "soul_sand", "soul_soil", "basalt", "end_stone", "chorus*", "powder_snow",
            "ancient_debris", "infested_stone", "infested_deepslate", "suspicious_*", "frogspawn", "*_egg", "cocoa",
            "big_dripleaf_stem", "cave_vines*", "netherrack", "blackstone", "crimson_nylium", "warped_nylium", "tuff", "deepslate");

    static boolean isTerrain(BlockState state, String path) {
        if (state.is(BlockTags.LEAVES) || state.is(BlockTags.LOGS) || state.is(BlockTags.BASE_STONE_OVERWORLD)
                || state.is(BlockTags.BASE_STONE_NETHER) || state.is(BlockTags.DIRT) || state.is(BlockTags.SAND)
                || state.is(BlockTags.ICE) || state.is(BlockTags.FLOWERS) || state.is(BlockTags.SAPLINGS)
                || state.is(BlockTags.CORALS) || state.is(BlockTags.CORAL_BLOCKS) || state.is(BlockTags.WALL_CORALS)
                || state.is(BlockTags.SNOW) || state.is(BlockTags.NYLIUM) || state.is(BlockTags.TERRACOTTA)) return true;
        for (String p : TERRAIN) if (match(path, p)) return true;
        return false;
    }

    private static double weight(String path) {
        if (path.endsWith("shulker_box")) return 6;
        if (path.equals("chest") || path.equals("trapped_chest") || path.equals("barrel") || path.equals("ender_chest")
                || path.endsWith("_bed")) return 3;
        if (path.equals("crafting_table") || path.equals("furnace") || path.equals("blast_furnace") || path.equals("smoker")
                || path.contains("anvil") || path.equals("enchanting_table") || path.equals("hopper") || path.equals("beacon")) return 2;
        if (path.endsWith("torch") || path.equals("ladder") || path.equals("rail")) return 0.25;
        return 1;
    }

    static Result classify(Map<String, Integer> counts, Map<String, Boolean> terrain, int armorStands, int itemFrames) {
        return classify(counts, terrain, armorStands, itemFrames, false);
    }

    static Result classify(Map<String, Integer> counts, Map<String, Boolean> terrain, int armorStands, int itemFrames,
                           boolean chestBase) {
        List<Structure> matched = new ArrayList<>();
        for (Structure s : ALL) if (s.signature().test(counts)) matched.add(s);

        double evidence = 0;
        boolean guaranteed = false;
        List<String> clues = new ArrayList<>();
        for (Map.Entry<String, Integer> e : counts.entrySet()) {
            String path = e.getKey();
            if (path.startsWith("#") || Boolean.TRUE.equals(terrain.get(path))) continue;
            boolean explained = false;
            for (Structure s : matched) {
                for (String p : s.palette()) {
                    if (match(path, p)) {
                        explained = true;
                        break;
                    }
                }
                if (explained) break;
            }
            if (explained) continue;
            boolean chest = path.equals("chest") || path.equals("trapped_chest");
            if (chest && (!chestBase || c(counts, "spawner") > 0)) continue;
            for (String h : HOME_BLOCKS) if (match(path, h)) guaranteed = true;
            evidence += weight(path) * e.getValue();
            clues.add(path.replace('_', ' '));
        }
        boolean endCity = matched.stream().anyMatch(s -> s.name().equals("end city"));
        evidence += armorStands * 3.0;
        if (!endCity) evidence += itemFrames * 3.0;
        if (armorStands > 0) clues.add("armor stand");
        if (itemFrames > 0 && !endCity) clues.add("item frame");

        String structure = matched.isEmpty() ? null : matched.get(0).name();
        return new Result(evidence >= 3 || guaranteed, guaranteed, structure, clues);
    }

    private static boolean explained(String path, List<Structure> matched) {
        for (Structure s : matched) for (String p : s.palette()) if (match(path, p)) return true;
        return false;
    }
}
