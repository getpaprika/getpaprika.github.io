package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class TracersEModule extends Module {
    public TracersEModule() {
        super("TracersE", "Lines to passive mobs (same color as ESPE)", Category.RENDER);
    }
}
