package com.paprika.module.modules;

public final class KillAuraFacing {
    private KillAuraFacing() {}

    public static void tick() { KillAura.keepFacing(); }

    public static boolean active() { return KillAura.facing(); }

    public static float yaw() { return KillAura.faceYaw(); }

    public static float pitch() { return KillAura.facePitch(); }
}
