package com.paprika.module.modules;

import com.paprika.Config;
import com.paprika.command.Areas;
import com.paprika.command.Markers;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

public class DeathWModule extends Module {
    private static final String MARKER = "Death";
    private boolean wasDead;

    public DeathWModule() {
        super("DeathW", "Marks where you died and tells you in chat", Category.UTILITY);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;

        boolean dead = mc.player.isDeadOrDying();
        if (dead && !wasDead) {
            BlockPos p = mc.player.blockPosition();
            String dim = Areas.currentDim();
            Markers.put(new Markers.Marker(MARKER, dim, p.getX() + 0.5, p.getY(), p.getZ() + 0.5, 0xFF0000));
            Config.save();
            mc.player.sendSystemMessage(Component.literal("[DeathW] ").withStyle(ChatFormatting.RED)
                    .append(Component.literal("You died at " + p.getX() + " " + p.getY() + " " + p.getZ()
                            + " in the " + worldName(dim)).withStyle(ChatFormatting.WHITE)));
        }
        wasDead = dead;
        if (dead) return;

        for (Markers.Marker m : Markers.current()) {
            if (!m.name().equals(MARKER)) continue;
            if (mc.player.position().distanceTo(new Vec3(m.x(), m.y(), m.z())) <= 3.0) {
                Markers.remove(MARKER);
                Config.save();
                mc.player.sendSystemMessage(Component.literal("[DeathW] ").withStyle(ChatFormatting.RED)
                        .append(Component.literal("You reached your death point").withStyle(ChatFormatting.WHITE)));
            }
            break;
        }
    }

    private static String worldName(String dim) {
        return switch (dim) {
            case "minecraft:overworld" -> "Overworld";
            case "minecraft:the_nether" -> "Nether";
            case "minecraft:the_end" -> "End";
            default -> dim;
        };
    }
}
