package com.paprika.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

public final class RenderUtil {
    private RenderUtil() {}

    public static float partialTick(LevelRenderContext ctx) {
        return Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);
    }

    public static Matrix4f viewMatrix(Camera camera) {
        return new Matrix4f();
    }

    public static Matrix4f cameraRotation(Camera camera) {
        return new Matrix4f().rotation(camera.rotation().conjugate(new Quaternionf()));
    }

    public static PoseStack worldPose(Camera camera) {
        return new PoseStack();
    }

    public static void beginWorld() {}

    public static void endWorld() {}
}
