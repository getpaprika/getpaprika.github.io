package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class NoWeatherModule extends Module {
    public NoWeatherModule() {
        super("NoWeather", "Removes rain, snow and thunder", Category.RENDER);
    }
}
