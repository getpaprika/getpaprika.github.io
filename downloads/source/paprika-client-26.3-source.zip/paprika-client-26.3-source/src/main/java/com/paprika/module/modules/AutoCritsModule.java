package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;

public class AutoCritsModule extends Module {
    private static boolean stoppedSprint;

    public AutoCritsModule() {
        super("AutoCrits", "Every sword/axe hit becomes a critical hit", Category.COMBAT);
    }

    public static void beforeAttack(Entity target) {
        stoppedSprint = false;
        if (mc.player == null || mc.getConnection() == null) return;
        if (!(target instanceof LivingEntity)) return;

        net.minecraft.world.item.ItemStack held = mc.player.getMainHandItem();
        if (!(com.paprika.util.ItemKinds.isSword(held) || com.paprika.util.ItemKinds.isAxe(held))) return;

        if (!mc.player.onGround() || mc.player.isInWater() || mc.player.isInLava()
                || mc.player.onClimbable() || mc.player.isPassenger()
                || mc.player.hasEffect(MobEffects.BLINDNESS)) return;

        if (mc.player.isSprinting()) {
            mc.getConnection().send(new ServerboundPlayerCommandPacket(mc.player,
                    ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
            stoppedSprint = true;
        }

        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        mc.getConnection().send(new ServerboundMovePlayerPacket.Pos(x, y + 0.0625, z, false, false));
        mc.getConnection().send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
    }

    public static void afterAttack() {
        if (stoppedSprint && mc.player != null && mc.getConnection() != null) {
            mc.getConnection().send(new ServerboundPlayerCommandPacket(mc.player,
                    ServerboundPlayerCommandPacket.Action.START_SPRINTING));
        }
        stoppedSprint = false;
    }
}
