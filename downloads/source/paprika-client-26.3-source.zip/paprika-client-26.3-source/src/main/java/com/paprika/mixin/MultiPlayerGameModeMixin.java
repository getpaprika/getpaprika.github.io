package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.AutoCritsModule;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "attack", at = @At("HEAD"))
    private void paprika$critBefore(Player player, Entity target, CallbackInfo ci) {
        if (ModuleManager.isOn(AutoCritsModule.class)) AutoCritsModule.beforeAttack(target);
    }

    @Inject(method = "attack", at = @At("TAIL"))
    private void paprika$critAfter(Player player, Entity target, CallbackInfo ci) {
        if (ModuleManager.isOn(AutoCritsModule.class)) AutoCritsModule.afterAttack();
    }
}
