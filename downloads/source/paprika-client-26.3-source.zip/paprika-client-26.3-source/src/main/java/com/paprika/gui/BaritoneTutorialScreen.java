package com.paprika.gui;

import com.paprika.Config;
import com.paprika.PaprikaClient;
import com.paprika.module.modules.BaritoneModule;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public class BaritoneTutorialScreen extends Screen {
    private static final int PANEL_BG     = 0x66000000;
    private static final int PANEL_BORDER = 0x88FF2B2B;
    private static final int BTN          = 0x803A7BFF;
    private static final int BTN_HOVER    = 0xA05A90FF;
    private static final int WHITE        = 0xFFFFFFFF;
    private static final int GRAY         = 0xFFAAAAAA;

    private static final int HEADER_H = 22;
    private static final int LINE_H = 11;
    private static final int PAD = 12;
    private static final int BTN_W = 80;
    private static final int BTN_H = 20;

    private static final ItemStack RED_DYE = new ItemStack(Items.DYE.red());

    private record Line(FormattedCharSequence text, int color) {}

    private final List<Line> lines = new ArrayList<>();
    private int px, py, pw, ph;
    private int scroll;

    public BaritoneTutorialScreen() {
        super(Component.literal("Baritone"));
    }

    @Override
    protected void init() {
        pw = Math.min(400, width - 20);
        ph = Math.min(280, height - 20);
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        lines.clear();
        title("Welcome to Baritone!");
        blank();
        text("To use Baritone, here are some commands you can use in chat:");
        blank();
        section("— Movement");
        command("#b goto x y z", "Pathfinds to the specific coordinates");
        command("#b goto [player/entity]", "Pathfinds to the specific player/entity");
        command("#b gotomarker [name]", "Pathfinds to one of your markers (press M to make markers)");
        command("#b follow [player/entity]", "Pathfinds and follows the player/entity until you use #b stop");
        command("#b stop", "Stops all current tasks");
        blank();
        section("— Mining");
        command("#b mine [block]", "Pathfinds to the closest block and mines it until you stop");
        command("#b minea", "Mines everything inside your areas (make areas with #a)");
        command("#b fillawith [block]", "Fills your areas with a block from your inventory");
        blank();
        section("— Farm");
        command("#b farm", "Plants seeds on all farmland within 64 blocks, grows them with bone meal, harvests, collects and repeats");
        command("#b farm [entity]", "Pathfinds to the nearest entity that you requested, kills it and picks up its loot (more at once: #b farm cow, pig, chicken)");
        blank();
        section("— Settings");
        command("#b avoidDanger", "Toggles if Baritone encounters hostiles during a task it will first kill them before continuing");
        command("#b autoEat", "Toggles during a task Baritone will eat when low on hunger");
        blank();
        section("— Other");
        command("#b tutorial", "Go back to this tutorial page");
        clampScroll();
    }

    private int wrapWidth() {
        return pw - PAD * 2;
    }

    private void add(Component c, int color) {
        for (FormattedCharSequence s : font.split(c, wrapWidth())) lines.add(new Line(s, color));
    }

    private void title(String s) {
        add(Component.literal(s).withStyle(ChatFormatting.BOLD), PaprikaClient.RED);
    }

    private void section(String s) {
        add(Component.literal(s).withStyle(ChatFormatting.BOLD), PaprikaClient.RED);
    }

    private void text(String s) {
        add(Component.literal(s), WHITE);
    }

    private void command(String cmd, String what) {
        add(Component.literal(cmd).withStyle(ChatFormatting.AQUA)
                .append(Component.literal(" - " + what).withStyle(ChatFormatting.WHITE)), WHITE);
    }

    private void blank() {
        lines.add(new Line(FormattedCharSequence.EMPTY, WHITE));
    }

    private int contentTop() {
        return py + HEADER_H + 6;
    }

    private int contentBottom() {
        return py + ph - 6;
    }

    private int contentHeight() {
        return lines.size() * LINE_H + 10 + BTN_H + 4;
    }

    private int maxScroll() {
        return Math.max(0, contentHeight() - (contentBottom() - contentTop()));
    }

    private void clampScroll() {
        scroll = Math.max(0, Math.min(scroll, maxScroll()));
    }

    private int buttonX() {
        return px + (pw - BTN_W) / 2;
    }

    private int buttonY() {
        return contentTop() + lines.size() * LINE_H + 10 - scroll;
    }

    private boolean overButton(double mx, double my) {
        int bx = buttonX(), by = buttonY();
        return mx >= bx && mx < bx + BTN_W && my >= by && my < by + BTN_H
                && my >= contentTop() && my < contentBottom();
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0xFF000000);

        g.fill(px, py, px + pw, py + ph, PANEL_BG);
        outline(g, px, py, pw, ph, PANEL_BORDER);
        g.item(RED_DYE, px + 4, py + 3);
        g.text(font, "Paprika Client - Baritone", px + 22, py + 7, PaprikaClient.RED, true);
        g.fill(px, py + HEADER_H, px + pw, py + HEADER_H + 1, PANEL_BORDER);
        if (scroll < maxScroll()) {
            g.text(font, "scroll ↓", px + pw - 50, py + 7, GRAY, false);
        }

        int top = contentTop(), bottom = contentBottom();
        g.enableScissor(px + 1, top, px + pw - 1, bottom);
        int y = top - scroll;
        for (Line line : lines) {
            if (y + LINE_H >= top && y <= bottom) {
                g.text(font, line.text(), px + PAD, y, line.color(), true);
            }
            y += LINE_H;
        }

        int bx = buttonX(), by = buttonY();
        boolean hover = overButton(mouseX, mouseY);
        g.fill(bx, by, bx + BTN_W, by + BTN_H, hover ? BTN_HOVER : BTN);
        g.centeredText(font, "OK", bx + BTN_W / 2, by + 6, WHITE);
        g.disableScissor();

        super.extractRenderState(g, mouseX, mouseY, partialTick);
    }

    private static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double delta) {
        scroll -= (int) (delta * LINE_H * 3);
        clampScroll();
        return true;
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent paprika$e, boolean paprika$dbl) {
        double mouseX = paprika$e.x(), mouseY = paprika$e.y();
        int button = paprika$glfwButton(paprika$e.button());
        if (button == 0 && overButton(mouseX, mouseY)) {
            if (minecraft != null) {
                minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
            }
            BaritoneModule.markTutorialSeen();
            Config.save();
            onClose();
            return true;
        }
        return super.mouseClicked(paprika$e, paprika$dbl);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static int paprika$glfwButton(int sdl) {
        return switch (sdl) { case 1 -> 0; case 3 -> 1; case 2 -> 2; default -> sdl - 1; };
    }
}
