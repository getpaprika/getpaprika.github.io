package com.paprika.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.List;

public class ModeSetting extends Setting {
    private final List<String> options;
    private final String def;
    private String value;

    public ModeSetting(String name, String description, String def, String... options) {
        super(name, description);
        this.options = List.of(options);
        this.def = def;
        this.value = def;
    }

    public String get() { return value; }
    public boolean is(String option) { return value.equalsIgnoreCase(option); }
    public List<String> options() { return options; }

    public void cycle() {
        int i = options.indexOf(value);
        value = options.get((i + 1) % options.size());
    }

    @Override public void reset() { value = def; }
    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement json) {
        for (String o : options) if (o.equalsIgnoreCase(json.getAsString())) value = o;
    }
}
