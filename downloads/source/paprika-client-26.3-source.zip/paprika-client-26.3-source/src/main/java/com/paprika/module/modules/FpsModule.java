package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class FpsModule extends Module {
    public FpsModule() {
        super("FPS", "Shows your FPS on screen", Category.RENDER);
    }

    @Override
    public int onRender(GuiGraphicsExtractor graphics, int x, int y) {
        graphics.text(mc.font, "FPS: " + mc.getFps(), x, y, 0xFFFFFFFF, true);
        return mc.font.lineHeight + 2;
    }
}
