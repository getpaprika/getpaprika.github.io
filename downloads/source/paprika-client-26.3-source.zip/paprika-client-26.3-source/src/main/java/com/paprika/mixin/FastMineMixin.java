package com.paprika.mixin;

import com.paprika.module.modules.FastMineModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MultiPlayerGameMode.class)
public abstract class FastMineMixin {
    @Shadow @Final private Minecraft minecraft;
    @Shadow private BlockPos destroyBlockPos;
    @Shadow private float destroyProgress;
    @Shadow private boolean isDestroying;

    @Inject(method = "continueDestroyBlock", at = @At("HEAD"))
    private void paprika$fastMine(BlockPos pos, Direction face, CallbackInfoReturnable<Boolean> cir) {
        FastMineModule fm = FastMineModule.active();
        if (fm == null || !isDestroying || !pos.equals(destroyBlockPos)) return;
        if (minecraft.player == null || minecraft.level == null || minecraft.player.isCreative()) return;
        BlockState state = minecraft.level.getBlockState(pos);
        float perTick = state.getDestroyProgress(minecraft.player, minecraft.level, pos);
        if (perTick <= 0) return;
        destroyProgress += perTick * (float) (fm.speed.get() - 1.0);
        if (fm.safe.get() && destroyProgress + perTick >= 0.72F) {
            destroyProgress = Math.max(destroyProgress, 1.001F - perTick);
        }
    }
}
