package com.paprika.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

public final class Ui {
    public static final Style SMOOTH = Style.EMPTY.withFont(new net.minecraft.network.chat.FontDescription.Resource(Identifier.fromNamespaceAndPath("paprika", "smooth")));

    private Ui() {}

    private static final Identifier RED_DYE_TEXTURE = Identifier.withDefaultNamespace("textures/item/red_dye.png");

    public static void redDye(GuiGraphicsExtractor g, int x, int y) {
        g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, RED_DYE_TEXTURE, x, y, 0, 0, 16, 16, 16, 16);
    }

    public static Component text(String s) {
        return Component.literal(s).withStyle(SMOOTH);
    }

    public static int width(Font font, String s) {
        return font.width(text(s));
    }

    public static void draw(GuiGraphicsExtractor g, Font font, String s, int x, int y, int color) {
        g.text(font, text(s), x, y, color, false);
    }

    public static void centered(GuiGraphicsExtractor g, Font font, String s, int cx, int y, int color) {
        draw(g, font, s, cx - width(font, s) / 2, y, color);
    }

    private static int inset(int r, int i) {
        double dy = r - i - 0.5;
        return (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
    }

    public static void round(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, color); return; }
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            g.fill(x + in, y + i, x + w - in, y + i + 1, color);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
    }

    public static void roundTop(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w / 2, h));
        if (r <= 0) { g.fill(x, y, x + w, y + h, color); return; }
        g.fill(x, y + r, x + w, y + h, color);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            g.fill(x + in, y + i, x + w - in, y + i + 1, color);
        }
    }

    public static void roundBottom(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w / 2, h));
        if (r <= 0) { g.fill(x, y, x + w, y + h, color); return; }
        g.fill(x, y, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
    }

    public static void trash(GuiGraphicsExtractor g, int x, int y, boolean hover) {
        int c = hover ? 0xFFFF5555 : 0xFFDD2222;
        g.fill(x + 4, y, x + 8, y + 1, c);
        g.fill(x + 1, y + 1, x + 11, y + 3, c);
        g.fill(x + 2, y + 3, x + 10, y + 4, c);
        g.fill(x + 2, y + 4, x + 3, y + 12, c);
        g.fill(x + 9, y + 4, x + 10, y + 12, c);
        g.fill(x + 2, y + 11, x + 10, y + 12, c);
        g.fill(x + 4, y + 5, x + 5, y + 10, c);
        g.fill(x + 7, y + 5, x + 8, y + 10, c);
    }

    public static void circle(GuiGraphicsExtractor g, int cx, int cy, int r, int color) {
        round(g, cx - r, cy - r, r * 2 + 1, r * 2 + 1, r + 1, color);
    }
}
