package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.NoSlowModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntitySpeedMixin {
    @Inject(method = "getBlockSpeedFactor", at = @At("HEAD"), cancellable = true)
    private void paprika$noSlowBlocks(CallbackInfoReturnable<Float> cir) {
        if ((Object) this == Minecraft.getInstance().player && ModuleManager.isOn(NoSlowModule.class)) {
            cir.setReturnValue(1.0F);
        }
    }
}
