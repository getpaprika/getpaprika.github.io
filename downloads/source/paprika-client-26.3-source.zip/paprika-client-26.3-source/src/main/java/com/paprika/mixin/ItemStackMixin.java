package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.ShulkerBoxTooltipModule;
import com.paprika.render.ShulkerTooltipData;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
    @Inject(method = "getTooltipImage", at = @At("HEAD"), cancellable = true)
    private void paprika$shulkerTooltip(CallbackInfoReturnable<Optional<TooltipComponent>> cir) {
        if (!ModuleManager.isOn(ShulkerBoxTooltipModule.class)) return;
        ShulkerTooltipData data = ShulkerBoxTooltipModule.read((ItemStack) (Object) this);
        if (data != null) {
            cir.setReturnValue(Optional.of(data));
        }
    }
}
