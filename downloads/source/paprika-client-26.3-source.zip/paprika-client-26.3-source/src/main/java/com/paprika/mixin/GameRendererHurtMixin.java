package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.NoHurtCamModule;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererHurtMixin {
    @Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true)
    private void paprika$noHurtCam(CallbackInfo ci) {
        if (ModuleManager.isOn(NoHurtCamModule.class)) ci.cancel();
    }
}
