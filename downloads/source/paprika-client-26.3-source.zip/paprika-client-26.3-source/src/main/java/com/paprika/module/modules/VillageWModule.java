package com.paprika.module.modules;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class VillageWModule extends StructureWModule {
    private static final Map<Block, String> TYPES = new LinkedHashMap<>();
    private static final String[] ORDER = {"bell", "job"};

    static {
        TYPES.put(Blocks.BELL, "bell");
        for (Block job : new Block[]{Blocks.COMPOSTER, Blocks.LECTERN, Blocks.SMOKER, Blocks.BLAST_FURNACE,
                Blocks.CARTOGRAPHY_TABLE, Blocks.FLETCHING_TABLE, Blocks.GRINDSTONE, Blocks.LOOM,
                Blocks.SMITHING_TABLE, Blocks.STONECUTTER, Blocks.BREWING_STAND, Blocks.CAULDRON, Blocks.BARREL}) {
            TYPES.put(job, "job");
        }
    }

    public VillageWModule() {
        super("VillageW", "Finds villages in loaded chunks and shows them in lime");
    }

    @Override protected Map<Block, String> types() { return TYPES; }
    @Override protected String[] order() { return ORDER; }
    @Override protected Set<String> sureTypes() { return Set.of("bell"); }
    @Override protected String specialType() { return "bell"; }
    @Override protected String specialMessage(BlockPos p) { return "Village bell at " + p.getX() + ", " + p.getY() + ", " + p.getZ() + "!"; }
    @Override protected int minBlocks() { return 8; }
    @Override protected String structureName() { return "Village"; }
    @Override protected boolean scanHere() { return mc.level.dimension() == Level.OVERWORLD; }
    @Override public int fillColor() { return 0x4D7CFC00; }
    @Override public int outlineColor() { return 0xFF7CFC00; }
    @Override public int labelColor() { return 0xFFAAFF55; }

    @Override
    protected String nice(String type, int n) {
        return n + " " + switch (type) {
            case "bell" -> n == 1 ? "bell" : "bells";
            case "job" -> n == 1 ? "job block" : "job blocks";
            default -> type;
        };
    }
}
