package com.paprika.mixin;

import com.paprika.module.modules.FreeLookModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class FreeLookTurnMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void paprika$freeLookTurn(double yRot, double xRot, CallbackInfo ci) {
        if ((Object) this != Minecraft.getInstance().player) return;
        FreeLookModule look = FreeLookModule.active();
        if (look != null) {
            look.turn(yRot, xRot);
            ci.cancel();
        }
    }
}
