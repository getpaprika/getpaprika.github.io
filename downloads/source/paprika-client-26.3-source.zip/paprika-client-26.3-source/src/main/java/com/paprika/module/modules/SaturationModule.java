package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.Locale;

public class SaturationModule extends Module {
    private static final int YELLOW = 0xFFFFFF55;

    public SaturationModule() {
        super("Saturation", "Shows your saturation above the hotbar", Category.UTILITY);
    }

    @Override
    public int onRender(GuiGraphicsExtractor graphics, int x, int y) {
        if (mc.player == null || mc.player.isCreative() || mc.player.isSpectator()) return 0;

        float sat = mc.player.getFoodData().getSaturationLevel();
        String value = sat == Math.floor(sat) ? String.valueOf((int) sat) : String.format(Locale.ROOT, "%.1f", sat);
        String text = "Saturation: " + value + "/20";

        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();

        int tx = w / 2 + 91 - mc.font.width(text);
        int ty = h - 60;
        graphics.text(mc.font, text, tx, ty, YELLOW, true);
        return 0;
    }

    @Override
    public int onRenderPreview(GuiGraphicsExtractor graphics, int x, int y) {
        if (mc.player != null && !mc.player.isCreative() && !mc.player.isSpectator()) return onRender(graphics, x, y);
        String text = "Saturation: 5.6/20";
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        graphics.text(mc.font, text, w / 2 + 91 - mc.font.width(text), h - 60, YELLOW, true);
        return 0;
    }
}
