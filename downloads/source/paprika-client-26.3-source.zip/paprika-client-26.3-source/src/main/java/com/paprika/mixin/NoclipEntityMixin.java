package com.paprika.mixin;

import com.paprika.module.modules.NoclipModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class NoclipEntityMixin {
    @Inject(method = "collide", at = @At("RETURN"), cancellable = true)
    private void paprika$noclip(Vec3 movement, CallbackInfoReturnable<Vec3> cir) {
        if (!NoclipModule.on() || (Object) this != Minecraft.getInstance().player) return;
        Vec3 blocked = cir.getReturnValue();

        double y = movement.y > 0 ? movement.y : blocked.y;
        cir.setReturnValue(new Vec3(movement.x, y, movement.z));
    }

    @Inject(method = "isInWall", at = @At("HEAD"), cancellable = true, require = 0)
    private void paprika$noSuffocation(CallbackInfoReturnable<Boolean> cir) {
        if (NoclipModule.on() && NoclipModule.isYou((Entity) (Object) this)) cir.setReturnValue(false);
    }
}
