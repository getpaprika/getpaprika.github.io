package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.render.ShulkerTooltipData;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.ShulkerBoxBlock;

public class ShulkerBoxTooltipModule extends Module {
    public ShulkerBoxTooltipModule() {
        super("ShulkerBoxTooltip", "Hover a shulker box to see its contents", Category.UTILITY);
    }

    public static ShulkerTooltipData read(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) return null;
        if (!(blockItem.getBlock() instanceof ShulkerBoxBlock)) return null;

        ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
        if (contents == null) return null;

        NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);
        contents.copyInto(items);

        boolean any = false;
        for (ItemStack s : items) if (!s.isEmpty()) { any = true; break; }
        return any ? new ShulkerTooltipData(items) : null;
    }
}
