package com.paprika.mixin;

import com.paprika.module.modules.AttackClick;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class AttackClickMixin {
    @Inject(method = "handleKeybinds", at = @At("HEAD"))
    private void paprika$aimClick(CallbackInfo ci) {
        AttackClick.beforeKeybinds();
    }
}
