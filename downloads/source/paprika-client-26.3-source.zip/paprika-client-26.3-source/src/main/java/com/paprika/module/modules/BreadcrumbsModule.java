package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BreadcrumbsModule extends Module {
    private static final Map<ResourceKey<Level>, List<Vec3>> TRAILS = new HashMap<>();
    private static ResourceKey<Level> current;
    private ClientPacketListener lastConnection;

    public BreadcrumbsModule() {
        super("Breadcrumbs", "Draws a line where you have walked (kept until you turn it off)", Category.RENDER);
    }

    public static List<Vec3> points() {
        List<Vec3> l = current == null ? null : TRAILS.get(current);
        return l == null ? List.of() : l;
    }

    @Override
    protected void onDisable() {
        TRAILS.clear();
        current = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (mc.getConnection() != lastConnection) {
            TRAILS.clear();
            lastConnection = mc.getConnection();
        }
        current = mc.level.dimension();
        List<Vec3> points = TRAILS.computeIfAbsent(current, k -> new ArrayList<>());
        Vec3 pos = mc.player.position().add(0, 0.1, 0);
        if (points.isEmpty() || points.get(points.size() - 1).distanceToSqr(pos) > 0.25) points.add(pos);
    }
}
