package com.paprika.mixin;

import com.paprika.module.modules.NoclipModule;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerGamePacketListenerImpl.class)
public abstract class NoclipServerMixin {
    @Shadow public ServerPlayer player;

    @Inject(method = "handleMovePlayer", at = @At("HEAD"))
    private void paprika$noclipServer(ServerboundMovePlayerPacket packet, CallbackInfo ci) {
        if (NoclipModule.on() && Minecraft.getInstance().hasSingleplayerServer() && NoclipModule.isYou(player)) {
            player.noPhysics = true;
        }
    }
}
