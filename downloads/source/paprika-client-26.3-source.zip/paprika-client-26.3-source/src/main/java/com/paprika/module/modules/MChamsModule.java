package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class MChamsModule extends Module {
    public MChamsModule() {
        super("MChams", "Hostile and neutral mobs get an orange glowing outline through walls", Category.RENDER);
    }
}
