package com.paprika.module.modules;

import com.paprika.command.Friends;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.villager.AbstractVillager;
import net.minecraft.world.entity.player.Player;

public final class Targets {
    private Targets() {}

    private static boolean alive(Entity e) {
        return e instanceof LivingEntity l && l.isAlive() && l.getHealth() > 0 && e != Minecraft.getInstance().player
                && !BlinkModule.isClone(e);
    }

    public static boolean player(Entity e) {
        return alive(e) && e instanceof Player p && !p.isSpectator() && !p.isCreative() && !Friends.is(p);
    }

    public static boolean passive(Entity e) {
        return alive(e) && e instanceof Mob mob && !(mob instanceof Enemy) && !(mob instanceof NeutralMob)
                && !(mob instanceof AbstractVillager)
                && !(mob instanceof TamableAnimal pet && pet.isTame())
                && !(mob instanceof AbstractHorse horse && horse.isTamed())
                && !mob.hasCustomName();
    }

    public static boolean monster(Entity e) {
        return alive(e) && (e instanceof Enemy || e instanceof NeutralMob)
                && !(e instanceof TamableAnimal pet && pet.isTame());
    }
}
