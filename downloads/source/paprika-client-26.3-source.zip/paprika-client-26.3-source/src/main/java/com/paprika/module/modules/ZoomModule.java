package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.PaprikaClient;
import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;

public class ZoomModule extends Module {
    public final NumberSetting zoom = number("Zoom", "How much it zooms in", 4, 1.5, 10, 0.5, "x");
    private static double current = 1.0;

    public ZoomModule() {
        super("Zoom", "Lets you hold Z to zoom in", Category.RENDER);
    }

    public static double fovFactor() {
        boolean zooming = ModuleManager.isOn(ZoomModule.class) && mc.gui.screen() == null
                && PaprikaClient.zoomKey != null && PaprikaClient.zoomKey.isDown();
        ZoomModule self = ModuleManager.get(ZoomModule.class);
        double target = zooming && self != null ? 1.0 / self.zoom.get() : 1.0;
        current += (target - current) * 0.3;
        if (Math.abs(current - target) < 0.001) current = target;
        return current;
    }
}
