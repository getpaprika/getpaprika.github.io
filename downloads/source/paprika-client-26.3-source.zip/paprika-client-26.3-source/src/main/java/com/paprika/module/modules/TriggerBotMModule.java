package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.setting.NumberSetting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;

public class TriggerBotMModule extends Module {
    public final NumberSetting randomDelay = number("Random delay", "Waits a random time before each hit, from 0 up to this (so hits are never evenly timed)", 0, 0, 1000, 5, " ms");
    private final RandomDelay delay = new RandomDelay();

    public TriggerBotMModule() {
        super("TriggerBotM", "Hits monsters and neutral mobs when your crosshair is on them", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null || mc.gui.screen() != null || mc.player.isUsingItem()) return;
        if (!(mc.hitResult instanceof EntityHitResult hit)) return;
        Entity e = hit.getEntity();
        if (!Targets.monster(e)) return;
        if (mc.player.getAttackStrengthScale(0.0F) < 1.0F) {
            delay.reset();
            return;
        }
        if (!delay.passed(randomDelay.get())) return;
        AttackClick.request(e);
    }
}
