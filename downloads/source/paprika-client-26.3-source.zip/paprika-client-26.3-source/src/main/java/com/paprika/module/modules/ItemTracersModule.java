package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class ItemTracersModule extends Module {
    public ItemTracersModule() {
        super("ItemTracers", "Purple lines to dropped items", Category.RENDER);
    }
}
