package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.setting.NumberSetting;
import com.paprika.network.PacketQueue;

public class FakeLagModule extends Module {
    public final NumberSetting delay = number("Delay", "How late your packets arrive", 200, 10, 1000, 10, " ms");

    public FakeLagModule() {
        super("FakeLag", "Makes you look laggy to other players", Category.MOVEMENT);
    }

    @Override
    public boolean shouldSave() {
        return false;
    }

    public static boolean active() {
        return ModuleManager.isOn(FakeLagModule.class) && mc.player != null;
    }

    @Override
    public void onTick() {
        if (mc.getConnection() == null) {
            PacketQueue.clear();
            return;
        }
        PacketQueue.flushLag(delay.getInt(), false);
    }

    @Override
    protected void onDisable() {
        PacketQueue.flushLag(0, true);
    }
}
