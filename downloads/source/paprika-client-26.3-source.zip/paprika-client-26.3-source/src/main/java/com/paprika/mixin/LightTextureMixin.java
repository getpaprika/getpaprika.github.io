package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.FullbrightModule;
import com.paprika.module.modules.XrayModule;
import net.minecraft.client.renderer.LightmapRenderStateExtractor;
import net.minecraft.client.renderer.state.LightmapRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LightmapRenderStateExtractor.class)
public abstract class LightTextureMixin {
    @Inject(method = "extract", at = @At("TAIL"))
    private void paprika$fullbright(LightmapRenderState state, float partialTicks, CallbackInfo ci) {
        if (ModuleManager.isOn(FullbrightModule.class) || ModuleManager.isOn(XrayModule.class)) {
            state.nightVisionEffectIntensity = 1.0F;
        }
    }
}
