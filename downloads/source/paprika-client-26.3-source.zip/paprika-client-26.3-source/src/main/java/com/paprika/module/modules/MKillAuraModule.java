package com.paprika.module.modules;

import com.paprika.module.setting.ModeSetting;
import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.monster.Enemy;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class MKillAuraModule extends Module {
    private static final Set<Integer> AGGRESSORS = ConcurrentHashMap.newKeySet();

    public final NumberSetting reach = number("Reach", "How far you hit (normal survival reach is 3)", 3, 1, 6, 0.1, " blocks");
    public final ModeSetting mode = mode("Mode", "Obvious: hits through walls without looking. Legit: only what you can see, turns your head/body to it (camera stays)", KillAura.OBVIOUS, KillAura.OBVIOUS, KillAura.LEGIT);
    public final NumberSetting randomDelay = number("Random delay", "Waits a random time before each hit, from 0 up to this (so hits are never evenly timed)", 0, 0, 1000, 5, " ms");
    private final RandomDelay delay = new RandomDelay();

    public MKillAuraModule() {
        super("MKillAura", "Hits hostile mobs, and neutral mobs only after they hit you", Category.COMBAT);
    }

    public static void hurtBy(int entityId) {
        if (entityId < 0) return;
        if (AGGRESSORS.size() > 200) AGGRESSORS.clear();
        AGGRESSORS.add(entityId);
    }

    @Override
    protected void onDisable() {
        AGGRESSORS.clear();
    }

    @Override
    public void onTick() {
        if (mc.level == null) return;
        AGGRESSORS.removeIf(id -> {
            Entity e = mc.level.getEntity(id);
            return e == null || !e.isAlive();
        });
        KillAura.tick(e -> {
            if (e instanceof NeutralMob) return AGGRESSORS.contains(e.getId());
            return e instanceof Enemy;
        }, reach.get(), mode.is(KillAura.LEGIT), delay, randomDelay.get());
    }
}
