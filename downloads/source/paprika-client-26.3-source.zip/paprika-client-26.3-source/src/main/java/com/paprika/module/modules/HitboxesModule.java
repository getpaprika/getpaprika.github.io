package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.setting.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class HitboxesModule extends Module {
    public final NumberSetting size = number("Size", "How much bigger hitboxes are (on every side)", 0.3, 0.1, 1.0, 0.05, " blocks");

    public HitboxesModule() {
        super("Hitboxes", "Makes other players' and mobs' hitboxes bigger", Category.COMBAT);
    }

    public static float extra(Entity e) {
        HitboxesModule h = ModuleManager.get(HitboxesModule.class);
        if (h == null || !h.isEnabled() || !(e instanceof LivingEntity) || e == Minecraft.getInstance().player || BlinkModule.isClone(e)) return -1;
        return (float) h.size.get();
    }
}
