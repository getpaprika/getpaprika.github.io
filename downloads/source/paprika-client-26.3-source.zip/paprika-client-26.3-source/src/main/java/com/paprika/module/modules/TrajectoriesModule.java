package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.EggItem;
import net.minecraft.world.item.EnderpearlItem;
import net.minecraft.world.item.ExperienceBottleItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SnowballItem;
import net.minecraft.world.item.ThrowablePotionItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TrajectoriesModule extends Module {
    public TrajectoriesModule() {
        super("Trajectories", "Shows where your projectile will fly and land", Category.RENDER);
    }

    public record Path(List<Vec3> points, AABB hit) {}

    private record Kind(double speed, double gravity, double drag, double waterDrag, float pitchOffset) {}

    private static Kind kindOf(ItemStack stack, Player player) {
        Item item = stack.getItem();
        if (item instanceof BowItem) {
            float power = player.isUsingItem() && player.getUseItem() == stack
                    ? BowItem.getPowerForTime(player.getTicksUsingItem()) : 1.0F;
            return new Kind(Math.max(power, 0.1F) * 3.0, 0.05, 0.99, 0.6, 0);
        }
        if (item instanceof CrossbowItem) return CrossbowItem.isCharged(stack) ? new Kind(3.15, 0.05, 0.99, 0.6, 0) : null;
        if (item instanceof TridentItem) return new Kind(2.5, 0.05, 0.99, 0.99, 0);
        if (item instanceof SnowballItem || item instanceof EggItem || item instanceof EnderpearlItem) {
            return new Kind(1.5, 0.03, 0.99, 0.8, 0);
        }
        if (item instanceof ThrowablePotionItem) return new Kind(0.5, 0.05, 0.99, 0.8, -20.0F);
        if (item instanceof ExperienceBottleItem) return new Kind(0.7, 0.07, 0.99, 0.8, -20.0F);
        return null;
    }

    public static Path compute(float partialTick) {
        Player player = mc.player;
        if (player == null || mc.level == null) return null;
        ItemStack stack = player.getMainHandItem();
        Kind kind = kindOf(stack, player);
        if (kind == null) {
            stack = player.getOffhandItem();
            kind = kindOf(stack, player);
        }
        if (kind == null) return null;

        float yaw = player.getViewYRot(partialTick);
        float pitch = player.getViewXRot(partialTick);
        double x = -Mth.sin(yaw * Mth.DEG_TO_RAD) * Mth.cos(pitch * Mth.DEG_TO_RAD);
        double y = -Mth.sin((pitch + kind.pitchOffset()) * Mth.DEG_TO_RAD);
        double z = Mth.cos(yaw * Mth.DEG_TO_RAD) * Mth.cos(pitch * Mth.DEG_TO_RAD);
        Vec3 vel = new Vec3(x, y, z).normalize().scale(kind.speed());
        Vec3 own = player.getDeltaMovement();
        vel = vel.add(own.x, player.onGround() ? 0.0 : own.y, own.z);

        Vec3 pos = new Vec3(Mth.lerp(partialTick, player.xo, player.getX()),
                Mth.lerp(partialTick, player.yo, player.getY()) + player.getEyeHeight() - 0.1,
                Mth.lerp(partialTick, player.zo, player.getZ()));

        List<Vec3> points = new ArrayList<>();
        points.add(pos);
        AABB hit = null;
        for (int t = 0; t < 300; t++) {
            Vec3 next = pos.add(vel);

            BlockHitResult blockHit = mc.level.clip(new ClipContext(pos, next, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, player));
            if (blockHit.getType() != HitResult.Type.MISS) next = blockHit.getLocation();

            if (t > 1) {
                AABB sweep = new AABB(pos, next).inflate(1.0);
                double bestDist = Double.MAX_VALUE;
                Entity hitEntity = null;
                Vec3 hitPos = null;
                for (Entity e : mc.level.getEntities(player, sweep, en -> en instanceof LivingEntity && en.isAlive())) {
                    Optional<Vec3> clip = e.getBoundingBox().inflate(0.3).clip(pos, next);
                    if (clip.isPresent() && pos.distanceToSqr(clip.get()) < bestDist) {
                        bestDist = pos.distanceToSqr(clip.get());
                        hitEntity = e;
                        hitPos = clip.get();
                    }
                }
                if (hitEntity != null) {
                    points.add(hitPos);
                    return new Path(points, hitEntity.getBoundingBox());
                }
            }

            points.add(next);
            if (blockHit.getType() != HitResult.Type.MISS) {
                BlockPos b = blockHit.getBlockPos();
                hit = new AABB(b);
                break;
            }
            pos = next;
            boolean inWater = mc.level.getFluidState(BlockPos.containing(pos)).is(FluidTags.WATER);
            vel = vel.scale(inWater ? kind.waterDrag() : kind.drag()).subtract(0, kind.gravity(), 0);
            if (pos.y < mc.level.getMinY() - 64) break;
        }
        return new Path(points, hit);
    }
}
