package com.paprika.baritone;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

public interface Goal {
    boolean isGoal(BlockPos feet);

    double heuristic(BlockPos feet);

    static double distance(BlockPos a, BlockPos b) {
        double dx = a.getX() - b.getX(), dy = a.getY() - b.getY(), dz = a.getZ() - b.getZ();
        return Math.sqrt(dx * dx + dz * dz) + Math.abs(dy);
    }

    record Block(BlockPos pos) implements Goal {
        public boolean isGoal(BlockPos feet) { return feet.equals(pos); }
        public double heuristic(BlockPos feet) { return distance(feet, pos); }
    }

    record Near(BlockPos pos, int radius) implements Goal {
        public boolean isGoal(BlockPos feet) { return feet.distSqr(pos) <= (double) radius * radius; }
        public double heuristic(BlockPos feet) { return Math.max(0, distance(feet, pos) - radius); }
    }

    record Adjacent(BlockPos target) implements Goal {
        public boolean isGoal(BlockPos feet) { return isAdjacent(feet, target); }
        public double heuristic(BlockPos feet) { return Math.max(0, distance(feet, target) - 1); }
    }

    record Reach(BlockPos target) implements Goal {
        public boolean isGoal(BlockPos feet) {
            if (feet.equals(target) || feet.above().equals(target)) return false;

            double dx = feet.getX() - target.getX(), dy = feet.getY() + 1.62 - (target.getY() + 0.5), dz = feet.getZ() - target.getZ();
            return dx * dx + dy * dy + dz * dz <= 3.5 * 3.5;
        }
        public double heuristic(BlockPos feet) { return Math.max(0, distance(feet, target) - 3); }
    }

    static boolean isAdjacent(BlockPos feet, BlockPos target) {
        BlockPos head = feet.above();
        for (Direction d : Direction.values()) {
            if (feet.relative(d).equals(target) || head.relative(d).equals(target)) return true;
        }
        return false;
    }
}
