package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class NoHurtCamModule extends Module {
    public NoHurtCamModule() {
        super("NoHurtCam", "Removes the camera shake when you get hurt", Category.RENDER);
    }
}
