package com.paprika.gui;

import com.mojang.blaze3d.platform.InputConstants;
import com.paprika.Config;
import com.paprika.PaprikaClient;
import com.paprika.command.Friends;
import com.paprika.command.OrgSkins;
import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.modules.BaritoneModule;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ListGuiScreen extends Screen {
    private enum Page {
        MODULES("Modules"), CONFIG("Config"), CONFIGS("Presets"), GUI("GUI"), HUD("HUD"), FRIENDS("Friends");
        final String label;
        Page(String label) { this.label = label; }
    }

    private static Page page = Page.MODULES;
    private static final Category[] ORDER = {Category.COMBAT, Category.PLAYER, Category.MOVEMENT, Category.RENDER, Category.UTILITY};

    private static final int WHITE = 0xFFFFFFFF, GRAY = 0xFFA0A0A0, DIM = 0xFFB4B4B4;
    private static final int BG = 0xB8141414;
    private static final int COL_W = 96, COL_GAP = 4, HEADER = 14, ROW = 11, SEARCH_H = 14;
    private static final int TOP = 20, BOTTOM = 26;

    private String search = "";
    private String friendName = "";

    private float scale = 1;
    private float originX, originY;

    public static boolean hidesHud(Screen screen) {
        return screen instanceof ListGuiScreen || screen instanceof ModPopupScreen
                || screen instanceof HudEditorScreen
                || screen instanceof NewConfigScreen;
    }

    public ListGuiScreen() {
        super(Component.literal(PaprikaClient.NAME));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
    }

    private int[] barX() {
        int[] x = new int[Page.values().length + 1];
        int total = 0;
        for (Page p : Page.values()) total += Ui.width(font, p.label) + 10;
        int cx = (width - total) / 2;
        for (int i = 0; i < Page.values().length; i++) {
            x[i] = cx;
            cx += Ui.width(font, Page.values()[i].label) + 10;
        }
        x[Page.values().length] = cx;
        return x;
    }

    private void drawTopBar(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        Theme theme = Theme.current();
        int[] x = barX();
        Ui.round(g, x[0] - 4, 2, x[x.length - 1] - x[0] + 8, 15, 5, BG);
        for (int i = 0; i < Page.values().length; i++) {
            Page p = Page.values()[i];
            boolean hover = inside(mouseX, mouseY, x[i], 2, x[i + 1] - x[i], 14);
            int color = p == page ? theme.accentArgb(0xFF) : hover ? WHITE : GRAY;
            Ui.draw(g, font, p.label, x[i] + 5, 5, color);
            if (p == page) g.fill(x[i] + 4, 15, x[i + 1] - 4, 16, theme.accentArgb(0xFF));
        }
    }

    private List<Module> searchResults() {
        List<Module> out = new ArrayList<>();
        String q = search.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return out;
        for (Module m : ModuleManager.getModules()) if (m.getName().toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        return out;
    }

    private int maxRows() {
        int rows = 0;
        for (Category c : ORDER) rows = Math.max(rows, ModuleManager.getByCategory(c).size());
        return Math.max(rows, 1);
    }

    private void layout() {
        int columns = ORDER.length + 1;
        float naturalW = columns * COL_W + (columns - 1) * COL_GAP;
        float naturalH = HEADER + maxRows() * ROW + 2;
        float availW = width - 16, availH = height - TOP - BOTTOM;
        scale = Math.min(1.0F, Math.min(availW / naturalW, availH / naturalH));
        originX = width - naturalW * scale - 8;
        originY = TOP + 2;
    }

    private int colX(int i) { return i * (COL_W + COL_GAP); }

    private double lx(double mouseX) { return (mouseX - originX) / scale; }
    private double ly(double mouseY) { return (mouseY - originY) / scale; }

    private Module moduleAt(double mouseX, double mouseY) {
        double x = lx(mouseX), y = ly(mouseY);
        for (int c = 0; c < ORDER.length; c++) {
            if (x < colX(c) || x >= colX(c) + COL_W) continue;
            List<Module> mods = ModuleManager.getByCategory(ORDER[c]);
            int row = (int) Math.floor((y - HEADER) / ROW);
            if (y >= HEADER && row >= 0 && row < mods.size()) return mods.get(row);
            return null;
        }
        int sc = ORDER.length;
        if (x >= colX(sc) && x < colX(sc) + COL_W) {
            List<Module> res = searchResults();
            int row = (int) Math.floor((y - HEADER - SEARCH_H) / ROW);
            if (y >= HEADER + SEARCH_H && row >= 0 && row < res.size()) return res.get(row);
        }
        return null;
    }

    private void drawModules(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        Theme theme = Theme.current();
        layout();
        Module hovered = moduleAt(mouseX, mouseY);
        int rows = maxRows();
        g.pose().pushMatrix();
        g.pose().translate((float) (originX), (float) (originY));
        g.pose().scale((float) (scale), (float) (scale));

        for (int c = 0; c <= ORDER.length; c++) {
            int x = colX(c);
            boolean searchCol = c == ORDER.length;
            Ui.roundTop(g, x, 0, COL_W, HEADER, 4, theme.accentArgb(0xD8));
            Ui.centered(g, font, searchCol ? "Search" : ORDER[c].displayName, x + COL_W / 2, 3, WHITE);
            List<Module> mods;
            int top = HEADER;
            if (searchCol) {
                Ui.roundBottom(g, x, HEADER, COL_W, SEARCH_H + searchResults().size() * ROW, 4, BG);
                Ui.round(g, x + 3, HEADER + 2, COL_W - 6, SEARCH_H - 4, 3, 0xFF0B0B0B);
                boolean cursor = (System.currentTimeMillis() / 500) % 2 == 0;
                String shown = search;
                while (Ui.width(font, shown) > COL_W - 14 && shown.length() > 1) shown = shown.substring(1);
                if (search.isEmpty()) Ui.draw(g, font, "Type to search", x + 6, HEADER + 3, 0xFF666666);
                else Ui.draw(g, font, shown + (cursor ? "_" : ""), x + 6, HEADER + 3, WHITE);
                mods = searchResults();
                top = HEADER + SEARCH_H;
            } else {
                mods = ModuleManager.getByCategory(ORDER[c]);
                Ui.roundBottom(g, x, top, COL_W, mods.size() * ROW + 2, 4, BG);
            }
            for (int i = 0; i < mods.size(); i++) {
                Module m = mods.get(i);
                int y = top + i * ROW;
                if (m.isEnabled()) {
                    g.fill(x, y, x + COL_W, y + ROW, theme.accentArgb(0x38));
                    g.fill(x + 1, y + 2, x + 3, y + ROW - 2, theme.accentArgb(0xFF));
                }
                if (m == hovered) g.fill(x, y, x + COL_W, y + ROW, 0x16FFFFFF);
                drawFitted(g, m.getName(), x + COL_W / 2, y + ROW / 2 + 1, COL_W - 6, m.isEnabled() ? WHITE : DIM);
            }
        }
        g.pose().popMatrix();

        Ui.draw(g, font, "Left click - Toggle module", 4, height - 21, GRAY);
        Ui.draw(g, font, "Right click - Open module settings", 4, height - 11, GRAY);
    }

    private record Toggle(String name, String desc, java.util.function.BooleanSupplier get, Runnable flip) {}

    private List<Toggle> toggles() {
        List<Toggle> out = new ArrayList<>();
        for (GlobalToggles.Toggle t : GlobalToggles.all()) out.add(new Toggle(t.name(), t.desc(), t.get(), t.flip()));
        return out;
    }

    private static final int PANEL_W = 240;

    private int panelX() { return (width - PANEL_W) / 2; }

    private void panel(GuiGraphicsExtractor g, int y, int h, String title) {
        Theme theme = Theme.current();
        int x = panelX();
        Ui.round(g, x, y, PANEL_W, h, 5, BG);
        Ui.roundTop(g, x, y, PANEL_W, HEADER, 5, theme.accentArgb(0xD8));
        Ui.centered(g, font, title, x + PANEL_W / 2, y + 3, WHITE);
    }

    private void drawConfig(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        Theme theme = Theme.current();
        List<Toggle> list = toggles();
        int y0 = TOP + 10, x = panelX();
        panel(g, y0, HEADER + 6 + list.size() * 20, "Config");
        String tip = null;
        for (int i = 0; i < list.size(); i++) {
            Toggle t = list.get(i);
            int y = y0 + HEADER + 4 + i * 20;
            Ui.draw(g, font, t.name(), x + 8, y + 5, WHITE);
            int bx = x + PANEL_W - 58;
            boolean hover = inside(mouseX, mouseY, bx, y + 1, 50, 16);
            boolean on = t.get().getAsBoolean();
            Ui.round(g, bx, y + 1, 50, 16, 5, on ? theme.onArgb(hover) : theme.offArgb(hover));
            Ui.centered(g, font, on ? "ON" : "OFF", bx + 25, y + 5, WHITE);
            if (inside(mouseX, mouseY, x, y, PANEL_W, 20)) tip = t.desc();
        }
        if (tip != null) g.setTooltipForNextFrame(font, Ui.text(tip), mouseX, mouseY);
    }

    private boolean clickConfig(double mouseX, double mouseY) {
        List<Toggle> list = toggles();
        int y0 = TOP + 10, x = panelX();
        for (int i = 0; i < list.size(); i++) {
            int y = y0 + HEADER + 4 + i * 20;
            if (inside(mouseX, mouseY, x + PANEL_W - 58, y + 1, 50, 16)) {
                list.get(i).flip().run();
                Config.save();
                click();
                return true;
            }
        }
        return false;
    }

    private static final int THEME_W = 74, THEME_H = 16, THEME_COLS = 3;

    private int themeX(int i) { return panelX() + 6 + (i % THEME_COLS) * (THEME_W + 4); }
    private int themeY(int i) { return TOP + 10 + HEADER + 4 + (i / THEME_COLS) * (THEME_H + 3); }
    private int styleY() { return themeY(Theme.ALL.size() - 1) + THEME_H + 8; }

    private void drawGui(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        Theme theme = Theme.current();
        int x = panelX();
        int h = styleY() + 14 + THEME_H + 6 - (TOP + 10);
        panel(g, TOP + 10, h, "Themes");
        for (int i = 0; i < Theme.ALL.size(); i++) {
            Theme t = Theme.ALL.get(i);
            int tx = themeX(i), ty = themeY(i);
            boolean hover = inside(mouseX, mouseY, tx, ty, THEME_W, THEME_H);
            Ui.round(g, tx, ty, THEME_W, THEME_H, 4, hover ? 0x30FFFFFF : 0x1AFFFFFF);
            Ui.circle(g, tx + 7, ty + 8, 3, t.accentArgb(0xFF));
            Ui.draw(g, font, t.name(), tx + 15, ty + 4, WHITE);
        }

        int sy = styleY();
        g.fill(x + 6, sy - 4, x + PANEL_W - 6, sy - 3, theme.accentArgb(0x90));
        Ui.centered(g, font, "Style", x + PANEL_W / 2, sy, theme.accentArgb(0xFF));
        String[] styles = {"Menu", "List"};
        for (int i = 0; i < 2; i++) {
            int bx = x + 6 + i * ((PANEL_W - 16) / 2 + 4), by = sy + 12, bw = (PANEL_W - 16) / 2;
            boolean hover = inside(mouseX, mouseY, bx, by, bw, THEME_H);
            Ui.round(g, bx, by, bw, THEME_H, 4, hover ? 0x30FFFFFF : 0x1AFFFFFF);
            Ui.centered(g, font, styles[i], bx + bw / 2, by + 4, WHITE);
        }
    }

    private boolean clickGui(double mouseX, double mouseY) {
        for (int i = 0; i < Theme.ALL.size(); i++) {
            if (inside(mouseX, mouseY, themeX(i), themeY(i), THEME_W, THEME_H)) {
                Theme.set(Theme.ALL.get(i));
                Config.save();
                click();
                return true;
            }
        }
        int sy = styleY(), x = panelX(), bw = (PANEL_W - 16) / 2;
        if (inside(mouseX, mouseY, x + 6, sy + 12, bw, THEME_H)) {
            GuiStyle.list = false;
            Config.save();
            click();
            if (minecraft != null) minecraft.gui.setScreen(new ClickGuiScreen());
            return true;
        }
        if (inside(mouseX, mouseY, x + 6 + bw + 4, sy + 12, bw, THEME_H)) {
            click();
            return true;
        }
        return false;
    }

    private void drawFriends(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        Theme theme = Theme.current();
        List<String> friends = Friends.all();
        int x = panelX(), y0 = TOP + 10;
        int h = HEADER + 6 + 18 + 4 + Math.max(1, friends.size()) * 14 + 4;
        panel(g, y0, h, "Friends");

        int fy = y0 + HEADER + 4;
        Ui.round(g, x + 6, fy, PANEL_W - 58, 16, 4, 0xFF0B0B0B);
        boolean cursor = (System.currentTimeMillis() / 500) % 2 == 0;
        if (friendName.isEmpty()) Ui.draw(g, font, "Type a name...", x + 10, fy + 4, 0xFF666666);
        else Ui.draw(g, font, friendName + (cursor ? "_" : ""), x + 10, fy + 4, WHITE);
        boolean overAdd = inside(mouseX, mouseY, x + PANEL_W - 48, fy, 42, 16);
        Ui.round(g, x + PANEL_W - 48, fy, 42, 16, 4, theme.onArgb(overAdd));
        Ui.centered(g, font, "Add", x + PANEL_W - 27, fy + 4, WHITE);

        int ly = fy + 22;
        if (friends.isEmpty()) Ui.draw(g, font, "No friends yet", x + 8, ly + 2, GRAY);
        for (int i = 0; i < friends.size(); i++) {
            int y = ly + i * 14;
            Ui.draw(g, font, friends.get(i), x + 8, y + 2, WHITE);
            int rx = x + PANEL_W - 18;
            boolean over = inside(mouseX, mouseY, rx, y, 12, 12);
            Ui.round(g, rx, y, 12, 12, 4, over ? 0xC0FF3333 : 0x80FF3333);
            Ui.centered(g, font, "x", rx + 6, y + 2, WHITE);
        }
    }

    private boolean clickFriends(double mouseX, double mouseY) {
        int x = panelX(), fy = TOP + 10 + HEADER + 4;
        if (inside(mouseX, mouseY, x + PANEL_W - 48, fy, 42, 16)) {
            addFriend();
            return true;
        }
        List<String> friends = Friends.all();
        int ly = fy + 22;
        for (int i = 0; i < friends.size(); i++) {
            if (inside(mouseX, mouseY, x + PANEL_W - 18, ly + i * 14, 12, 12)) {
                Friends.remove(friends.get(i));
                Config.save();
                click();
                return true;
            }
        }
        return false;
    }

    private void drawConfigs(GuiGraphicsExtractor g, int mouseX, int mouseY) {
        Theme theme = Theme.current();
        List<String> configs = com.paprika.ConfigProfiles.list();
        String active = com.paprika.ConfigProfiles.active();
        int x = panelX(), y0 = TOP + 10;
        int h = HEADER + 6 + 18 + 4 + Math.max(1, configs.size()) * 16 + 4;
        panel(g, y0, h, "Presets");
        int by = y0 + HEADER + 4;
        boolean overNew = inside(mouseX, mouseY, x + 6, by, PANEL_W - 12, 16);
        Ui.round(g, x + 6, by, PANEL_W - 12, 16, 4, theme.onArgb(overNew));
        Ui.centered(g, font, "+ New preset", x + PANEL_W / 2, by + 4, WHITE);
        int ly = by + 22;
        if (configs.isEmpty()) Ui.draw(g, font, "No presets yet. Save one with New preset.", x + 8, ly + 3, GRAY);
        for (int i = 0; i < configs.size(); i++) {
            String name = configs.get(i);
            int y = ly + i * 16;
            boolean inUse = name.equals(active);
            boolean overRow = inside(mouseX, mouseY, x + 4, y, PANEL_W - 8, 15);
            boolean overTrash = inside(mouseX, mouseY, x + PANEL_W - 20, y + 1, 12, 12);
            if (inUse) Ui.round(g, x + 4, y, PANEL_W - 8, 15, 4, 0x6033D45A);
            else if (overRow && !overTrash) Ui.round(g, x + 4, y, PANEL_W - 8, 15, 4, 0x18FFFFFF);
            Ui.draw(g, font, name, x + 10, y + 4, WHITE);
            if (inUse) Ui.draw(g, font, "in use", x + PANEL_W - 26 - Ui.width(font, "in use"), y + 4, 0xFFCCFFCC);
            Ui.trash(g, x + PANEL_W - 20, y + 1, overTrash);
        }
    }

    private boolean clickConfigs(double mouseX, double mouseY) {
        int x = panelX(), by = TOP + 10 + HEADER + 4;
        if (inside(mouseX, mouseY, x + 6, by, PANEL_W - 12, 16)) {
            click();
            if (minecraft != null) minecraft.gui.setScreen(new NewConfigScreen(this));
            return true;
        }
        List<String> configs = com.paprika.ConfigProfiles.list();
        int ly = by + 22;
        for (int i = 0; i < configs.size(); i++) {
            int y = ly + i * 16;
            if (inside(mouseX, mouseY, x + PANEL_W - 20, y + 1, 12, 12)) {
                com.paprika.ConfigProfiles.delete(configs.get(i));
                click();
                return true;
            }
            if (inside(mouseX, mouseY, x + 4, y, PANEL_W - 8, 15)) {
                com.paprika.ConfigProfiles.load(configs.get(i));
                click();
                return true;
            }
        }
        return false;
    }

    private void addFriend() {
        String n = friendName.trim();
        if (n.isEmpty()) return;
        Friends.add(n);
        friendName = "";
        Config.save();
        click();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        drawTopBar(g, mouseX, mouseY);
        switch (page) {
            case MODULES -> drawModules(g, mouseX, mouseY);
            case CONFIG -> drawConfig(g, mouseX, mouseY);
            case GUI -> drawGui(g, mouseX, mouseY);
            case FRIENDS -> drawFriends(g, mouseX, mouseY);
            case CONFIGS -> drawConfigs(g, mouseX, mouseY);
            case HUD -> { }
        }
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent paprika$e, boolean paprika$dbl) {
        double mouseX = paprika$e.x(), mouseY = paprika$e.y();
        int button = paprika$glfwButton(paprika$e.button());

        int[] x = barX();
        for (int i = 0; i < Page.values().length; i++) {
            if (button == 0 && inside(mouseX, mouseY, x[i], 2, x[i + 1] - x[i], 14)) {
                click();
                if (Page.values()[i] == Page.HUD) {
                    if (minecraft != null) minecraft.gui.setScreen(new HudEditorScreen(() -> {
                        page = Page.MODULES;
                        return new ListGuiScreen();
                    }));
                    return true;
                }
                page = Page.values()[i];
                return true;
            }
        }
        switch (page) {
            case MODULES -> {
                layout();
                Module m = moduleAt(mouseX, mouseY);
                if (m == null) return false;
                click();
                if (button == 0) {
                    m.toggle();
                    Config.save();
                } else if (button == 1 && minecraft != null) {
                    minecraft.gui.setScreen(new ModPopupScreen(m, this));
                }
                return true;
            }
            case CONFIG -> { return button == 0 && clickConfig(mouseX, mouseY); }
            case GUI -> { return button == 0 && clickGui(mouseX, mouseY); }
            case FRIENDS -> { return button == 0 && clickFriends(mouseX, mouseY); }
            case HUD -> { return false; }
            case CONFIGS -> { return button == 0 && clickConfigs(mouseX, mouseY); }
        }
        return false;
    }

    private boolean typingPage() {
        return page == Page.MODULES || page == Page.FRIENDS;
    }

    @Override
    public boolean charTyped(net.minecraft.client.input.CharacterEvent paprika$c) {
        char c = (char) paprika$c.codepoint();
        int modifiers = 0;
        if (!typingPage() || c < ' ' || c == 127) return false;
        if (page == Page.MODULES && search.length() < 32) search += c;
        if (page == Page.FRIENDS && friendName.length() < 16 && c != ' ') friendName += c;
        return true;
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent paprika$k) {
        int keyCode = paprika$k.key(), scanCode = paprika$k.keycode(), modifiers = paprika$k.modifiers();
        if (keyCode == InputConstants.KEY_BACKSPACE && typingPage()) {
            if (page == Page.MODULES && !search.isEmpty()) search = search.substring(0, search.length() - 1);
            if (page == Page.FRIENDS && !friendName.isEmpty()) friendName = friendName.substring(0, friendName.length() - 1);
            return true;
        }
        if ((keyCode == InputConstants.KEY_RETURN || keyCode == InputConstants.KEY_NUMPADENTER) && page == Page.FRIENDS) {
            addFriend();
            return true;
        }
        if (keyCode == InputConstants.KEY_ESCAPE && page == Page.MODULES && !search.isEmpty()) {
            search = "";
            return true;
        }
        if (PaprikaClient.menuKey.matches(paprika$k) || PaprikaClient.menuKey2.matches(paprika$k)) {
            onClose();
            return true;
        }
        return super.keyPressed(paprika$k);
    }

    private void drawFitted(GuiGraphicsExtractor g, String text, int cx, int cy, int maxW, int color) {
        int w = Ui.width(font, text);
        float s = w > maxW ? Math.max(0.5F, maxW / (float) w) : 1.0F;
        g.pose().pushMatrix();
        g.pose().translate((float) (cx), (float) (cy));
        g.pose().scale((float) (s), (float) (s));
        Ui.draw(g, font, text, -w / 2, -4, color);
        g.pose().popMatrix();
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void click() {
        if (minecraft != null) minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    private static int paprika$glfwButton(int sdl) {
        return switch (sdl) { case 1 -> 0; case 3 -> 1; case 2 -> 2; default -> sdl - 1; };
    }
}
