package com.paprika.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class BoolSetting extends Setting {
    private final boolean def;
    private boolean value;

    public BoolSetting(String name, String description, boolean def) {
        super(name, description);
        this.def = def;
        this.value = def;
    }

    public boolean get() { return value; }
    public void set(boolean v) { value = v; }
    public void toggle() { value = !value; }

    @Override public void reset() { value = def; }
    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement json) { value = json.getAsBoolean(); }
}
