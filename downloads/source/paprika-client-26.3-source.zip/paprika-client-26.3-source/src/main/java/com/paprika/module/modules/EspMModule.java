package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class EspMModule extends Module {
    public EspMModule() {
        super("ESPM", "Orange boxes around hostile and neutral mobs", Category.RENDER);
    }
}
