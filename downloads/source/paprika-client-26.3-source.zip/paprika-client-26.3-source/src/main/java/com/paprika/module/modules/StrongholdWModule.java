package com.paprika.module.modules;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class StrongholdWModule extends StructureWModule {
    private static final Map<Block, String> TYPES = new LinkedHashMap<>();
    private static final String[] ORDER = {"frame", "portal", "infested", "bookshelf", "mossy", "cracked", "bars", "door"};

    static {
        TYPES.put(Blocks.END_PORTAL_FRAME, "frame");
        TYPES.put(Blocks.END_PORTAL, "portal");
        TYPES.put(Blocks.INFESTED_STONE_BRICKS, "infested");
        TYPES.put(Blocks.INFESTED_MOSSY_STONE_BRICKS, "infested");
        TYPES.put(Blocks.INFESTED_CRACKED_STONE_BRICKS, "infested");
        TYPES.put(Blocks.INFESTED_CHISELED_STONE_BRICKS, "infested");
        TYPES.put(Blocks.BOOKSHELF, "bookshelf");
        TYPES.put(Blocks.MOSSY_STONE_BRICKS, "mossy");
        TYPES.put(Blocks.CRACKED_STONE_BRICKS, "cracked");
        TYPES.put(Blocks.IRON_BARS, "bars");
        TYPES.put(Blocks.IRON_DOOR, "door");
    }

    public StrongholdWModule() {
        super("StrongholdW", "Finds strongholds in loaded chunks and shows them in red");
    }

    @Override protected Map<Block, String> types() { return TYPES; }
    @Override protected String[] order() { return ORDER; }
    @Override protected Set<String> sureTypes() { return Set.of("frame", "portal"); }
    @Override protected Set<String> requiredTypes() { return Set.of("frame", "portal", "door", "bookshelf"); }
    @Override protected String specialType() { return "frame"; }
    @Override protected String specialMessage(BlockPos p) { return "End portal room at " + p.getX() + ", " + p.getY() + ", " + p.getZ() + "!"; }
    @Override protected int minBlocks() { return 30; }
    @Override protected String structureName() { return "Stronghold"; }
    @Override protected boolean scanHere() { return true; }
    @Override public int fillColor() { return 0x4DFF0000; }
    @Override public int outlineColor() { return 0xFFFF0000; }
    @Override public int labelColor() { return 0xFFFF5555; }

    @Override
    protected String nice(String type, int n) {
        return n + " " + switch (type) {
            case "frame" -> n == 1 ? "end portal frame" : "end portal frames";
            case "portal" -> n == 1 ? "end portal block" : "end portal blocks";
            case "infested" -> n == 1 ? "infested block" : "infested blocks";
            case "bookshelf" -> n == 1 ? "bookshelf" : "bookshelves";
            case "mossy" -> "mossy stone bricks";
            case "cracked" -> "cracked stone bricks";
            case "bars" -> "iron bars";
            case "door" -> n == 1 ? "iron door" : "iron doors";
            default -> type;
        };
    }
}
