package com.paprika.mixin;

import com.paprika.module.modules.Chams;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public abstract class MinecraftGlowMixin {
    @Inject(method = "shouldEntityAppearGlowing", at = @At("HEAD"), cancellable = true)
    private void paprika$chams(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (Chams.colorFor(entity) != -1) cir.setReturnValue(true);
    }
}
