package com.paprika.mixin;

import com.paprika.command.Commands;
import net.minecraft.client.multiplayer.ClientPacketListener;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerChatMixin {
    @Inject(method = "sendChat", at = @At("HEAD"), cancellable = true)
    private void paprika$baritoneCommands(String message, CallbackInfo ci) {
        if (Commands.onChat(message)) {
            ci.cancel();
        }
    }
}
