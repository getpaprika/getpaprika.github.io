package com.paprika.render;

import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import com.paprika.command.Areas;
import com.paprika.module.ModuleManager;
import com.paprika.module.modules.BaritoneModule;
import com.paprika.module.modules.BaseWModule;
import com.paprika.module.modules.DangerousNetherrackModule;
import com.paprika.module.modules.BreadcrumbsModule;
import com.paprika.module.modules.TrajectoriesModule;
import com.paprika.module.modules.StructureWModule;
import com.paprika.module.modules.EspEModule;
import com.paprika.module.modules.EspMModule;
import com.paprika.module.modules.EspPModule;
import com.paprika.module.modules.TracersEModule;
import com.paprika.module.modules.TracersMModule;
import com.paprika.module.modules.TracersPModule;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3fc;

public final class EspRenderer {
    public static final int PLAYER_COLOR  = 0xFFFF0000;
    public static final int FRIEND_COLOR  = 0xFF55FFFF;
    public static final int PASSIVE_COLOR = 0xFF00FF00;
    public static final int HOSTILE_COLOR = 0xFFFF8800;
    public static final int ITEM_COLOR    = 0xFFAA00FF;

    private EspRenderer() {}

    public static int colorFor(Mob mob) {
        return (mob instanceof Enemy || mob instanceof NeutralMob) ? HOSTILE_COLOR : PASSIVE_COLOR;
    }

    public static void render(LevelRenderContext ctx) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        boolean espP = ModuleManager.isOn(EspPModule.class);
        boolean espE = ModuleManager.isOn(EspEModule.class);
        boolean espM = ModuleManager.isOn(EspMModule.class);
        boolean trP = ModuleManager.isOn(TracersPModule.class);
        boolean trE = ModuleManager.isOn(TracersEModule.class);
        boolean trM = ModuleManager.isOn(TracersMModule.class);
        boolean espI = ModuleManager.isOn(com.paprika.module.modules.ItemEspModule.class);
        boolean trI = ModuleManager.isOn(com.paprika.module.modules.ItemTracersModule.class);
        boolean newChunks = ModuleManager.isOn(com.paprika.module.modules.NewChunksModule.class);
        com.paprika.module.modules.BlockOutlineModule outlineMod = ModuleManager.get(com.paprika.module.modules.BlockOutlineModule.class);
        AABB lookedAt = null;
        if (outlineMod != null && outlineMod.isEnabled() && mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult bhit
                && bhit.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) {
            net.minecraft.core.BlockPos bp = bhit.getBlockPos();
            net.minecraft.world.phys.shapes.VoxelShape shape = mc.level.getBlockState(bp).getShape(mc.level, bp);
            if (!shape.isEmpty()) lookedAt = shape.bounds().move(bp).inflate(0.002);
        }
        boolean oldChunks = newChunks && ModuleManager.get(com.paprika.module.modules.NewChunksModule.class).showOld.get();
        BaritoneModule baritone = ModuleManager.get(BaritoneModule.class);
        boolean baritoneOn = baritone != null && baritone.isEnabled();
        BaseWModule baseW = ModuleManager.get(BaseWModule.class);
        boolean baseWOn = baseW != null && baseW.isEnabled();
        java.util.List<Areas.Area> areas = Areas.current();

        java.util.List<StructureWModule> structures = new java.util.ArrayList<>();
        boolean anyStructure = false;
        for (com.paprika.module.Module m : ModuleManager.getModules()) {
            if (m instanceof StructureWModule s && s.isEnabled()) {
                structures.add(s);
                if (!s.espGroups().isEmpty()) anyStructure = true;
            }
        }
        boolean crumbs = ModuleManager.isOn(BreadcrumbsModule.class) && BreadcrumbsModule.points().size() > 1;
        com.paprika.module.modules.BlockEspModule blockEspMod = ModuleManager.get(com.paprika.module.modules.BlockEspModule.class);
        java.util.List<net.minecraft.core.BlockPos> blockEsp = blockEspMod != null && blockEspMod.isEnabled()
                ? blockEspMod.shown() : java.util.List.of();
        boolean blockChams = blockEspMod != null && blockEspMod.chams.get();
        com.paprika.module.modules.BlockTracersModule blockTracerMod = ModuleManager.get(com.paprika.module.modules.BlockTracersModule.class);
        java.util.List<net.minecraft.core.BlockPos> blockTracers = blockTracerMod != null && blockTracerMod.isEnabled()
                ? blockTracerMod.shown() : java.util.List.of();
        if (blockTracers.size() > 300) blockTracers = blockTracers.subList(0, 300);
        java.util.List<com.paprika.module.modules.LavaEspModule.Lava> lavaEsp = ModuleManager.isOn(com.paprika.module.modules.LavaEspModule.class)
                ? ModuleManager.get(com.paprika.module.modules.LavaEspModule.class).shown() : java.util.List.of();
        java.util.List<net.minecraft.core.BlockPos> dangerous = ModuleManager.isOn(DangerousNetherrackModule.class)
                ? ModuleManager.get(DangerousNetherrackModule.class).found() : java.util.List.of();
        TrajectoriesModule.Path path = ModuleManager.isOn(TrajectoriesModule.class)
                ? TrajectoriesModule.compute(RenderUtil.partialTick(ctx)) : null;
        if (!espP && !espE && !espM && !trP && !trE && !trM && !baritoneOn && !baseWOn && areas.isEmpty() && !anyStructure
                && !crumbs && path == null && dangerous.isEmpty() && blockEsp.isEmpty() && blockTracers.isEmpty() && lavaEsp.isEmpty()
                && !espI && !trI && !newChunks && lookedAt == null) return;

        float td = RenderUtil.partialTick(ctx);
        Camera camera = mc.gameRenderer.mainCamera();
        Vec3 cam = camera.position();
        Matrix4f matrix = RenderUtil.viewMatrix(camera);
        RenderUtil.beginWorld();
        Vec3 tracerStart = tracerStart(mc, camera);

        CAM = cam;
        Object buf = null;

        boolean baseFills = baseWOn && !baseW.espGroups().isEmpty();
        boolean pathFill = path != null && path.hit() != null;
        if (baseFills || anyStructure || pathFill || !dangerous.isEmpty() || (blockChams && !blockEsp.isEmpty()) || !lavaEsp.isEmpty()
                || newChunks || (lookedAt != null && outlineMod.fill.get())) {
            buf = null;
            if (baseFills) {
                for (BaseWModule.Group group : baseW.espGroups()) {
                    filledBox(buf, matrix, group.box().move(-cam.x, -cam.y, -cam.z), 0x4D000000 | (baseW.colorOf(group) & 0xFFFFFF));
                }
            }
            for (StructureWModule s : structures) {
                for (BaseWModule.Group group : s.espGroups()) {
                    filledBox(buf, matrix, group.box().move(-cam.x, -cam.y, -cam.z), s.fillColor());
                }
            }
            if (lookedAt != null && outlineMod.fill.get()) {
                filledBox(buf, matrix, lookedAt.move(-cam.x, -cam.y, -cam.z), 0x80000000 | outlineMod.rgb());
            }
            if (newChunks) {
                double chunkY = Math.floor(mc.player.getY()) - cam.y;
                for (long key : com.paprika.module.modules.NewChunksModule.newChunks()) {
                    filledFaces(buf, matrix, chunkSquare(key, chunkY, cam), 0x40FF0000, 0b11);
                }
                if (oldChunks) {
                    for (long key : com.paprika.module.modules.NewChunksModule.oldChunks()) {
                        filledFaces(buf, matrix, chunkSquare(key, chunkY, cam), 0x2000FF00, 0b11);
                    }
                }
            }
            for (com.paprika.module.modules.LavaEspModule.Lava l : lavaEsp) {
                filledFaces(buf, matrix, new AABB(l.pos()).move(-cam.x, -cam.y, -cam.z), 0x55FF8C00, l.faces());
            }
            if (blockChams) {
                for (net.minecraft.core.BlockPos p : blockEsp) {
                    filledBox(buf, matrix, new AABB(p).move(-cam.x, -cam.y, -cam.z), 0x50000000 | (rainbowAt(p) & 0xFFFFFF));
                }
            }
            if (pathFill) filledBox(buf, matrix, path.hit().move(-cam.x, -cam.y, -cam.z), 0x4D00FF00);
            for (net.minecraft.core.BlockPos p : dangerous) {
                filledBox(buf, matrix, new AABB(p).move(-cam.x, -cam.y, -cam.z), 0x60DC143C);
            }
        }

        buf = null;
        int drawn = 0;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || e == mc.getCameraEntity()) continue;

            int color;
            boolean box, tracer;
            if (e instanceof Player pl) {
                color = com.paprika.command.Friends.is(pl) ? FRIEND_COLOR : PLAYER_COLOR; box = espP; tracer = trP;
            } else if (e instanceof net.minecraft.world.entity.item.ItemEntity) {
                color = ITEM_COLOR; box = espI; tracer = trI;
            } else if (e instanceof Mob mob) {
                color = colorFor(mob);
                boolean hostile = color == HOSTILE_COLOR;
                box = hostile ? espM : espE;
                tracer = hostile ? trM : trE;
            } else {
                continue;
            }
            if (!box && !tracer) continue;

            double x = Mth.lerp(td, e.xOld, e.getX()) - cam.x;
            double y = Mth.lerp(td, e.yOld, e.getY()) - cam.y;
            double z = Mth.lerp(td, e.zOld, e.getZ()) - cam.z;
            AABB bb = e.getBoundingBox().move(-e.getX() + x, -e.getY() + y, -e.getZ() + z);

            if (box) { box(buf, matrix, bb, color); drawn++; }
            if (tracer) {
                Vec3 c = bb.getCenter();
                line(buf, matrix, tracerStart.x, tracerStart.y, tracerStart.z, c.x(), c.y, c.z(), color);
                drawn++;
            }
        }

        for (net.minecraft.core.BlockPos p : dangerous) {
            box(buf, matrix, new AABB(p).move(-cam.x, -cam.y, -cam.z), 0xFFDC143C);
            drawn++;
        }

        if (path != null) {
            java.util.List<Vec3> pts = path.points();
            for (int i = 1; i < pts.size(); i++) {
                Vec3 a = pts.get(i - 1), b = pts.get(i);
                line(buf, matrix, a.x - cam.x, a.y - cam.y, a.z - cam.z, b.x - cam.x, b.y - cam.y, b.z - cam.z, 0xFF00FF00);
                drawn++;
            }
            if (path.hit() != null) {
                box(buf, matrix, path.hit().move(-cam.x, -cam.y, -cam.z), 0xFF00FF00);
                drawn++;
            }
        }

        if (crumbs) {
            java.util.List<Vec3> pts = BreadcrumbsModule.points();
            for (int i = 1; i < pts.size(); i++) {
                Vec3 a = pts.get(i - 1), b = pts.get(i);
                if (a.distanceToSqr(b) > 100) continue;
                line(buf, matrix, a.x - cam.x, a.y - cam.y, a.z - cam.z, b.x - cam.x, b.y - cam.y, b.z - cam.z, 0xFFFFFF55);
                drawn++;
            }
        }

        for (StructureWModule s : structures) {
            for (BaseWModule.Group group : s.espGroups()) {
                box(buf, matrix, group.box().move(-cam.x, -cam.y, -cam.z), s.outlineColor());
                drawn++;
            }
        }

        if (lookedAt != null) {
            box(buf, matrix, lookedAt.move(-cam.x, -cam.y, -cam.z), 0xFF000000 | outlineMod.rgb());
            drawn++;
        }

        if (newChunks) {
            double chunkY = Math.floor(mc.player.getY()) - cam.y;
            for (long key : com.paprika.module.modules.NewChunksModule.newChunks()) {
                box(buf, matrix, chunkSquare(key, chunkY, cam), 0xFFFF0000);
                drawn++;
            }
            if (oldChunks) {
                for (long key : com.paprika.module.modules.NewChunksModule.oldChunks()) {
                    box(buf, matrix, chunkSquare(key, chunkY, cam), 0x8000FF00);
                    drawn++;
                }
            }
        }

        for (net.minecraft.core.BlockPos p : blockEsp) {
            box(buf, matrix, new AABB(p).move(-cam.x, -cam.y, -cam.z), rainbowAt(p));
            drawn++;
        }

        for (net.minecraft.core.BlockPos p : blockTracers) {
            line(buf, matrix, tracerStart.x, tracerStart.y, tracerStart.z,
                    p.getX() + 0.5 - cam.x, p.getY() + 0.5 - cam.y, p.getZ() + 0.5 - cam.z, rainbowAt(p));
            drawn++;
        }

        for (Areas.Area area : areas) {
            box(buf, matrix, area.box().move(-cam.x, -cam.y, -cam.z), 0xFF00FFFF);
            drawn++;
        }

        if (baseWOn) {
            for (BaseWModule.Group group : baseW.espGroups()) {
                box(buf, matrix, group.box().move(-cam.x, -cam.y, -cam.z), baseW.colorOf(group));
                drawn++;
            }
        }

        if (baritoneOn) {
            int rainbow = 0xFF000000 | Mth.hsvToRgb((System.currentTimeMillis() % 3000L) / 3000.0F, 1.0F, 1.0F);
            for (AABB block : baritone.espBlocks()) {
                box(buf, matrix, block.move(-cam.x, -cam.y, -cam.z), rainbow);
                drawn++;
            }
            Entity target = baritone.espEntity();
            if (target != null && target.isAlive()) {
                double x = Mth.lerp(td, target.xOld, target.getX()) - cam.x;
                double y = Mth.lerp(td, target.yOld, target.getY()) - cam.y;
                double z = Mth.lerp(td, target.zOld, target.getZ()) - cam.z;
                box(buf, matrix, target.getBoundingBox()
                        .move(-target.getX() + x, -target.getY() + y, -target.getZ() + z), rainbow);
                drawn++;
            }
        }

        RenderUtil.endWorld();
    }

    private static Vec3 tracerStart(Minecraft mc, Camera camera) {
        Vector3fc look = camera.forwardVector();
        Vector3fc up = camera.upVector();
        double halfFov = Math.toRadians(mc.options.fov().get()) / 2.0;
        double down = Math.tan(halfFov) * 0.95;
        return new Vec3(look.x() - up.x() * down, look.y() - up.y() * down, look.z() - up.z() * down);
    }

    private static AABB chunkSquare(long key, double y, Vec3 cam) {
        int cx = net.minecraft.world.level.ChunkPos.getX(key) << 4, cz = net.minecraft.world.level.ChunkPos.getZ(key) << 4;
        return new AABB(cx - cam.x, y, cz - cam.z, cx + 16 - cam.x, y, cz + 16 - cam.z);
    }

    private static int rainbowAt(net.minecraft.core.BlockPos p) {
        float hue = ((System.currentTimeMillis() % 3000L) / 3000.0F + (p.getX() + p.getY() + p.getZ()) * 0.03F) % 1.0F;
        if (hue < 0) hue += 1.0F;
        return 0xFF000000 | Mth.hsvToRgb(hue, 1.0F, 1.0F);
    }

    private static Vec3 CAM = Vec3.ZERO;

    private static AABB world(AABB bb) {
        return bb.move(CAM.x, CAM.y, CAM.z);
    }

    private static void box(Object b, Matrix4f m, AABB bb, int color) {
        Gizmos.cuboid(world(bb), GizmoStyle.stroke(color, 2.0F)).setAlwaysOnTop();
    }

    private static void filledBox(Object b, Matrix4f m, AABB bb, int color) {
        Gizmos.cuboid(world(bb), GizmoStyle.fill(color)).setAlwaysOnTop();
    }

    private static final net.minecraft.core.Direction[] FACES = {
            net.minecraft.core.Direction.DOWN, net.minecraft.core.Direction.UP, net.minecraft.core.Direction.NORTH,
            net.minecraft.core.Direction.SOUTH, net.minecraft.core.Direction.WEST, net.minecraft.core.Direction.EAST};

    private static void filledFaces(Object b, Matrix4f m, AABB bb, int color, int faces) {
        AABB w = world(bb);
        Vec3 lo = new Vec3(w.minX, w.minY, w.minZ), hi = new Vec3(w.maxX, w.maxY, w.maxZ);
        for (int f = 0; f < 6; f++) {
            if ((faces & (1 << f)) == 0) continue;
            Gizmos.rect(lo, hi, FACES[f], GizmoStyle.fill(color)).setAlwaysOnTop();
        }
    }

    static void line(Object b, Matrix4f m,
                     double x1, double y1, double z1,
                     double x2, double y2, double z2, int color) {
        Gizmos.line(new Vec3(x1 + CAM.x, y1 + CAM.y, z1 + CAM.z), new Vec3(x2 + CAM.x, y2 + CAM.y, z2 + CAM.z), color, 2.0F).setAlwaysOnTop();
    }
}
