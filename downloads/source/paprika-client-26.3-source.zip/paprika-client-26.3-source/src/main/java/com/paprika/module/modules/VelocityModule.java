package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;

public class VelocityModule extends Module {
    public final NumberSetting horizontal = number("Horizontal", "How much sideways knockback you still take", 0, 0, 100, 5, "%");
    public final NumberSetting vertical = number("Vertical", "How much upward knockback you still take", 0, 0, 100, 5, "%");

    public VelocityModule() {
        super("Velocity", "You take no knockback at all", Category.PLAYER);
    }
}
