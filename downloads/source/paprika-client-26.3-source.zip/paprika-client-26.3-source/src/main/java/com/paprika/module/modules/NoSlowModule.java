package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class NoSlowModule extends Module {
    public NoSlowModule() {
        super("NoSlow", "No slowdown from using items, soul sand or honey", Category.MOVEMENT);
    }
}
