package com.paprika.module.modules;

public class TunnelModule extends NukerModule {
    public TunnelModule() {
        super("Tunnel", "Digs a 3x3x3 area around you, never the blocks below you", 1, 0, 2);
    }
}
