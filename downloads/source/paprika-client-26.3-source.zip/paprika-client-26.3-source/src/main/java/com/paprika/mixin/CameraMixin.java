package com.paprika.mixin;

import com.paprika.module.modules.FreecamModule;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow private boolean detached;

    @Shadow protected abstract void setPosition(double x, double y, double z);

    @Shadow protected abstract void setRotation(float yRot, float xRot);

    @Inject(method = "alignWithEntity", at = @At("TAIL"))
    private void paprika$freecam(float partialTick, CallbackInfo ci) {
        FreecamModule freecam = FreecamModule.active();
        if (freecam == null) return;
        this.detached = true;
        this.setRotation(freecam.yaw(), freecam.pitch());
        Vec3 pos = freecam.position(partialTick);
        this.setPosition(pos.x, pos.y, pos.z);
    }
}
