package com.paprika.mixin;

import com.paprika.module.modules.FreecamModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class FreecamTurnMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void paprika$freecamTurn(double yRot, double xRot, CallbackInfo ci) {
        if ((Object) this != Minecraft.getInstance().player) return;
        FreecamModule freecam = FreecamModule.active();
        if (freecam != null) {
            freecam.turn(yRot, xRot);
            ci.cancel();
        }
    }
}
