package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.XrayModule;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.block.BlockQuadOutput;
import net.minecraft.client.renderer.block.ModelBlockRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ModelBlockRenderer.class)
public abstract class BlockRenderDispatcherMixin {
    @Inject(method = "tesselateBlock", at = @At("HEAD"), cancellable = true)
    private void paprika$xrayHide(BlockQuadOutput output, float x, float y, float z, BlockAndTintGetter level,
                                  BlockPos pos, BlockState state,
                                  net.minecraft.client.renderer.block.dispatch.BlockStateModel model, long seed,
                                  CallbackInfo ci) {
        if (ModuleManager.isOn(XrayModule.class) && !XrayModule.isVisible(state, level, pos)) {
            ci.cancel();
        }
    }
}
