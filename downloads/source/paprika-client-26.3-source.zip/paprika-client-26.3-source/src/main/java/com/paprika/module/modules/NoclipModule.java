package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

public class NoclipModule extends Module {
    public NoclipModule() {
        super("Noclip", "Walk through walls and ceilings (the floor still holds you)", Category.MOVEMENT);
    }

    @Override
    public String warning() {
        return "MAY NOT WORK!";
    }

    public static boolean on() {
        return ModuleManager.isOn(NoclipModule.class);
    }

    public static boolean isYou(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && (e == mc.player || e.getUUID().equals(mc.player.getUUID()));
    }
}
