package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.phys.Vec3;

public class SpiderModule extends Module {
    public SpiderModule() {
        super("Spider", "Climb walls like a spider", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.horizontalCollision) {
            Vec3 v = mc.player.getDeltaMovement();
            mc.player.setDeltaMovement(v.x, 0.2, v.z);
        }
    }
}
