package com.paprika.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class TextSetting extends Setting {
    private final String def;
    private String value;

    public TextSetting(String name, String description, String def) {
        super(name, description);
        this.def = def;
        this.value = def;
    }

    public String get() { return value; }
    public void set(String v) { value = v == null ? "" : v; }

    @Override public void reset() { value = def; }
    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement json) { value = json.getAsString(); }
}
