package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.VelocityModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import com.paprika.module.modules.MKillAuraModule;
import net.minecraft.network.protocol.game.ClientboundDamageEventPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {
    @Inject(method = "handleDamageEvent", at = @At("HEAD"))
    private void paprika$rememberAttacker(ClientboundDamageEventPacket packet, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && packet.entityId() == mc.player.getId()) {
            MKillAuraModule.hurtBy(packet.sourceCauseId());
            MKillAuraModule.hurtBy(packet.sourceDirectId());
        }
    }

    @Inject(method = "handleSetEntityMotion", at = @At("HEAD"), cancellable = true)
    private void paprika$noKnockback(ClientboundSetEntityMotionPacket packet, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (ModuleManager.isOn(VelocityModule.class)
                && mc.player != null
                && packet.id() == mc.player.getId()) {
            VelocityModule v = ModuleManager.get(VelocityModule.class);
            double h = v.horizontal.get() / 100.0, up = v.vertical.get() / 100.0;
            if (h > 0 || up > 0) {
                net.minecraft.world.phys.Vec3 m = packet.movement();
                double x = m.x * h, y = m.y * up, z = m.z * h;
                mc.execute(() -> { if (mc.player != null) mc.player.setDeltaMovement(x, y, z); });
            }
            ci.cancel();
        }
    }
}
