package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class NoFireModule extends Module {
    public NoFireModule() {
        super("NoFire", "Removes the fire on your screen when you burn", Category.RENDER);
    }
}
