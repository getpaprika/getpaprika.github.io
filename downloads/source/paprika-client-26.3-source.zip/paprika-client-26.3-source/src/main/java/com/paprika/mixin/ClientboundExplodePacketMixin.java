package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.VelocityModule;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientboundExplodePacket.class)
public abstract class ClientboundExplodePacketMixin {
    @Inject(method = "playerKnockback", at = @At("RETURN"), cancellable = true)
    private void paprika$explosionPush(CallbackInfoReturnable<java.util.Optional<net.minecraft.world.phys.Vec3>> cir) {
        if (ModuleManager.isOn(VelocityModule.class) && cir.getReturnValue().isPresent()) {
            VelocityModule v = ModuleManager.get(VelocityModule.class);
            double h = v.horizontal.get() / 100.0, up = v.vertical.get() / 100.0;
            net.minecraft.world.phys.Vec3 push = cir.getReturnValue().get();
            cir.setReturnValue(java.util.Optional.of(new net.minecraft.world.phys.Vec3(push.x * h, push.y * up, push.z * h)));
        }
    }
}
