package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class AutoReplenishModule extends Module {
    private final ItemStack[] last = new ItemStack[9];

    public AutoReplenishModule() {
        super("AutoReplenish", "Refills empty hotbar slots and replaces broken tools", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) return;

        boolean canAct = mc.gui.screen() == null && mc.player.containerMenu == mc.player.inventoryMenu;

        for (int i = 0; i < 9; i++) {
            ItemStack now = mc.player.getInventory().getItem(i);
            ItemStack before = last[i];
            if (canAct && before != null && !before.isEmpty() && now.isEmpty()) {
                int from = findReplacement(before);
                if (from >= 0) {
                    mc.gameMode.handleContainerInput(mc.player.inventoryMenu.containerId, from, i, ContainerInput.SWAP, mc.player);
                }
            }
        }
        for (int i = 0; i < 9; i++) last[i] = mc.player.getInventory().getItem(i).copy();
    }

    private int findReplacement(ItemStack before) {
        Item item = before.getItem();
        for (int j = 9; j < 36; j++) {
            if (mc.player.getInventory().getItem(j).is(item)) return j;
        }

        String kind = com.paprika.util.ItemKinds.toolKind(before);
        if (kind == null) return -1;
        float oldSpeed = com.paprika.util.ItemKinds.toolSpeed(before);
        int best = -1;
        float bestSpeed = oldSpeed - 0.001F;
        for (int j = 9; j < 36; j++) {
            ItemStack other = mc.player.getInventory().getItem(j);
            if (!kind.equals(com.paprika.util.ItemKinds.toolKind(other))) continue;
            float speed = com.paprika.util.ItemKinds.toolSpeed(other);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                best = j;
            }
        }
        return best;
    }
}
