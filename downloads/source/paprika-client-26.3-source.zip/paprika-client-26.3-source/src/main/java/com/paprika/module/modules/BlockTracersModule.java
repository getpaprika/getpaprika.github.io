package com.paprika.module.modules;

public class BlockTracersModule extends BlockEspModule {
    public BlockTracersModule() {
        super("BlockTracers", "Rainbow lines to the block you choose (pencil -> Block, e.g. diamond_ore), through walls");
        getSettings().remove(chams);
    }
}
