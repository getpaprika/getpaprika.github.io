package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;

public class EntityCullingModule extends Module {
    private static final int RECHECK_TICKS = 4;

    private static final Map<Integer, Entry> ENTITIES = new HashMap<>();
    private static final Map<Long, Entry> BLOCK_ENTITIES = new HashMap<>();
    private static int ticks;

    private static final class Entry {
        boolean visible;
        int checkedAt;
    }

    public EntityCullingModule() {
        super("EntityCulling", "Hides entities you can't see to boost FPS", Category.RENDER);
    }

    @Override
    public void onTick() {
        ticks++;
        if (ticks % 200 == 0) {
            ENTITIES.clear();
            BLOCK_ENTITIES.clear();
        }
    }

    @Override
    protected void onDisable() {
        ENTITIES.clear();
        BLOCK_ENTITIES.clear();
    }

    public static boolean isEntityVisible(Entity e) {
        if (mc.level == null || mc.player == null) return true;
        if (e == mc.player || e == mc.getCameraEntity() || e.isCurrentlyGlowing()) return true;

        Vec3 cam = mc.gameRenderer.mainCamera().position();
        AABB box = e.getBoundingBox();
        if (box.inflate(3).contains(cam)) return true;

        Entry entry = ENTITIES.computeIfAbsent(e.getId(), k -> new Entry());
        if (entry.checkedAt == 0 || ticks - entry.checkedAt >= RECHECK_TICKS) {
            entry.visible = canSee(cam, box, null);
            entry.checkedAt = ticks == 0 ? 1 : ticks;
        }
        return entry.visible;
    }

    public static boolean isBlockEntityVisible(BlockPos pos) {
        if (mc.level == null || mc.player == null) return true;

        Vec3 cam = mc.gameRenderer.mainCamera().position();
        AABB box = new AABB(pos).deflate(0.05);
        if (box.inflate(3).contains(cam)) return true;

        Entry entry = BLOCK_ENTITIES.computeIfAbsent(pos.asLong(), k -> new Entry());
        if (entry.checkedAt == 0 || ticks - entry.checkedAt >= RECHECK_TICKS) {
            entry.visible = canSee(cam, box, pos);
            entry.checkedAt = ticks == 0 ? 1 : ticks;
        }
        return entry.visible;
    }

    private static boolean canSee(Vec3 cam, AABB box, BlockPos self) {
        Vec3 c = box.getCenter();
        Vec3[] points = {
                c,
                new Vec3(c.x, box.maxY - 0.05, c.z),
                new Vec3(c.x, box.minY + 0.05, c.z),
                new Vec3(box.minX, c.y, box.minZ),
                new Vec3(box.maxX, c.y, box.maxZ),
                new Vec3(box.minX, c.y, box.maxZ),
                new Vec3(box.maxX, c.y, box.minZ)
        };
        for (Vec3 p : points) {
            BlockHitResult hit = mc.level.clip(new ClipContext(cam, p,
                    ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, mc.player));
            if (hit.getType() == HitResult.Type.MISS) return true;
            if (self != null && hit.getBlockPos().equals(self)) return true;
        }
        return false;
    }
}
