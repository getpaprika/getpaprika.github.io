package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class NExpModule extends Module {
    public NExpModule() {
        super("NExp", "Removes explosion particles", Category.RENDER);
    }
}
