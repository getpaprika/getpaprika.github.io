package com.paprika.command;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

public final class Friends {
    private static final Set<String> NAMES = new TreeSet<>();

    private Friends() {}

    public static boolean add(String name) { return NAMES.add(name.toLowerCase(Locale.ROOT)); }

    public static boolean remove(String name) { return NAMES.remove(name.toLowerCase(Locale.ROOT)); }

    public static boolean is(String name) { return NAMES.contains(name.toLowerCase(Locale.ROOT)); }

    public static boolean is(Player player) { return is(player.getGameProfile().name()); }

    public static List<String> all() { return new ArrayList<>(NAMES); }

    public static JsonArray save() {
        JsonArray arr = new JsonArray();
        for (String n : NAMES) arr.add(n);
        return arr;
    }

    public static void load(JsonArray arr) {
        NAMES.clear();
        for (JsonElement e : arr) NAMES.add(e.getAsString().toLowerCase(Locale.ROOT));
    }
}
