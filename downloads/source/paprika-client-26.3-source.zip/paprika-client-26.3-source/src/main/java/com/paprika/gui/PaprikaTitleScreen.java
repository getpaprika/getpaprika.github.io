package com.paprika.gui;

import com.paprika.PaprikaClient;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.CreditsAndAttributionScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class PaprikaTitleScreen extends Screen {
    private static final int BTN_W = 200, BTN_H = 20, GAP = 4, SMALL_W = 98, ICON = 20;
    private static final int WHITE = 0xFFFFFFFF;
    private static final ItemStack RED_DYE = new ItemStack(Items.DYE.red());

    private static final long BLACK_ONLY = 0, LOGO_IN = 1000, HOLD = 0, FADE_OUT = 1000;
    private static final long INTRO_END = BLACK_ONLY + LOGO_IN + HOLD + FADE_OUT;

    private static boolean introPlayed;
    private long introStart = -1;
    private boolean intro;

    private record Btn(int x, int y, int w, int h, String label, int icon, Runnable action) {}
    private final java.util.List<Btn> buttons = new java.util.ArrayList<>();

    public PaprikaTitleScreen() {
        super(Component.translatable("narrator.screen.title"));
        intro = !introPlayed;
        introPlayed = true;
    }

    private int logoY() {
        return height / 2 - 62;
    }

    @Override
    protected void init() {
        buttons.clear();
        int x = width / 2 - BTN_W / 2;
        int y = Math.max(logoY() + 34, height / 2 - 22);
        Minecraft mc = Minecraft.getInstance();
        buttons.add(new Btn(x, y, BTN_W, BTN_H, I18n.get("menu.singleplayer"), 0, () -> mc.gui.setScreen(new SelectWorldScreen(this))));
        buttons.add(new Btn(x, y + 24, BTN_W, BTN_H, I18n.get("menu.multiplayer"), 0, () -> mc.gui.setScreen(new JoinMultiplayerScreen(this))));
        buttons.add(new Btn(x, y + 48, BTN_W, BTN_H, I18n.get("menu.online"), 0,
                () -> mc.gui.setScreen(new com.mojang.realmsclient.RealmsMainScreen(this))));
        int row = y + 72 + 12;
        buttons.add(new Btn(x, row + 24, BTN_W, BTN_H, "HUD Editor", 0, () -> mc.gui.setScreen(new HudEditorScreen(() -> this))));
        buttons.add(new Btn(x - ICON - 4, row, ICON, BTN_H, "", 1,
                () -> mc.gui.setScreen(new net.minecraft.client.gui.screens.options.LanguageSelectScreen(this, mc.options, mc.getLanguageManager()))));
        buttons.add(new Btn(x, row, SMALL_W, BTN_H, I18n.get("menu.options"), 0,
                () -> mc.gui.setScreen(new net.minecraft.client.gui.screens.options.OptionsScreen(this, mc.options))));
        buttons.add(new Btn(x + BTN_W - SMALL_W, row, SMALL_W, BTN_H, I18n.get("menu.quit"), 0, mc::stop));
        buttons.add(new Btn(x + BTN_W + 4, row, ICON, BTN_H, "", 2,
                () -> mc.gui.setScreen(new net.minecraft.client.gui.screens.options.AccessibilityOptionsScreen(this, mc.options))));
    }

    private String versionText() {
        Minecraft mc = Minecraft.getInstance();
        String type = "";
        String modded = Minecraft.checkModStatus().shouldReportAsModified() ? I18n.get("menu.modded") : "";
        return "Minecraft " + SharedConstants.getCurrentVersion().name() + type + modded;
    }

    private static final String COPYRIGHT = "Copyright Mojang AB. Do not distribute!";

    private int copyrightX() {
        return width - font.width(COPYRIGHT) - 2;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        long now = System.currentTimeMillis();
        if (intro && introStart < 0) introStart = now;
        long t = intro ? now - introStart : INTRO_END;
        if (t >= INTRO_END) intro = false;

        extractPanorama(g, partialTick);
        g.fill(0, 0, width, height, 0x50000000);

        boolean ready = !intro;
        Theme theme = Theme.current();
        for (Btn b : buttons) {
            boolean hover = ready && inside(mouseX, mouseY, b);
            g.fill(b.x(), b.y(), b.x() + b.w(), b.y() + b.h(), hover ? 0xA0000000 : 0x70000000);
            outline(g, b.x(), b.y(), b.w(), b.h(), hover ? theme.accentArgb(0xFF) : theme.accentArgb(0x90));
            if (b.icon() == 1) globe(g, b.x() + 3, b.y() + 3, hover ? WHITE : 0xFFDDDDDD);
            else if (b.icon() == 2) person(g, b.x() + 3, b.y() + 3, hover ? WHITE : 0xFFDDDDDD);
            else g.centeredText(font, b.label(), b.x() + b.w() / 2, b.y() + 6, hover ? 0xFFFFFFA0 : WHITE);
        }

        g.text(font, versionText(), 2, height - 10, WHITE, true);
        boolean overCopy = ready && mouseX >= copyrightX() && mouseY >= height - 10;
        g.text(font, COPYRIGHT, copyrightX(), height - 10, WHITE, true);
        if (overCopy) g.fill(copyrightX(), height - 1, copyrightX() + font.width(COPYRIGHT), height, WHITE);

        float black = 1.0F, logo = 1.0F;
        if (t < BLACK_ONLY) {
            logo = 0;
        } else if (t < BLACK_ONLY + LOGO_IN) {
            logo = (t - BLACK_ONLY) / (float) LOGO_IN;
        } else if (t < BLACK_ONLY + LOGO_IN + HOLD) {
            logo = 1;
        } else if (t < INTRO_END) {
            black = 1 - (t - BLACK_ONLY - LOGO_IN - HOLD) / (float) FADE_OUT;
        } else {
            black = 0;
        }
        if (black > 0) {
            g.pose().pushMatrix();
            g.pose().translate((float) (0), (float) (0));
            g.fill(0, 0, width, height, ((int) (Mth.clamp(black, 0, 1) * 255) << 24));
            g.pose().popMatrix();
        }
        drawLogo(g, Mth.clamp(logo, 0, 1));
    }

    private void drawLogo(GuiGraphicsExtractor g, float alpha) {
        if (alpha <= 0.02F) return;
        float scale = 3.0F;
        int textW = font.width(PaprikaClient.NAME);
        float totalW = (16 + 4 + textW) * scale;
        float left = width / 2.0F - totalW / 2.0F;
        float top = logoY() - 8 * scale;
        g.pose().pushMatrix();
        g.pose().translate((float) (left), (float) (top));
        g.pose().scale((float) (scale), (float) (scale));
        if (alpha >= 0.6F) g.item(RED_DYE, 0, 0);
        int a = Math.max(4, (int) (alpha * 255));
        g.text(font, PaprikaClient.NAME, 20, 4, (a << 24) | (PaprikaClient.RED & 0xFFFFFF), true);
        g.pose().popMatrix();
    }

    private static void globe(GuiGraphicsExtractor g, int x, int y, int c) {
        int[][] ring = {{5,0,9,1},{3,1,5,2},{9,1,11,2},{2,2,3,3},{11,2,12,3},{1,3,2,5},{12,3,13,5},{0,5,1,9},{13,5,14,9},
                {1,9,2,11},{12,9,13,11},{2,11,3,12},{11,11,12,12},{3,12,5,13},{9,12,11,13},{5,13,9,14}};
        for (int[] r : ring) g.fill(x + r[0], y + r[1], x + r[2], y + r[3], c);
        g.fill(x + 1, y + 6, x + 13, y + 7, c);
        g.fill(x + 6, y + 1, x + 7, y + 13, c);
        g.fill(x + 3, y + 3, x + 11, y + 4, c);
        g.fill(x + 3, y + 10, x + 11, y + 11, c);
    }

    private static void person(GuiGraphicsExtractor g, int x, int y, int c) {
        g.fill(x + 5, y + 0, x + 9, y + 4, c);
        g.fill(x + 3, y + 5, x + 11, y + 6, c);
        g.fill(x + 1, y + 5, x + 3, y + 6, c);
        g.fill(x + 11, y + 5, x + 13, y + 6, c);
        g.fill(x + 5, y + 6, x + 9, y + 10, c);
        g.fill(x + 5, y + 10, x + 6, y + 14, c);
        g.fill(x + 8, y + 10, x + 9, y + 14, c);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent paprika$e, boolean paprika$dbl) {
        double mouseX = paprika$e.x(), mouseY = paprika$e.y();
        int button = paprika$glfwButton(paprika$e.button());
        if (intro) {
            intro = false;
            return true;
        }
        if (button != 0) return false;
        for (Btn b : buttons) {
            if (inside(mouseX, mouseY, b)) {
                click();
                b.action().run();
                return true;
            }
        }
        if (mouseX >= copyrightX() && mouseY >= height - 10) {
            click();
            Minecraft.getInstance().gui.setScreen(new CreditsAndAttributionScreen(this));
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent paprika$k) {
        int keyCode = paprika$k.key(), scanCode = paprika$k.keycode(), modifiers = paprika$k.modifiers();
        if (intro) {
            intro = false;
            return true;
        }
        return super.keyPressed(paprika$k);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static boolean inside(double mx, double my, Btn b) {
        return mx >= b.x() && mx < b.x() + b.w() && my >= b.y() && my < b.y() + b.h();
    }

    private static void outline(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private static void click() {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    private static int paprika$glfwButton(int sdl) {
        return switch (sdl) { case 1 -> 0; case 3 -> 1; case 2 -> 2; default -> sdl - 1; };
    }
}
