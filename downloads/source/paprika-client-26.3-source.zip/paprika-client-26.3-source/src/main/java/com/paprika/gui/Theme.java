package com.paprika.gui;

import java.util.List;

public record Theme(String name, int accent, int off, int on) {
    public static final List<Theme> ALL = List.of(
            new Theme("Paprika", 0xFF2B2B, 0x3A7BFF, 0x33D45A),
            new Theme("Ocean",   0x2BB5FF, 0x2B4BFF, 0x2BFFD5),
            new Theme("Forest",  0x3CB043, 0x2E7D32, 0x9BE35B),
            new Theme("Grape",   0xA64DFF, 0x6A3DE8, 0xE04DFF),
            new Theme("Sunset",  0xFF8C1A, 0xD9480F, 0xFFD43B),
            new Theme("Sakura",  0xFF6FAE, 0xB05A8A, 0xFFB3D9),
            new Theme("Mono",    0xDDDDDD, 0x555555, 0xBBBBBB),
            new Theme("Midnight", 0x5B6CFF, 0x1F2A5C, 0x7F8CFF),
            new Theme("Lava",    0xFF4500, 0x8B1A00, 0xFFB000),
            new Theme("Ice",     0xA0E9FF, 0x4A7FA7, 0xE0FBFF),
            new Theme("Toxic",   0x7FFF00, 0x2F4F2F, 0xCCFF33),
            new Theme("Royal",   0xFFD700, 0x5B2C83, 0xFFE680),
            new Theme("Candy",   0xFF69B4, 0x40C4FF, 0xFFF176),
            new Theme("Nether",  0xB22222, 0x4A0E0E, 0xFF7F50),
            new Theme("End",     0xE0D68A, 0x3B2D4F, 0xC77DFF),
            new Theme("Mint",    0x3EB489, 0x2A6F5A, 0xB2F7D7),
            new Theme("Coffee",  0xC69C6D, 0x5C4033, 0xE6CCB2),
            new Theme("Neon",    0x00FFF0, 0xFF00C8, 0x39FF14)
    );

    private static Theme current = ALL.get(0);

    public static Theme current() { return current; }

    public static void set(Theme theme) { current = theme; }

    public static void setByName(String name) {
        for (Theme t : ALL) if (t.name().equalsIgnoreCase(name)) current = t;
    }

    public int accentArgb(int alpha) { return (alpha << 24) | accent; }
    public int offArgb(boolean hover) { return ((hover ? 0xA0 : 0x80) << 24) | (hover ? lighter(off) : off); }
    public int onArgb(boolean hover) { return ((hover ? 0xA0 : 0x80) << 24) | (hover ? lighter(on) : on); }

    private static int lighter(int rgb) {
        int r = Math.min(255, ((rgb >> 16) & 0xFF) + 32);
        int g = Math.min(255, ((rgb >> 8) & 0xFF) + 32);
        int b = Math.min(255, (rgb & 0xFF) + 32);
        return (r << 16) | (g << 8) | b;
    }
}
