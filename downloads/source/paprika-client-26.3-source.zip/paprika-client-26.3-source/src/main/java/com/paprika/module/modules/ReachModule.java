package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.setting.NumberSetting;

public class ReachModule extends Module {
    public final NumberSetting entity = number("Entity reach", "How far you can hit players and mobs (normal is 3)", 4, 3, 7, 0.1, " blocks");
    public final NumberSetting block = number("Block reach", "How far you can break and place blocks (normal is 4.5)", 5.5, 4.5, 7, 0.1, " blocks");

    public ReachModule() {
        super("Reach", "Hit and reach blocks from further away (up to 7 blocks)", Category.COMBAT);
    }

    @Override
    public String warning() {
        return "MAY NOT WORK!";
    }

    public static ReachModule active() {
        ReachModule r = ModuleManager.get(ReachModule.class);
        return r != null && r.isEnabled() ? r : null;
    }
}
