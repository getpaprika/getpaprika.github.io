package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

public class CrystalAuraModule extends Module {
    public final NumberSetting targetRange = number("Target range", "How far away enemies are targeted", 12, 4, 30, 1, " blocks");
    public final NumberSetting perSecond = number("Speed", "Places + breaks per second", 5, 1, 20, 1, "/s");
    private static final double PLACE_REACH = 4.5;
    private static final double BREAK_REACH = 5.0;
    private static final double MAX_TARGET_DIST = 6.0;
    private static final Random RANDOM = new Random();

    private int cooldown;

    public CrystalAuraModule() {
        super("CrystalAura", "Places and blows up crystals next to enemy players", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.gui.screen() != null) return;
        if (cooldown > 0) {
            cooldown--;
            return;
        }

        InteractionHand hand;
        if (mc.player.getMainHandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.MAIN_HAND;
        else if (mc.player.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
        else return;

        Player target = findTarget();
        if (target == null) return;
        Vec3 eye = mc.player.getEyePosition();

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof EndCrystal crystal) || !crystal.isAlive()) continue;
            if (eye.distanceTo(crystal.position()) > BREAK_REACH) continue;
            if (crystal.distanceTo(target) > MAX_TARGET_DIST + 1) continue;
            mc.gameMode.attack(mc.player, crystal);
            mc.player.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
            cooldown = nextCycle();
            return;
        }

        BlockPos best = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        BlockPos me = mc.player.blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(me.offset(-5, -4, -5), me.offset(5, 3, 5))) {
            BlockState state = mc.level.getBlockState(p);
            if (!state.is(Blocks.OBSIDIAN) && !state.is(Blocks.BEDROCK)) continue;
            BlockPos above = p.above();
            if (!mc.level.isEmptyBlock(above)) continue;
            if (eye.distanceTo(Vec3.atCenterOf(p).add(0, 0.5, 0)) > PLACE_REACH) continue;
            AABB space = new AABB(above.getX(), above.getY(), above.getZ(), above.getX() + 1, above.getY() + 2, above.getZ() + 1);
            if (!mc.level.getEntities(null, space).isEmpty()) continue;

            Vec3 crystalPos = Vec3.atBottomCenterOf(above);
            double toTarget = crystalPos.distanceTo(target.position());
            double toMe = crystalPos.distanceTo(mc.player.position());
            if (toTarget > MAX_TARGET_DIST) continue;
            double score = toMe - toTarget * 2;
            if (score > bestScore) {
                bestScore = score;
                best = p.immutable();
            }
        }
        if (best == null) return;

        Vec3 hit = Vec3.atCenterOf(best).add(0, 0.5, 0);
        mc.gameMode.useItemOn(mc.player, hand, new BlockHitResult(hit, Direction.UP, best, false));
        mc.player.swing(hand, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
        cooldown = nextCycle();
    }

    private int nextCycle() {
        int ticks = (int) Math.round(20.0 / perSecond.get()) + RANDOM.nextInt(3) - 1;
        return Math.max(1, ticks) - 1;
    }

    private Player findTarget() {
        Player best = null;
        double bestDist = targetRange.get();
        for (Player p : mc.level.players()) {
            if (com.paprika.module.modules.BlinkModule.isClone(p)) continue;
            if (p == mc.player || !p.isAlive() || p.isCreative() || p.isSpectator() || com.paprika.command.Friends.is(p)) continue;
            double d = p.distanceTo(mc.player);
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }
}
