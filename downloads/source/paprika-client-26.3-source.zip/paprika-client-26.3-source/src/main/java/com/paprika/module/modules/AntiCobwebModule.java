package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class AntiCobwebModule extends Module {
    public AntiCobwebModule() {
        super("AntiCobweb", "Cobwebs don't slow you down", Category.MOVEMENT);
    }
}
