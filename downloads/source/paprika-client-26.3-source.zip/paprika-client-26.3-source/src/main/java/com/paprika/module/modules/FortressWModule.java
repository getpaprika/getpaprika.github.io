package com.paprika.module.modules;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class FortressWModule extends StructureWModule {
    private static final Map<Block, String> TYPES = new LinkedHashMap<>();
    private static final String[] ORDER = {"spawner", "wart", "bricks", "fence", "stairs"};

    static {
        TYPES.put(Blocks.SPAWNER, "spawner");
        TYPES.put(Blocks.NETHER_WART, "wart");
        TYPES.put(Blocks.NETHER_BRICKS, "bricks");
        TYPES.put(Blocks.NETHER_BRICK_FENCE, "fence");
        TYPES.put(Blocks.NETHER_BRICK_STAIRS, "stairs");
    }

    public FortressWModule() {
        super("FortressW", "Finds nether fortresses in loaded chunks and shows them in purple");
    }

    @Override protected Map<Block, String> types() { return TYPES; }
    @Override protected String[] order() { return ORDER; }
    @Override protected Set<String> sureTypes() { return Set.of("spawner", "wart"); }
    @Override protected String specialType() { return "spawner"; }
    @Override protected String specialMessage(BlockPos p) { return "Blaze spawner at " + p.getX() + ", " + p.getY() + ", " + p.getZ() + "!"; }
    @Override protected int minBlocks() { return 40; }
    @Override protected String structureName() { return "Fortress"; }
    @Override protected boolean scanHere() { return mc.level.dimension() == Level.NETHER; }
    @Override public int fillColor() { return 0x4DC040FF; }
    @Override public int outlineColor() { return 0xFFC040FF; }
    @Override public int labelColor() { return 0xFFD080FF; }

    @Override
    protected String nice(String type, int n) {
        return n + " " + switch (type) {
            case "spawner" -> n == 1 ? "blaze spawner" : "blaze spawners";
            case "wart" -> "nether wart";
            case "bricks" -> "nether bricks";
            case "fence" -> n == 1 ? "nether brick fence" : "nether brick fences";
            case "stairs" -> "nether brick stairs";
            default -> type;
        };
    }
}
