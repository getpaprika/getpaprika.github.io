package com.paprika.gui;

public final class HudMeasure {
    private static boolean on;
    private static int minX, minY, maxX, maxY;

    private HudMeasure() {}

    public static void begin() {
        on = true;
        minX = minY = Integer.MAX_VALUE;
        maxX = maxY = Integer.MIN_VALUE;
    }

    public static HudRenderer.Rect end() {
        on = false;
        if (minX == Integer.MAX_VALUE) return null;
        return new HudRenderer.Rect(minX, minY, Math.max(1, maxX - minX), Math.max(1, maxY - minY));
    }

    public static void add(int x1, int y1, int x2, int y2) {
        if (!on) return;
        minX = Math.min(minX, Math.min(x1, x2));
        minY = Math.min(minY, Math.min(y1, y2));
        maxX = Math.max(maxX, Math.max(x1, x2));
        maxY = Math.max(maxY, Math.max(y1, y2));
    }
}
