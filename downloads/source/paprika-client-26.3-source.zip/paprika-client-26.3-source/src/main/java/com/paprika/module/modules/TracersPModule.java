package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class TracersPModule extends Module {
    public TracersPModule() {
        super("TracersP", "Lines to players (same color as ESPP)", Category.RENDER);
    }
}
