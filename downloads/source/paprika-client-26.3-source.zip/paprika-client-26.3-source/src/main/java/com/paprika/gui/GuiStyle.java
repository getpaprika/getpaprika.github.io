package com.paprika.gui;

import net.minecraft.client.gui.screens.Screen;

public final class GuiStyle {
    public static boolean list = false;

    private GuiStyle() {}

    public static Screen open() {
        return list ? new ListGuiScreen() : new ClickGuiScreen();
    }
}
