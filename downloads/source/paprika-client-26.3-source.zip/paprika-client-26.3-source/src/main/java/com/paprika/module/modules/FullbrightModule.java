package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class FullbrightModule extends Module {
    public FullbrightModule() {
        super("Fullbright", "Makes everything fully bright", Category.RENDER);
    }
}
