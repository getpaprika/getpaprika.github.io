package com.paprika.module;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    PLAYER("Player"),
    UTILITY("Utility");

    public final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }
}
