package com.paprika.util;

import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.Tool;
import net.minecraft.world.item.equipment.Equippable;

public final class ItemKinds {
    private ItemKinds() {}

    public static boolean isSword(ItemStack s) { return s.is(ItemTags.SWORDS); }
    public static boolean isAxe(ItemStack s) { return s.is(ItemTags.AXES); }

    public static String toolKind(ItemStack s) {
        if (s.is(ItemTags.SWORDS)) return "sword";
        if (s.is(ItemTags.PICKAXES)) return "pickaxe";
        if (s.is(ItemTags.AXES)) return "axe";
        if (s.is(ItemTags.SHOVELS)) return "shovel";
        if (s.is(ItemTags.HOES)) return "hoe";
        return null;
    }

    public static float toolSpeed(ItemStack s) {
        Tool tool = s.get(DataComponents.TOOL);
        if (tool == null) return 1.0F;
        float best = tool.defaultMiningSpeed();
        for (Tool.Rule rule : tool.rules()) {
            if (rule.speed().isPresent()) best = Math.max(best, rule.speed().get());
        }
        return best;
    }

    public static double attackDamage(ItemStack s) {
        double[] total = {0};
        s.forEachModifier(EquipmentSlot.MAINHAND, (attr, mod) -> {
            if (attr.is(Attributes.ATTACK_DAMAGE) && mod.operation() == AttributeModifier.Operation.ADD_VALUE) total[0] += mod.amount();
        });
        return total[0];
    }

    public static EquipmentSlot armorSlot(ItemStack s) {
        Equippable eq = s.get(DataComponents.EQUIPPABLE);
        if (eq == null || !eq.slot().isArmor()) return null;
        return eq.slot();
    }

    public static double armorValue(ItemStack s, EquipmentSlot slot) {
        double[] total = {0};
        s.forEachModifier(slot, (attr, mod) -> {
            if (mod.operation() != AttributeModifier.Operation.ADD_VALUE) return;
            if (attr.is(Attributes.ARMOR)) total[0] += mod.amount();
            else if (attr.is(Attributes.ARMOR_TOUGHNESS)) total[0] += mod.amount() * 0.5;
        });
        return total[0];
    }
}
