package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.List;

public class DangerousNetherrackModule extends Module {
    private static final int MAX_SHOWN = 800;

    public final NumberSetting range = number("Range", "How far around you it looks", 16, 8, 32, 1, " blocks");
    public final NumberSetting depth = number("Hole depth", "How deep the empty space under it must be", 3, 2, 10, 1, " blocks");

    private List<BlockPos> found = new ArrayList<>();
    private int timer;

    public DangerousNetherrackModule() {
        super("DangerousNetherrack", "Highlights hanging blocks with a deep hole under them in crimson (any block in the Nether, netherrack elsewhere)", Category.RENDER);
    }

    public List<BlockPos> found() {
        return found;
    }

    @Override
    protected void onDisable() {
        found = new ArrayList<>();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (timer-- > 0) return;
        timer = 10;

        List<BlockPos> list = new ArrayList<>();
        int r = range.getInt(), v = Math.max(4, r / 2), d = depth.getInt();
        BlockPos me = mc.player.blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(me.offset(-r, -v, -r), me.offset(r, v, r))) {
            if (isDangerous(mc.level, p, d)) {
                list.add(p.immutable());
                if (list.size() >= MAX_SHOWN) break;
            }
        }
        found = list;
    }

    public static boolean isDangerous(Level level, BlockPos pos, int depth) {
        net.minecraft.world.level.block.state.BlockState state = level.getBlockState(pos);
        if (level.dimension() == Level.NETHER) {
            if (state.is(Blocks.BEDROCK) || state.getCollisionShape(level, pos).isEmpty()) return false;
        } else if (!state.is(Blocks.NETHERRACK)) {
            return false;
        }
        for (int k = 1; k <= depth; k++) {
            BlockPos below = pos.below(k);
            if (level.isOutsideBuildHeight(below) || !level.hasChunkAt(below)) return false;
            if (!level.getBlockState(below).getCollisionShape(level, below).isEmpty()) return false;
        }
        return true;
    }

    public static boolean isDangerous(Level level, BlockPos pos) {
        DangerousNetherrackModule m = ModuleManager.get(DangerousNetherrackModule.class);
        return isDangerous(level, pos, m == null ? 3 : m.depth.getInt());
    }
}
