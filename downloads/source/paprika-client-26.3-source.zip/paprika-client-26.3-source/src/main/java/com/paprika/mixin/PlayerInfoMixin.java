package com.paprika.mixin;

import com.mojang.authlib.GameProfile;
import com.paprika.command.OrgSkins;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerInfo.class)
public abstract class PlayerInfoMixin {
    @Shadow public abstract GameProfile getProfile();

    @Inject(method = "getSkin", at = @At("HEAD"), cancellable = true)
    private void paprika$skin(CallbackInfoReturnable<PlayerSkin> cir) {
        if (!OrgSkins.enabled) return;
        GameProfile profile = getProfile();
        if (profile.properties().containsKey("textures")) return;
        OrgSkins.Skin skin = OrgSkins.get(profile.name());
        if (skin != null) cir.setReturnValue(skin.skin());
    }
}
