package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.NoFireModule;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ScreenEffectRenderer.class)
public abstract class ScreenEffectRendererMixin {
    @Inject(method = "submitFire", at = @At("HEAD"), cancellable = true)
    private static void paprika$noFire(CallbackInfo ci) {
        if (ModuleManager.isOn(NoFireModule.class)) ci.cancel();
    }
}
