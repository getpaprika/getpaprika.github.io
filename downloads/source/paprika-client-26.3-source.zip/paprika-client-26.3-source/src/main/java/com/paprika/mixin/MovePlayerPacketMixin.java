package com.paprika.mixin;

import com.paprika.module.modules.NoFallModule;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerboundMovePlayerPacket.class)
public abstract class MovePlayerPacketMixin {
    @Shadow @Final @Mutable protected boolean onGround;
    @Shadow @Final @Mutable protected float yRot;
    @Shadow @Final @Mutable protected float xRot;
    @Shadow @Final protected boolean hasRot;

    @Inject(method = "<init>(DDDFFZZZZ)V", at = @At("TAIL"))
    private void paprika$noFall(double x, double y, double z, float yRot, float xRot,
                                boolean onGround, boolean horizontalCollision, boolean hasPos, boolean hasRot, CallbackInfo ci) {
        if (NoFallModule.shouldSpoof() || com.paprika.module.modules.FlyModule.shouldSpoof()) this.onGround = true;

        if (hasRot && com.paprika.module.modules.KillAuraFacing.active()) {
            this.yRot = com.paprika.module.modules.KillAuraFacing.yaw();
            this.xRot = com.paprika.module.modules.KillAuraFacing.pitch();
        }
    }
}
