package com.paprika.module.modules;

import com.paprika.baritone.Pathfinder;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public class ScaffoldModule extends Module {
    private static final double REACH = 4.5;

    public ScaffoldModule() {
        super("Scaffold", "Places blocks under you as you walk so you can't fall", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (mc.gui.screen() != null || mc.player.getAbilities().flying || mc.player.isSpectator()) return;

        Vec3 pos = mc.player.position();
        Vec3 next = pos.add(mc.player.getDeltaMovement().x, 0, mc.player.getDeltaMovement().z);

        int y = (int) Math.floor(mc.player.getY() + 1.0E-4) - 1;

        List<BlockPos> spots = new ArrayList<>();
        spots.add(BlockPos.containing(pos.x, y, pos.z));
        spots.add(BlockPos.containing(next.x, y, pos.z));
        spots.add(BlockPos.containing(pos.x, y, next.z));
        spots.add(BlockPos.containing(next.x, y, next.z));

        int placed = 0;
        for (BlockPos spot : spots) {
            if (placed >= 2) break;
            if (!Pathfinder.isReplaceable(mc.level, spot)) continue;
            if (place(spot)) placed++;
        }
    }

    private boolean place(BlockPos spot) {
        Direction face = null;
        BlockPos support = null;
        for (Direction d : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP}) {
            BlockPos n = spot.relative(d);
            if (!Pathfinder.isReplaceable(mc.level, n) && !mc.level.getBlockState(n).getCollisionShape(mc.level, n).isEmpty()) {
                support = n;
                face = d.getOpposite();
                break;
            }
        }
        if (support == null) return false;

        Vec3 hit = Vec3.atCenterOf(support).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
        if (mc.player.getEyePosition().distanceTo(hit) > REACH) return false;

        int slot = blockSlot();
        if (slot < 0) return false;

        int previous = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(slot);
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, support, false));
        mc.player.swing(InteractionHand.MAIN_HAND, net.minecraft.world.item.component.SwingAnimation.DEFAULT, false);
        mc.player.getInventory().setSelectedSlot(previous);
        return true;
    }

    private int blockSlot() {
        int throwaway = Pathfinder.throwawaySlot(mc.player);
        if (throwaway >= 0) return throwaway;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (!(stack.getItem() instanceof BlockItem bi)) continue;
            Block block = bi.getBlock();
            if (block instanceof FallingBlock) continue;
            if (!block.defaultBlockState().isCollisionShapeFullBlock(mc.level, BlockPos.ZERO)) continue;
            return i;
        }
        return -1;
    }
}
