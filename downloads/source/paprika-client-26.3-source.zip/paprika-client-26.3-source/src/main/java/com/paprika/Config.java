package com.paprika;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("paprika.json");
    }

    public static void load() {
        Path path = file();
        if (!Files.exists(path)) return;
        try (Reader reader = Files.newBufferedReader(path)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null || !root.has("enabled")) return;
            Set<String> names = new HashSet<>();
            for (JsonElement e : root.getAsJsonArray("enabled")) names.add(renamed(e.getAsString()));
            if (root.has("settings")) {
                JsonObject settings = root.getAsJsonObject("settings");
                if (settings.has("watermark")) PaprikaClient.watermark = settings.get("watermark").getAsBoolean();
            }
            if (root.has("keybinds")) {
                JsonObject binds = root.getAsJsonObject("keybinds");
                for (String saved : binds.keySet()) {
                    for (Module m : ModuleManager.getModules()) {
                        if (m.getName().equals(renamed(saved))) m.setKeybind(binds.get(saved).getAsInt());
                    }
                }
            }
            if (root.has("settings")) {
                JsonObject s2 = root.getAsJsonObject("settings");
                if (s2.has("theme")) com.paprika.gui.Theme.setByName(s2.get("theme").getAsString());
                if (s2.has("style")) com.paprika.gui.GuiStyle.list = "list".equals(s2.get("style").getAsString());
                if (s2.has("orgSkin")) com.paprika.command.OrgSkins.enabled = s2.get("orgSkin").getAsBoolean();

                if (!root.has("modSettings")) {
                    if (s2.has("speed")) ModuleManager.get(com.paprika.module.modules.SpeedModule.class).speed.set(s2.get("speed").getAsDouble());
                    if (s2.has("autoLogout")) ModuleManager.get(com.paprika.module.modules.AutoLogoutModule.class).distance.set(s2.get("autoLogout").getAsDouble());
                    if (s2.has("boatFlySpeed")) ModuleManager.get(com.paprika.module.modules.BoatFlyModule.class).speed.set(s2.get("boatFlySpeed").getAsDouble());
                }
            }
            if (root.has("friends")) com.paprika.command.Friends.load(root.getAsJsonArray("friends"));
            if (root.has("hud")) com.paprika.gui.HudLayout.load(root.getAsJsonObject("hud"));
            if (root.has("cracked")) com.paprika.command.CrackedAccounts.load(root.getAsJsonArray("cracked"));
            if (root.has("modSettings")) {
                JsonObject all = root.getAsJsonObject("modSettings");
                for (Module m : ModuleManager.getModules()) {
                    if (!all.has(m.getName())) continue;
                    JsonObject mine = all.getAsJsonObject(m.getName());
                    for (com.paprika.module.setting.Setting s : m.getSettings()) {
                        try {
                            if (mine.has(s.getName())) s.load(mine.get(s.getName()));
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
            if (root.has("areas")) com.paprika.command.Areas.load(root.getAsJsonArray("areas"));
            if (root.has("markers")) com.paprika.command.Markers.load(root.getAsJsonArray("markers"));
            if (root.has("baritone")) {
                com.paprika.module.modules.BaritoneModule.loadSettings(root.getAsJsonObject("baritone"));
            }
            for (Module m : ModuleManager.getModules()) {
                if (m.shouldSave() && names.contains(m.getName())) m.setEnabled(true);
            }
        } catch (Exception e) {
            System.err.println("[Paprika] Could not read config: " + e);
        }
    }

    private static String renamed(String name) {
        return switch (name) {
            case "AutoBridge" -> "Scaffold";
            default -> name;
        };
    }

    public static void save() {
        JsonArray enabled = new JsonArray();
        for (Module m : ModuleManager.getModules()) {
            if (m.isEnabled() && m.shouldSave()) enabled.add(m.getName());
        }
        JsonObject root = new JsonObject();
        root.add("enabled", enabled);
        root.add("baritone", com.paprika.module.modules.BaritoneModule.saveSettings());
        JsonObject settings = new JsonObject();
        settings.addProperty("watermark", PaprikaClient.watermark);
        settings.addProperty("theme", com.paprika.gui.Theme.current().name());
        settings.addProperty("style", com.paprika.gui.GuiStyle.list ? "list" : "menu");
        settings.addProperty("orgSkin", com.paprika.command.OrgSkins.enabled);
        JsonObject binds = new JsonObject();
        for (Module m : ModuleManager.getModules()) {
            if (m.getKeybind() != -1) binds.addProperty(m.getName(), m.getKeybind());
        }
        root.add("keybinds", binds);
        JsonObject modSettings = new JsonObject();
        for (Module m : ModuleManager.getModules()) {
            if (!m.hasSettings()) continue;
            JsonObject mine = new JsonObject();
            for (com.paprika.module.setting.Setting s : m.getSettings()) mine.add(s.getName(), s.save());
            modSettings.add(m.getName(), mine);
        }
        root.add("modSettings", modSettings);
        root.add("settings", settings);
        root.add("friends", com.paprika.command.Friends.save());
        root.add("hud", com.paprika.gui.HudLayout.save());
        root.add("cracked", com.paprika.command.CrackedAccounts.save());
        root.add("areas", com.paprika.command.Areas.save());
        root.add("markers", com.paprika.command.Markers.save());
        try {
            Path path = file();
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(path)) {
                GSON.toJson(root, writer);
            }
        } catch (Exception e) {
            System.err.println("[Paprika] Could not save config: " + e);
        }
    }
}
