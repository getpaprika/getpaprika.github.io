package com.paprika.gui;

import com.mojang.blaze3d.platform.InputConstants;
import com.paprika.Config;
import com.paprika.command.CrackedAccounts;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CrackedNewScreen extends Screen {
    private final Screen parent;
    private EditBox name;
    private String error = "";

    public CrackedNewScreen(Screen parent) {
        super(Component.literal("New account"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2, cy = height / 2;
        String old = name == null ? "" : name.getValue();
        name = new EditBox(font, cx - 100, cy - 20, 200, 20, Component.literal("Account name"));
        name.setMaxLength(16);
        name.setValue(old);
        name.setHint(Component.literal("Account name").withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
        name.setResponder(t -> error = "");
        addRenderableWidget(name);
        setInitialFocus(name);
        addRenderableWidget(Button.builder(Component.literal("Create"), b -> create()).bounds(cx - 100, cy + 10, 98, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose()).bounds(cx + 2, cy + 10, 98, 20).build());
    }

    private void create() {
        String n = name.getValue().trim();
        if (!CrackedAccounts.validName(n)) {
            error = "3-16 letters, numbers or _";
            return;
        }
        if (!CrackedAccounts.add(n)) {
            error = "You already have that account";
            return;
        }
        Config.save();
        onClose();
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent paprika$k) {
        int keyCode = paprika$k.key(), scanCode = paprika$k.keycode(), modifiers = paprika$k.modifiers();
        if (keyCode == InputConstants.KEY_RETURN || keyCode == InputConstants.KEY_NUMPADENTER) {
            create();
            return true;
        }
        return super.keyPressed(paprika$k);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        g.centeredText(font, title, width / 2, height / 2 - 50, 0xFFFFFFFF);
        g.centeredText(font, "Name of the account:", width / 2, height / 2 - 34, 0xFFAAAAAA);
        if (!error.isEmpty()) g.centeredText(font, error, width / 2, height / 2 + 36, 0xFFFF5555);
    }

    @Override
    public void onClose() {
        minecraft.gui.setScreen(parent);
    }
}
