package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class EspPModule extends Module {
    public EspPModule() {
        super("ESPP", "Red boxes around players, visible through walls", Category.RENDER);
    }
}
