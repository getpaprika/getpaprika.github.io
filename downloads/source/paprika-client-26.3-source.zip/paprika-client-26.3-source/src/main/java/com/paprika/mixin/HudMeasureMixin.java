package com.paprika.mixin;

import com.paprika.gui.HudMeasure;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GuiGraphicsExtractor.class)
public abstract class HudMeasureMixin {
    @Inject(method = "drawString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V", at = @At("HEAD"), require = 0)
    private void paprika$text(Font font, String text, int x, int y, int color, boolean shadow, CallbackInfo ci) {
        if (text != null) HudMeasure.add(x, y, x + font.width(text), y + font.lineHeight);
    }

    @Inject(method = "drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;IIIZ)V", at = @At("HEAD"), require = 0)
    private void paprika$text2(Font font, FormattedCharSequence text, int x, int y, int color, boolean shadow, CallbackInfo ci) {
        HudMeasure.add(x, y, x + font.width(text), y + font.lineHeight);
    }

    @Inject(method = "fill(IIIII)V", at = @At("HEAD"), require = 0)
    private void paprika$fill(int x1, int y1, int x2, int y2, int color, CallbackInfo ci) {
        HudMeasure.add(x1, y1, x2, y2);
    }

    @Inject(method = "renderItem(Lnet/minecraft/world/item/ItemStack;II)V", at = @At("HEAD"), require = 0)
    private void paprika$item(ItemStack stack, int x, int y, CallbackInfo ci) {
        HudMeasure.add(x, y, x + 16, y + 16);
    }
}
