package com.paprika;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public final class ConfigProfiles {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static String active;

    private ConfigProfiles() {}

    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("paprika").resolve("configs");
    }

    public static String active() { return active; }

    public static boolean validName(String name) {
        return name.matches("[A-Za-z0-9 _-]{1,24}") && !name.isBlank();
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        if (!Files.isDirectory(dir())) return out;
        try (Stream<Path> files = Files.list(dir())) {
            files.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
                    .map(n -> n.substring(0, n.length() - 5)).sorted(String.CASE_INSENSITIVE_ORDER).forEach(out::add);
        } catch (Exception ignored) {
        }
        return out;
    }

    public static boolean exists(String name) {
        for (String n : list()) if (n.equalsIgnoreCase(name)) return true;
        return false;
    }

    public static boolean create(String name) {
        name = name.trim();
        if (!validName(name) || exists(name)) return false;
        JsonObject root = new JsonObject();
        JsonArray enabled = new JsonArray();
        JsonObject binds = new JsonObject();
        JsonObject settings = new JsonObject();
        for (Module m : ModuleManager.getModules()) {
            if (m.shouldSave() && m.isEnabled()) enabled.add(m.getName());
            if (m.getKeybind() != -1) binds.addProperty(m.getName(), m.getKeybind());
            if (m.hasSettings()) {
                JsonObject mine = new JsonObject();
                for (Setting s : m.getSettings()) mine.add(s.getName(), s.save());
                settings.add(m.getName(), mine);
            }
        }
        root.add("enabled", enabled);
        root.add("keybinds", binds);
        root.add("modSettings", settings);
        try {
            Files.createDirectories(dir());
            try (Writer writer = Files.newBufferedWriter(dir().resolve(name + ".json"))) {
                GSON.toJson(root, writer);
            }
            active = name;
            return true;
        } catch (Exception e) {
            System.err.println("[Paprika] Could not save config " + name + ": " + e);
            return false;
        }
    }

    public static void load(String name) {
        Path file = dir().resolve(name + ".json");
        if (!Files.exists(file)) return;
        try (Reader reader = Files.newBufferedReader(file)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null) return;
            Set<String> on = new HashSet<>();
            if (root.has("enabled")) for (JsonElement e : root.getAsJsonArray("enabled")) on.add(e.getAsString());
            JsonObject binds = root.has("keybinds") ? root.getAsJsonObject("keybinds") : new JsonObject();
            JsonObject settings = root.has("modSettings") ? root.getAsJsonObject("modSettings") : new JsonObject();
            for (Module m : ModuleManager.getModules()) {
                m.resetSettings();
                if (settings.has(m.getName())) {
                    JsonObject mine = settings.getAsJsonObject(m.getName());
                    for (Setting s : m.getSettings()) {
                        try {
                            if (mine.has(s.getName())) s.load(mine.get(s.getName()));
                        } catch (Exception ignored) {
                        }
                    }
                }
                m.setKeybind(binds.has(m.getName()) ? binds.get(m.getName()).getAsInt() : -1);
                if (m.shouldSave()) m.setEnabled(on.contains(m.getName()));
            }
            active = name;
            Config.save();
        } catch (Exception e) {
            System.err.println("[Paprika] Could not load config " + name + ": " + e);
        }
    }

    public static void delete(String name) {
        try {
            Files.deleteIfExists(dir().resolve(name + ".json"));
        } catch (Exception ignored) {
        }
        if (name.equals(active)) active = null;
    }
}
