package com.paprika.mixin;

import com.paprika.module.modules.Chams;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityTeamColorMixin {
    @Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true)
    private void paprika$chamsColor(CallbackInfoReturnable<Integer> cir) {
        int color = Chams.colorFor((Entity) (Object) this);
        if (color != -1) cir.setReturnValue(color);
    }
}
