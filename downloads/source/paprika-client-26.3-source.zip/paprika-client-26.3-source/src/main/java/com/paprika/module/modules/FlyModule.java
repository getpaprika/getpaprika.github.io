package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.entity.player.Abilities;

public class FlyModule extends Module {
    public final NumberSetting flySpeed = number("Fly speed", "1 = normal creative flying speed", 1, 0.5, 10, 0.5, "x");

    public FlyModule() {
        super("Fly", "Fly like in creative mode", Category.MOVEMENT);
    }

    private static int sinceFlying = 100;

    public static boolean shouldSpoof() {
        if (!com.paprika.module.ModuleManager.isOn(FlyModule.class)) return false;
        net.minecraft.client.Minecraft m = net.minecraft.client.Minecraft.getInstance();
        if (!m.isSameThread() || m.player == null) return false;
        if (m.player.isCreative() || m.player.isSpectator() || m.player.isFallFlying()) return false;
        return m.player.getAbilities().flying || sinceFlying <= 3;
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.getAbilities().flying) {
            sinceFlying = 0;
            mc.player.fallDistance = 0;
        } else if (sinceFlying < 100) {
            sinceFlying++;
        }

        mc.player.getAbilities().mayfly = true;
        mc.player.getAbilities().setFlyingSpeed(0.05F * (float) flySpeed.get());
    }

    @Override
    protected void onDisable() {
        if (mc.player == null) return;
        if (mc.player.isCreative() || mc.player.isSpectator()) return;
        Abilities abilities = mc.player.getAbilities();
        abilities.mayfly = false;
        abilities.flying = false;
        abilities.setFlyingSpeed(0.05F);
    }
}
