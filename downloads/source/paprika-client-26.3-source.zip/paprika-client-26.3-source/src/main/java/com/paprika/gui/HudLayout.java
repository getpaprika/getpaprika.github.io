package com.paprika.gui;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.HashMap;
import java.util.Map;

public final class HudLayout {
    private static final Map<String, float[]> POS = new HashMap<>();

    private HudLayout() {}

    public static float[] get(String id) { return POS.get(id); }

    public static void set(String id, float fx, float fy) { POS.put(id, new float[] {fx, fy}); }

    public static void reset(String id) { POS.remove(id); }

    public static JsonObject save() {
        JsonObject o = new JsonObject();
        for (Map.Entry<String, float[]> e : POS.entrySet()) {
            JsonArray a = new JsonArray();
            a.add(e.getValue()[0]);
            a.add(e.getValue()[1]);
            o.add(e.getKey(), a);
        }
        return o;
    }

    public static void load(JsonObject o) {
        POS.clear();
        for (String key : o.keySet()) {
            JsonElement el = o.get(key);
            if (el.isJsonArray() && el.getAsJsonArray().size() == 2) {
                POS.put(key, new float[] {el.getAsJsonArray().get(0).getAsFloat(), el.getAsJsonArray().get(1).getAsFloat()});
            }
        }
    }
}
