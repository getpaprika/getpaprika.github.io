package com.paprika.mixin;

import com.paprika.gui.PaprikaTitleScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(net.minecraft.client.gui.Gui.class)
public abstract class TitleScreenMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen paprika$title(Screen screen) {
        return screen != null && screen.getClass() == TitleScreen.class ? new PaprikaTitleScreen() : screen;
    }
}
