package com.paprika.module.modules;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class BastionWModule extends StructureWModule {
    private static final Map<Block, String> TYPES = new LinkedHashMap<>();
    private static final String[] ORDER = {"gold", "gilded", "bricks", "cracked", "chiseled"};

    static {
        TYPES.put(Blocks.GOLD_BLOCK, "gold");
        TYPES.put(Blocks.GILDED_BLACKSTONE, "gilded");
        TYPES.put(Blocks.POLISHED_BLACKSTONE_BRICKS, "bricks");
        TYPES.put(Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS, "cracked");
        TYPES.put(Blocks.CHISELED_POLISHED_BLACKSTONE, "chiseled");
    }

    public BastionWModule() {
        super("BastionW", "Finds bastions in loaded chunks and shows them in gold");
    }

    @Override protected Map<Block, String> types() { return TYPES; }
    @Override protected String[] order() { return ORDER; }
    @Override protected Set<String> sureTypes() { return Set.of("gilded"); }

    @Override protected Set<String> requiredTypes() { return Set.of("gilded", "gold"); }
    @Override protected String specialType() { return "gold"; }
    @Override protected String specialMessage(BlockPos p) { return "Gold blocks (treasure room?) at " + p.getX() + ", " + p.getY() + ", " + p.getZ() + "!"; }
    @Override protected int minBlocks() { return 60; }
    @Override protected String structureName() { return "Bastion"; }
    @Override protected boolean scanHere() { return mc.level.dimension() == Level.NETHER; }
    @Override public int fillColor() { return 0x4DFFAA00; }
    @Override public int outlineColor() { return 0xFFFFAA00; }
    @Override public int labelColor() { return 0xFFFFCC55; }

    @Override
    protected String nice(String type, int n) {
        return n + " " + switch (type) {
            case "gold" -> n == 1 ? "gold block" : "gold blocks";
            case "gilded" -> "gilded blackstone";
            case "bricks" -> "blackstone bricks";
            case "cracked" -> "cracked blackstone bricks";
            case "chiseled" -> "chiseled blackstone";
            default -> type;
        };
    }
}
