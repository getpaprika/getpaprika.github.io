package com.paprika.gui;

import com.paprika.PaprikaClient;
import com.paprika.command.OrgSkins;
import com.paprika.module.modules.BaritoneModule;

import java.util.List;
import java.util.function.BooleanSupplier;

public final class GlobalToggles {
    public record Toggle(String name, String desc, BooleanSupplier get, Runnable flip) {}

    private GlobalToggles() {}

    public static List<Toggle> all() {
        return List.of(
                new Toggle("Watermark", "The red dye + Paprika Client in the top left",
                        () -> PaprikaClient.watermark, () -> PaprikaClient.watermark = !PaprikaClient.watermark),
                new Toggle("Real skins (orgSkin)", "Load real skins on servers that don't show them",
                        () -> OrgSkins.enabled, () -> {
                            OrgSkins.enabled = !OrgSkins.enabled;
                            if (OrgSkins.enabled) OrgSkins.retryMisses();
                        }),
                new Toggle("Baritone: avoid danger", "Baritone kills hostile mobs that come close before continuing",
                        BaritoneModule::avoidDanger, () -> BaritoneModule.setAvoidDanger(!BaritoneModule.avoidDanger())),
                new Toggle("Baritone: auto eat", "Baritone eats when you're hungry during a task",
                        BaritoneModule::autoEat, () -> BaritoneModule.setAutoEat(!BaritoneModule.autoEat())));
    }
}
