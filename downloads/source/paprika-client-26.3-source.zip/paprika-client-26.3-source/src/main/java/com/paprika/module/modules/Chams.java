package com.paprika.module.modules;

import com.paprika.command.Friends;
import com.paprika.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

public final class Chams {
    private Chams() {}

    public static int colorFor(Entity e) {
        if (e instanceof Player p) {
            if (p == Minecraft.getInstance().player || !ModuleManager.isOn(PChamsModule.class)) return -1;
            return Friends.is(p) ? 0x55FFFF : 0xFF0000;
        }
        if (e instanceof Mob mob) {
            boolean hostile = mob instanceof Enemy || mob instanceof NeutralMob;
            if (hostile) return ModuleManager.isOn(MChamsModule.class) ? 0xFF8800 : -1;
            return ModuleManager.isOn(EChamsModule.class) ? 0x00FF00 : -1;
        }
        return -1;
    }
}
