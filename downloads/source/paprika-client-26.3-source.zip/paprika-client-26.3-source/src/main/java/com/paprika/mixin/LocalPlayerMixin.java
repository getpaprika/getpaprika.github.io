package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.NoSlowModule;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin {
    @Redirect(method = "modifyInput", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;isUsingItem()Z"))
    private boolean paprika$noSlow(LocalPlayer player) {
        if (ModuleManager.isOn(NoSlowModule.class)) return false;
        return player.isUsingItem();
    }
}
