package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class TracersMModule extends Module {
    public TracersMModule() {
        super("TracersM", "Lines to hostile and neutral mobs (same color as ESPM)", Category.RENDER);
    }
}
