package com.paprika.gui;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.ChestStealerModule;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.DispenserMenu;
import net.minecraft.world.inventory.HopperMenu;
import net.minecraft.world.inventory.ShulkerBoxMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BlockItem;

public final class ChestStealer {
    private ChestStealer() {}

    public static void addButtons(Screen screen, int width, int height) {
        if (!ModuleManager.isOn(ChestStealerModule.class)) return;
        if (!(screen instanceof AbstractContainerScreen<?> container)) return;
        AbstractContainerMenu menu = container.getMenu();

        int imageHeight;
        if (menu instanceof ChestMenu chest) imageHeight = 114 + chest.getRowCount() * 18;
        else if (menu instanceof ShulkerBoxMenu || menu instanceof DispenserMenu) imageHeight = 166;
        else if (menu instanceof HopperMenu) imageHeight = 133;
        else return;

        int left = (width - 176) / 2;
        int top = (height - imageHeight) / 2;
        int y = Math.max(2, top - 22);

        Screens.getWidgets(screen).add(Button.builder(Component.literal("Blocks"), b -> take(menu, true))
                .bounds(left, y, 60, 20).build());
        Screens.getWidgets(screen).add(Button.builder(Component.literal("Items"), b -> take(menu, false))
                .bounds(left + 64, y, 60, 20).build());
    }

    private static void take(AbstractContainerMenu menu, boolean blocks) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null) return;
        int storageSlots = menu.slots.size() - 36;
        for (int i = 0; i < storageSlots; i++) {
            Slot slot = menu.slots.get(i);
            if (!slot.hasItem()) continue;
            boolean isBlock = slot.getItem().getItem() instanceof BlockItem;
            if (isBlock == blocks) {
                mc.gameMode.handleContainerInput(menu.containerId, i, 0, ContainerInput.QUICK_MOVE, mc.player);
            }
        }
    }
}
