package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class PChamsModule extends Module {
    public PChamsModule() {
        super("PChams", "Players get a red glowing outline through walls (friends in aqua)", Category.RENDER);
    }
}
