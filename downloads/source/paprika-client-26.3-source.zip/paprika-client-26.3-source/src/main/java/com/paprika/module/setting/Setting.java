package com.paprika.module.setting;

import com.google.gson.JsonElement;

public abstract class Setting {
    private final String name;
    private final String description;

    protected Setting(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }

    public abstract void reset();

    public abstract JsonElement save();

    public abstract void load(JsonElement json);
}
