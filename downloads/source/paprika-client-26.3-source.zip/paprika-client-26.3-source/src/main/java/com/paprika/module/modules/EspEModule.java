package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class EspEModule extends Module {
    public EspEModule() {
        super("ESPE", "Green boxes around passive mobs", Category.RENDER);
    }
}
