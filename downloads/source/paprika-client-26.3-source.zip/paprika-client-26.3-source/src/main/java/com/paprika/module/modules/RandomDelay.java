package com.paprika.module.modules;

import java.util.concurrent.ThreadLocalRandom;

public final class RandomDelay {
    private long readySince = -1;
    private long waitMs;

    public void reset() {
        readySince = -1;
    }

    public boolean passed(double maxMs) {
        long now = System.currentTimeMillis();
        if (readySince < 0) {
            readySince = now;
            waitMs = maxMs <= 0 ? 0 : Math.round(ThreadLocalRandom.current().nextDouble() * maxMs);
        }
        if (now - readySince < waitMs) return false;
        readySince = -1;
        return true;
    }
}
