package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.NExpModule;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleEngine.class)
public abstract class ParticleEngineMixin {
    @Inject(method = "createParticle", at = @At("HEAD"), cancellable = true)
    private void paprika$noExplosions(ParticleOptions options, double x, double y, double z,
                                      double xSpeed, double ySpeed, double zSpeed,
                                      CallbackInfoReturnable<Particle> cir) {
        if (!ModuleManager.isOn(NExpModule.class)) return;
        if (options.getType() == ParticleTypes.EXPLOSION || options.getType() == ParticleTypes.EXPLOSION_EMITTER) {
            cir.setReturnValue(null);
        }
    }
}
