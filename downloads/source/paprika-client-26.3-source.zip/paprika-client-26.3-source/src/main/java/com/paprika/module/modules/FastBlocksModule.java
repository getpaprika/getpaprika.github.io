package com.paprika.module.modules;

import com.paprika.mixin.MinecraftAccessor;
import com.paprika.mixin.MultiPlayerGameModeAccessor;
import com.paprika.module.Category;
import com.paprika.module.Module;

public class FastBlocksModule extends Module {
    public FastBlocksModule() {
        super("FastBlocks", "Place and break blocks without the delay", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) return;
        ((MinecraftAccessor) mc).paprika$setRightClickDelay(0);
        ((MultiPlayerGameModeAccessor) mc.gameMode).paprika$setDestroyDelay(0);
    }
}
