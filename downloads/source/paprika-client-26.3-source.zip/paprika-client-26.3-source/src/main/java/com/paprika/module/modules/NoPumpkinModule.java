package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class NoPumpkinModule extends Module {
    public NoPumpkinModule() {
        super("NoPumpkin", "Removes the pumpkin overlay when you wear a carved pumpkin", Category.RENDER);
    }
}
