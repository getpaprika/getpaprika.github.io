package com.paprika.render;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.HealthHudModule;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.gizmos.TextGizmo;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;

public final class HealthHudRenderer {
    private HealthHudRenderer() {}

    public static void render(LevelRenderContext ctx) {
        if (!ModuleManager.isOn(HealthHudModule.class)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.gui.hud.isHidden()) return;

        float pt = RenderUtil.partialTick(ctx);
        Vec3 cam = mc.gameRenderer.mainCamera().position();

        for (Player p : mc.level.players()) {
            if (com.paprika.module.modules.BlinkModule.isClone(p)) continue;
            if (p == mc.player || !p.isAlive() || p.isInvisible() || p.isSpectator()) continue;
            if (p.distanceToSqr(cam) > 64 * 64) continue;

            float hp = p.getHealth() + p.getAbsorptionAmount();
            float ratio = Mth.clamp(p.getHealth() / Math.max(1.0F, p.getMaxHealth()), 0.0F, 1.0F);
            int color = ratio > 0.66F ? 0x55FF55 : ratio > 0.33F ? 0xFFFF55 : 0xFF5555;
            String text = (hp == Math.floor(hp) ? String.valueOf((int) hp) : String.format(Locale.ROOT, "%.1f", hp)) + "\u2764";

            double x = Mth.lerp(pt, p.xo, p.getX());
            double y = Mth.lerp(pt, p.yo, p.getY()) + p.getBbHeight() + 0.8;
            double z = Mth.lerp(pt, p.zo, p.getZ());
            Gizmos.billboardText(text, new Vec3(x, y, z), TextGizmo.Style.forColorAndCentered(0xFF000000 | color).withScale(0.4F));
        }
    }
}
