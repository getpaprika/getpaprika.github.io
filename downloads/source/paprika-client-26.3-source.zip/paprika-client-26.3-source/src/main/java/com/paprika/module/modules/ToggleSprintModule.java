package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class ToggleSprintModule extends Module {
    public ToggleSprintModule() {
        super("ToggleSprint", "Sprints automatically when you walk forward", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.player.input == null) return;

        boolean canSprint = mc.player.input.hasForwardImpulse()
                && !mc.player.isShiftKeyDown()
                && !mc.player.isUsingItem()
                && !mc.player.horizontalCollision
                && (mc.player.getFoodData().getFoodLevel() > 6 || mc.player.getAbilities().mayfly);

        if (canSprint && !mc.player.isSprinting()) {
            mc.player.setSprinting(true);
        }
    }
}
