package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.setting.NumberSetting;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public class AimAssistPModule extends Module {
    public final NumberSetting range = number("Range", "How far away targets can be", 5, 2, 10, 0.5, " blocks");
    public final NumberSetting fov = number("FOV", "Only targets this close to your crosshair", 60, 10, 180, 5, "\u00b0");
    public final NumberSetting strength = number("Strength", "How hard it pulls your aim", 3, 1, 10, 1, "");

    public AimAssistPModule() {
        super("AimAssistP", "Pulls your aim toward players", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gui.screen() != null) return;
        if (FreeLookModule.active() != null || FreecamModule.active() != null) return;
        Vec3 eye = mc.player.getEyePosition();
        LivingEntity best = null;
        double bestAngle = fov.get() / 2.0;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!Targets.player(e) || !(e instanceof LivingEntity living)) continue;
            if (mc.player.distanceTo(e) > range.get() || !mc.player.hasLineOfSight(e)) continue;
            double angle = angleTo(eye, aimPoint(living));
            if (angle < bestAngle) {
                bestAngle = angle;
                best = living;
            }
        }
        if (best == null) return;

        AimSmoother.offer(best, strength.get(), bestAngle);
    }

    private static Vec3 aimPoint(LivingEntity e) {
        return new Vec3(e.getX(), e.getY() + e.getBbHeight() * 0.6, e.getZ());
    }

    private double angleTo(Vec3 eye, Vec3 point) {
        Vec3 look = mc.player.getLookAngle();
        Vec3 dir = point.subtract(eye).normalize();
        return Math.toDegrees(Math.acos(Mth.clamp(look.dot(dir), -1.0, 1.0)));
    }
}
