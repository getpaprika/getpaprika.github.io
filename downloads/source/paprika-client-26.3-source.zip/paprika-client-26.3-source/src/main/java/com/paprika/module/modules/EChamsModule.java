package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class EChamsModule extends Module {
    public EChamsModule() {
        super("EChams", "Passive mobs get a green glowing outline through walls", Category.RENDER);
    }
}
