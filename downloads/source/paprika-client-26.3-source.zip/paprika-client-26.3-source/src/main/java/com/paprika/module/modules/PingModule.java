package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.PlayerInfo;

public class PingModule extends Module {
    public PingModule() {
        super("Ping", "Shows your ping in ms", Category.RENDER);
    }

    @Override
    public int onRender(GuiGraphicsExtractor graphics, int x, int y) {
        if (mc.player == null || mc.getConnection() == null) return 0;
        PlayerInfo me = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        int ping = me == null ? 0 : me.getLatency();
        graphics.text(mc.font, "Ping: " + ping + " ms", x, y, 0xFFFFFFFF, true);
        return mc.font.lineHeight + 2;
    }

    @Override
    public int onRenderPreview(GuiGraphicsExtractor graphics, int x, int y) {
        if (mc.player != null && mc.getConnection() != null) return onRender(graphics, x, y);
        graphics.text(mc.font, "Ping: 42 ms", x, y, 0xFFFFFFFF, true);
        return mc.font.lineHeight + 2;
    }
}
