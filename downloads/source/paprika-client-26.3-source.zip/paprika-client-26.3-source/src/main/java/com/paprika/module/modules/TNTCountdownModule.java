package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;

public class TNTCountdownModule extends Module {
    public final com.paprika.module.setting.NumberSetting maxDistance =
            number("Range", "TNT further away than this has no timer", 64, 16, 128, 4, " blocks");

    public TNTCountdownModule() {
        super("TNTCountdown", "Shows a timer above lit TNT until it explodes", Category.UTILITY);
    }

    @Override
    protected void onDisable() {
        com.paprika.render.TntTimerRenderer.clear();
    }
}
