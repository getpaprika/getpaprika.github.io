package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.setting.BoolSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class XrayModule extends Module {
    private static final Set<Block> EXTRA = Set.of(
            Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.ENDER_CHEST,
            Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER,
            Blocks.ANCIENT_DEBRIS
    );

    private static final Map<Block, Boolean> CACHE = new ConcurrentHashMap<>();

    public final BoolSetting onlyExposed = bool("OnlyExposed", "Only show ores that touch air, hide ores buried in stone", false);

    private static volatile boolean exposedOnly = false;
    private boolean lastExposed = false;

    public XrayModule() {
        super("Xray", "See ores, beds, chests and furnaces through walls", Category.RENDER);
    }

    private static boolean isOre(BlockState state) {
        Block block = state.getBlock();
        return block == Blocks.ANCIENT_DEBRIS
                || BuiltInRegistries.BLOCK.getKey(block).getPath().endsWith("_ore");
    }

    public static boolean isVisible(BlockState state, BlockGetter level, BlockPos pos) {
        if (!isVisible(state)) return false;
        if (!exposedOnly || level == null || pos == null || !isOre(state)) return true;
        BlockPos.MutableBlockPos n = new BlockPos.MutableBlockPos();
        for (Direction d : Direction.values()) {
            n.setWithOffset(pos, d);
            try {
                if (level.getBlockState(n).isAir()) return true;
            } catch (Exception e) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onTick() {
        boolean now = onlyExposed.get();
        exposedOnly = now;
        if (now != lastExposed) {
            lastExposed = now;
            if (mc.levelExtractor != null && mc.level != null) mc.levelExtractor.allChanged();
        }
    }

    public static boolean isVisible(BlockState state) {
        Block block = state.getBlock();
        Boolean cached = CACHE.get(block);
        if (cached != null) return cached;
        boolean visible = EXTRA.contains(block)
                || state.is(BlockTags.BEDS)
                || BuiltInRegistries.BLOCK.getKey(block).getPath().endsWith("_ore");
        CACHE.put(block, visible);
        return visible;
    }

    public static void updateCulling() {
        mc.smartCull = !(com.paprika.module.ModuleManager.isOn(XrayModule.class)
                || com.paprika.module.ModuleManager.isOn(FreecamModule.class));
    }

    @Override
    protected void onEnable() { refresh(true); }

    @Override
    protected void onDisable() { refresh(false); }

    private void refresh(boolean on) {
        exposedOnly = onlyExposed.get();
        lastExposed = exposedOnly;

        updateCulling();
        if (mc.levelExtractor != null && mc.level != null) {
            mc.levelExtractor.allChanged();
        }
    }
}
