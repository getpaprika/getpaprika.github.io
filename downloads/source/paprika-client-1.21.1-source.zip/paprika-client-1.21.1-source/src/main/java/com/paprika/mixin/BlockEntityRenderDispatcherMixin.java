package com.paprika.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.paprika.module.ModuleManager;
import com.paprika.module.modules.EntityCullingModule;
import com.paprika.module.modules.XrayModule;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockEntityRenderDispatcher.class)
public abstract class BlockEntityRenderDispatcherMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void paprika$hideBlockEntities(BlockEntity blockEntity, float partialTick,
                                           PoseStack poseStack, MultiBufferSource buffers,
                                           CallbackInfo ci) {
        if (ModuleManager.isOn(XrayModule.class)) {
            if (!XrayModule.isVisible(blockEntity.getBlockState())) ci.cancel();
            return;
        }
        if (ModuleManager.isOn(EntityCullingModule.class)
                && !EntityCullingModule.isBlockEntityVisible(blockEntity.getBlockPos())) {
            ci.cancel();
        }
    }
}
