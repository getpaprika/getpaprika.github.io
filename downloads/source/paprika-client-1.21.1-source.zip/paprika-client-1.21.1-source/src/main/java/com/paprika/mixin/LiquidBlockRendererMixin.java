package com.paprika.mixin;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.paprika.module.ModuleManager;
import com.paprika.module.modules.XrayModule;
import net.minecraft.client.renderer.block.LiquidBlockRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LiquidBlockRenderer.class)
public abstract class LiquidBlockRendererMixin {
    @Inject(method = "tesselate", at = @At("HEAD"), cancellable = true)
    private void paprika$hideFluids(BlockAndTintGetter level, BlockPos pos, VertexConsumer consumer,
                                    BlockState blockState, FluidState fluidState, CallbackInfo ci) {
        if (ModuleManager.isOn(XrayModule.class)) {
            ci.cancel();
        }
    }
}
