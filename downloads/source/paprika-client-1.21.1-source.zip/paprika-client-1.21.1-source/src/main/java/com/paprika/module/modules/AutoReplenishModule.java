package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TieredItem;

public class AutoReplenishModule extends Module {
    private final ItemStack[] last = new ItemStack[9];

    public AutoReplenishModule() {
        super("AutoReplenish", "Refills empty hotbar slots and replaces broken tools", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) return;

        boolean canAct = mc.screen == null && mc.player.containerMenu == mc.player.inventoryMenu;

        for (int i = 0; i < 9; i++) {
            ItemStack now = mc.player.getInventory().getItem(i);
            ItemStack before = last[i];
            if (canAct && before != null && !before.isEmpty() && now.isEmpty()) {
                int from = findReplacement(before);
                if (from >= 0) {
                    mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, from, i, ClickType.SWAP, mc.player);
                }
            }
        }
        for (int i = 0; i < 9; i++) last[i] = mc.player.getInventory().getItem(i).copy();
    }

    private int findReplacement(ItemStack before) {
        Item item = before.getItem();
        for (int j = 9; j < 36; j++) {
            if (mc.player.getInventory().getItem(j).is(item)) return j;
        }

        Class<?> kind = toolKind(item);
        if (kind == null) return -1;
        float oldSpeed = ((TieredItem) item).getTier().getSpeed();
        int best = -1;
        float bestSpeed = oldSpeed - 0.001F;
        for (int j = 9; j < 36; j++) {
            Item other = mc.player.getInventory().getItem(j).getItem();
            if (toolKind(other) != kind) continue;
            float speed = ((TieredItem) other).getTier().getSpeed();
            if (speed > bestSpeed) {
                bestSpeed = speed;
                best = j;
            }
        }
        return best;
    }

    private static Class<?> toolKind(Item item) {
        if (item instanceof SwordItem) return SwordItem.class;
        if (item instanceof PickaxeItem) return PickaxeItem.class;
        if (item instanceof AxeItem) return AxeItem.class;
        if (item instanceof ShovelItem) return ShovelItem.class;
        if (item instanceof HoeItem) return HoeItem.class;
        return null;
    }
}
