package com.paprika.gui;

import com.paprika.PaprikaClient;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.modules.SpecWModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class HudRenderer {
    public record Rect(int x, int y, int w, int h) {
        public boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    public record Element(String id, String name, Module module) {
        public boolean on() { return module == null ? PaprikaClient.watermark : module.isEnabled(); }
    }

    private static final ItemStack RED_DYE = new ItemStack(Items.RED_DYE);
    private static final Map<String, Rect> NATURAL = new HashMap<>();
    private static final Map<String, Rect> SHOWN = new LinkedHashMap<>();
    private static List<Element> elements;

    private HudRenderer() {}

    public static List<Element> elements() {
        if (elements == null) {
            List<Element> list = new ArrayList<>();
            list.add(new Element("watermark", "Watermark", null));
            for (Module m : ModuleManager.getModules()) {
                if (m instanceof SpecWModule) continue;
                try {
                    if (m.getClass().getMethod("onRender", GuiGraphics.class, int.class, int.class).getDeclaringClass() != Module.class) {
                        list.add(new Element(m.getName(), m.getName(), m));
                    }
                } catch (NoSuchMethodException ignored) {
                }
            }
            elements = list;
        }
        return elements;
    }

    public static Map<String, Rect> shown() {
        return SHOWN;
    }

    public static void render(GuiGraphics g) {
        render(g, false);
    }

    private static List<Element> order(boolean preview) {
        if (!preview) return elements();
        List<Element> list = new ArrayList<>();
        for (Element el : elements()) if (el.on()) list.add(el);
        for (Element el : elements()) if (!el.on()) list.add(el);
        return list;
    }

    public static void render(GuiGraphics g, boolean preview) {
        Minecraft mc = Minecraft.getInstance();
        int width = mc.getWindow().getGuiScaledWidth(), height = mc.getWindow().getGuiScaledHeight();
        SHOWN.clear();
        int stackY = 4;
        for (Element el : order(preview)) {
            if (!preview && !el.on()) continue;
            float[] pos = HudLayout.get(el.id());
            int ox = el.module() == null ? 2 : 4;
            int oy = pos != null ? 4 : (el.module() == null ? 2 : stackY);
            Rect prev = NATURAL.get(el.id());
            int px = 0, py = 0;
            g.pose().pushPose();
            if (pos != null && prev != null) {
                px = clamp(Math.round(pos[0] * width), 0, width - prev.w());
                py = clamp(Math.round(pos[1] * height), 0, height - prev.h());
                g.pose().translate(px - prev.x(), py - prev.y(), 0);
            }
            HudMeasure.begin();
            int h;
            if (el.module() == null) {
                g.renderItem(RED_DYE, ox, oy);
                g.drawString(mc.font, PaprikaClient.NAME, ox + 18, oy + 4, PaprikaClient.RED, true);
                h = 20;
            } else {
                h = preview ? el.module().onRenderPreview(g, ox, oy) : el.module().onRender(g, ox, oy);
            }
            Rect r = HudMeasure.end();
            g.pose().popPose();
            if (r != null) {
                NATURAL.put(el.id(), r);
                SHOWN.put(el.id(), pos != null && prev != null ? new Rect(px, py, r.w(), r.h()) : r);
            }
            if (pos == null) stackY = el.module() == null ? 22 : stackY + h;
        }

        SpecWModule specW = ModuleManager.get(SpecWModule.class);
        if (specW != null && specW.isEnabled()) specW.onRender(g, 4, 0);
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(Math.max(min, max), v));
    }
}
