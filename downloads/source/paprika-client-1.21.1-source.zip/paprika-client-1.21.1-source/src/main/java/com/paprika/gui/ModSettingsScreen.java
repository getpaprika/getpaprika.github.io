package com.paprika.gui;

import com.paprika.Config;
import com.paprika.module.Module;
import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.ModeSetting;
import com.paprika.module.setting.NumberSetting;
import com.paprika.module.setting.Setting;
import com.paprika.module.setting.TextSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ModSettingsScreen extends Screen {
    private static final int PANEL_BG = 0x66000000;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFF888888;
    private static final int TRACK = 0x60FFFFFF;

    private static final int HEADER_H = 22;
    private static final int ROW_H = 26;
    private static final int PAD = 10;
    private static final int CONTROL_H = 14;
    private static final int BUTTON_H = 18;

    private final Module module;
    private final Screen parent;
    private int px, py, panelH;
    private NumberSetting dragging;
    private TextSetting typing;
    private final boolean compact;
    private final int panelW, controlW;
    private boolean bindListening;

    public ModSettingsScreen(Module module, Screen parent) {
        this(module, parent, false);
    }

    public ModSettingsScreen(Module module, Screen parent, boolean compact) {
        super(Component.literal(module.getName() + " settings"));
        this.module = module;
        this.parent = parent;
        this.compact = compact;
        this.panelW = compact ? 250 : 300;
        this.controlW = compact ? 110 : 130;
    }

    private int rows() {
        return module.getSettings().size() + (compact ? 1 : 0);
    }

    @Override
    protected void init() {
        panelH = HEADER_H + PAD + warnH() + rows() * ROW_H + PAD + BUTTON_H + PAD;
        if (compact && parent != null && minecraft != null) parent.init(minecraft, width, height);
        px = (width - panelW) / 2;
        py = (height - panelH) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
    }

    private int rowY(int i) { return py + HEADER_H + PAD + warnH() + i * ROW_H; }

    private int warnH() { return module.warning() == null ? 0 : 14; }
    private int controlX() { return px + panelW - PAD - controlW; }
    private int closeX() { return px + panelW - 16; }
    private int closeY() { return py + 5; }
    private int resetX() { return px + (panelW - 110) / 2; }
    private int resetY() { return py + panelH - PAD - BUTTON_H; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        Theme theme = Theme.current();
        if (compact && parent != null) {
            parent.render(g, -1, -1, partialTick);
            g.fill(0, 0, width, height, 0x50000000);
        }
        g.fill(px, py, px + panelW, py + panelH, PANEL_BG);
        outline(g, px, py, panelW, panelH, theme.accentArgb(0x88));
        g.drawString(font, module.getName() + " settings", px + 8, py + 7, theme.accentArgb(0xFF), true);
        if (module.warning() != null) {
            g.drawCenteredString(font, module.warning(), px + panelW / 2, py + HEADER_H + PAD + 2, 0xFFFF3333);
        }
        g.fill(px, py + HEADER_H, px + panelW, py + HEADER_H + 1, theme.accentArgb(0x88));

        boolean overClose = inside(mouseX, mouseY, closeX(), closeY(), 11, 11);
        g.fill(closeX(), closeY(), closeX() + 11, closeY() + 11, overClose ? 0xA0FF3333 : 0x60FF3333);
        for (int k = 0; k < 7; k++) {
            g.fill(closeX() + 2 + k, closeY() + 2 + k, closeX() + 3 + k, closeY() + 3 + k, WHITE);
            g.fill(closeX() + 8 - k, closeY() + 2 + k, closeX() + 9 - k, closeY() + 3 + k, WHITE);
        }

        String tooltip = null;
        List<Setting> settings = module.getSettings();
        for (int i = 0; i < settings.size(); i++) {
            Setting s = settings.get(i);
            int y = rowY(i);
            int cx = controlX(), cy = y + (ROW_H - CONTROL_H) / 2 - 2;
            g.drawString(font, s.getName(), px + PAD, y + 7, WHITE, true);
            if (inside(mouseX, mouseY, px + PAD, y, controlW, ROW_H - 4)) tooltip = s.getDescription();

            if (s instanceof NumberSetting n) {
                int filled = (int) Math.round(n.fraction() * controlW);
                g.fill(cx, cy, cx + controlW, cy + CONTROL_H, TRACK);
                g.fill(cx, cy, cx + filled, cy + CONTROL_H, theme.onArgb(n == dragging));
                g.fill(cx + filled - 1, cy - 1, cx + filled + 2, cy + CONTROL_H + 1, WHITE);
                g.drawCenteredString(font, n.display(), cx + controlW / 2, cy + 3, WHITE);
            } else if (s instanceof ModeSetting m) {
                boolean hover = inside(mouseX, mouseY, cx, cy, controlW, CONTROL_H);
                g.fill(cx, cy, cx + controlW, cy + CONTROL_H, theme.offArgb(hover));
                g.drawCenteredString(font, "< " + m.get() + " >", cx + controlW / 2, cy + 3, WHITE);
            } else if (s instanceof BoolSetting b) {
                boolean hover = inside(mouseX, mouseY, cx, cy, controlW, CONTROL_H);
                g.fill(cx, cy, cx + controlW, cy + CONTROL_H, b.get() ? theme.onArgb(hover) : theme.offArgb(hover));
                g.drawCenteredString(font, b.get() ? "ON" : "OFF", cx + controlW / 2, cy + 3, WHITE);
            } else if (s instanceof TextSetting t) {
                boolean active = t == typing;
                g.fill(cx, cy, cx + controlW, cy + CONTROL_H, 0xA0000000);
                outline(g, cx, cy, controlW, CONTROL_H, active ? theme.accentArgb(0xFF) : 0x80FFFFFF);
                String shown = t.get();

                while (font.width(shown) > controlW - 10 && shown.length() > 1) shown = shown.substring(1);
                boolean cursor = active && (System.currentTimeMillis() / 500) % 2 == 0;
                g.drawString(font, shown + (cursor ? "_" : ""), cx + 4, cy + 3, WHITE, false);
            }
        }

        if (compact) {
            int y = rowY(settings.size());
            int cx = controlX(), cy = y + (ROW_H - CONTROL_H) / 2 - 2;
            g.drawString(font, "Keybind", px + PAD, y + 7, WHITE, true);
            boolean hover = inside(mouseX, mouseY, cx, cy, controlW, CONTROL_H);
            g.fill(cx, cy, cx + controlW, cy + CONTROL_H, 0xA0000000);
            outline(g, cx, cy, controlW, CONTROL_H, bindListening || hover ? theme.accentArgb(0xFF) : 0x80FFFFFF);
            String label = bindListening ? "Press a key..." : module.getKeybind() == -1 ? "None" : ClickGuiScreen.keyName(module.getKeybind());
            g.drawCenteredString(font, label, cx + controlW / 2, cy + 3, WHITE);
            if (inside(mouseX, mouseY, px + PAD, y, controlW, ROW_H - 4) || hover) {
                tooltip = bindListening ? "Press a key to toggle " + module.getName() + " with (ESC = none)"
                        : "Click, then press a key to toggle " + module.getName() + " with it";
            }
        }

        boolean overReset = inside(mouseX, mouseY, resetX(), resetY(), 110, BUTTON_H);
        g.fill(resetX(), resetY(), resetX() + 110, resetY() + BUTTON_H, theme.offArgb(overReset));
        g.drawCenteredString(font, "Default config", resetX() + 55, resetY() + 5, WHITE);

        super.render(g, mouseX, mouseY, partialTick);
        if (tooltip != null) g.renderTooltip(font, Component.literal(tooltip), mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        stopTyping();
        if (compact && !inside(mouseX, mouseY, px, py, panelW, panelH)) {
            onClose();
            return true;
        }
        if (compact) {
            int cy = rowY(module.getSettings().size()) + (ROW_H - CONTROL_H) / 2 - 2;
            if (inside(mouseX, mouseY, controlX() - 2, cy - 2, controlW + 4, CONTROL_H + 4)) {
                bindListening = !bindListening;
                click();
                return true;
            }
        }
        bindListening = false;

        if (inside(mouseX, mouseY, closeX(), closeY(), 11, 11)) {
            click();
            onClose();
            return true;
        }
        if (inside(mouseX, mouseY, resetX(), resetY(), 110, BUTTON_H)) {
            module.resetSettings();
            Config.save();
            click();
            return true;
        }
        List<Setting> settings = module.getSettings();
        for (int i = 0; i < settings.size(); i++) {
            Setting s = settings.get(i);
            int cx = controlX(), cy = rowY(i) + (ROW_H - CONTROL_H) / 2 - 2;
            if (!inside(mouseX, mouseY, cx - 2, cy - 2, controlW + 4, CONTROL_H + 4)) continue;
            if (s instanceof NumberSetting n) {
                dragging = n;
                slide(mouseX);
            } else if (s instanceof BoolSetting b) {
                b.toggle();
                Config.save();
                click();
            } else if (s instanceof ModeSetting m) {
                m.cycle();
                Config.save();
                click();
            } else if (s instanceof TextSetting t) {
                typing = t;
                click();
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null) {
            slide(mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private void slide(double mouseX) {
        double f = (mouseX - controlX()) / controlW;
        dragging.setFraction(Math.max(0, Math.min(1, f)));
    }

    private void stopTyping() {
        if (typing != null) {
            typing.set(typing.get().trim());
            typing = null;
            Config.save();
        }
    }

    @Override
    public boolean charTyped(char c, int modifiers) {
        if (typing != null && c >= ' ' && c != 127 && typing.get().length() < 200) {
            typing.set(typing.get() + c);
            return true;
        }
        return super.charTyped(c, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindListening) {
            module.setKeybind(keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode);
            bindListening = false;
            Config.save();
            return true;
        }
        if (typing != null) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                String v = typing.get();
                if (!v.isEmpty()) typing.set(v.substring(0, v.length() - 1));
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER || keyCode == GLFW.GLFW_KEY_ESCAPE) {
                stopTyping();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_V && (modifiers & GLFW.GLFW_MOD_CONTROL) != 0 && minecraft != null) {
                typing.set(typing.get() + minecraft.keyboardHandler.getClipboard().replace("\n", ""));
                return true;
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        stopTyping();
        Config.save();
        if (minecraft != null) minecraft.setScreen(parent);
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private void click() {
        if (minecraft != null) {
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
        }
    }
}
