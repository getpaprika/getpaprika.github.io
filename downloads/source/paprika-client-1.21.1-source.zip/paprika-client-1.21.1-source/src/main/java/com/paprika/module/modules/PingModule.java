package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;

public class PingModule extends Module {
    public PingModule() {
        super("Ping", "Shows your ping in ms", Category.RENDER);
    }

    @Override
    public int onRender(GuiGraphics graphics, int x, int y) {
        if (mc.player == null || mc.getConnection() == null) return 0;
        PlayerInfo me = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        int ping = me == null ? 0 : me.getLatency();
        graphics.drawString(mc.font, "Ping: " + ping + " ms", x, y, 0xFFFFFFFF, true);
        return mc.font.lineHeight + 2;
    }

    @Override
    public int onRenderPreview(GuiGraphics graphics, int x, int y) {
        if (mc.player != null && mc.getConnection() != null) return onRender(graphics, x, y);
        graphics.drawString(mc.font, "Ping: 42 ms", x, y, 0xFFFFFFFF, true);
        return mc.font.lineHeight + 2;
    }
}
