package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.TextSetting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BlockEspModule extends Module {
    private static final int CHUNKS_PER_TICK = 4;
    private static final int MAX_SHOWN = 2000;

    public final TextSetting blocks = text("Block", "Block id to highlight, e.g. diamond_ore (more: separate with commas)", "diamond_ore");
    public final BoolSetting chams = bool("Chams", "See-through rainbow fill inside the box", true);

    private final Map<Long, List<BlockPos>> found = new HashMap<>();
    private final Deque<Long> queue = new ArrayDeque<>();
    private Set<Block> targets = Set.of();
    private String parsedFrom;
    private List<BlockPos> shown = List.of();
    private ClientLevel lastLevel;
    private int timer;

    public BlockEspModule() {
        super("BlockESP", "Highlights the block you choose (pencil -> Block, e.g. diamond_ore) in rainbow through walls", Category.RENDER);
    }

    protected BlockEspModule(String name, String description) {
        super(name, description, Category.RENDER);
    }

    public List<BlockPos> shown() {
        return shown;
    }

    @Override
    protected void onDisable() {
        found.clear();
        queue.clear();
        shown = List.of();
        parsedFrom = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) {
            lastLevel = null;
            return;
        }

        if (mc.level != lastLevel || !blocks.get().equals(parsedFrom)) {
            lastLevel = mc.level;
            parsedFrom = blocks.get();
            targets = parse(parsedFrom);
            found.clear();
            queue.clear();
            shown = List.of();
        }
        if (targets.isEmpty()) return;

        if (queue.isEmpty()) {
            int radius = mc.options.getEffectiveRenderDistance() + 1;
            ChunkPos center = mc.player.chunkPosition();
            Set<Long> loaded = new HashSet<>();
            for (int cx = center.x - radius; cx <= center.x + radius; cx++) {
                for (int cz = center.z - radius; cz <= center.z + radius; cz++) {
                    if (mc.level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false) == null) continue;
                    long key = ChunkPos.asLong(cx, cz);
                    loaded.add(key);
                    queue.add(key);
                }
            }
            found.keySet().retainAll(loaded);
        }
        for (int i = 0; i < CHUNKS_PER_TICK && !queue.isEmpty(); i++) scanChunk(queue.poll());

        if (timer-- <= 0) {
            timer = 10;
            List<BlockPos> all = new ArrayList<>();
            for (List<BlockPos> l : found.values()) {
                for (BlockPos p : l) {
                    if (targets.contains(mc.level.getBlockState(p).getBlock())) all.add(p);
                }
            }
            BlockPos me = mc.player.blockPosition();
            all.sort(Comparator.comparingDouble(p -> p.distSqr(me)));
            shown = all.size() > MAX_SHOWN ? new ArrayList<>(all.subList(0, MAX_SHOWN)) : all;
        }
    }

    private void scanChunk(long key) {
        LevelChunk chunk = mc.level.getChunkSource().getChunk(ChunkPos.getX(key), ChunkPos.getZ(key), ChunkStatus.FULL, false);
        if (chunk == null) {
            found.remove(key);
            return;
        }
        List<BlockPos> list = new ArrayList<>();
        LevelChunkSection[] sections = chunk.getSections();
        int baseX = chunk.getPos().getMinBlockX(), baseZ = chunk.getPos().getMinBlockZ();
        for (int s = 0; s < sections.length; s++) {
            LevelChunkSection section = sections[s];
            if (section == null || section.hasOnlyAir()) continue;
            if (!section.maybeHas(st -> targets.contains(st.getBlock()))) continue;
            int baseY = SectionPos.sectionToBlockCoord(chunk.getSectionYFromSectionIndex(s));
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (targets.contains(state.getBlock())) list.add(new BlockPos(baseX + x, baseY + y, baseZ + z));
                    }
                }
            }
        }
        if (list.isEmpty()) found.remove(key);
        else found.put(key, list);
    }

    private static Set<Block> parse(String text) {
        Set<String> names = new HashSet<>();
        for (String part : text.split("[,\\s]+")) {
            String n = part.trim().toLowerCase(java.util.Locale.ROOT);
            if (n.startsWith("minecraft:")) n = n.substring("minecraft:".length());
            if (!n.isEmpty()) names.add(n);
        }
        Set<Block> out = new HashSet<>();
        if (names.isEmpty()) return out;
        for (Block b : BuiltInRegistries.BLOCK) {
            if (names.contains(BuiltInRegistries.BLOCK.getKey(b).getPath())) out.add(b);
        }
        return out;
    }
}
