package com.paprika.command;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public final class Chat {
    private Chat() {}

    public static void send(String prefix, String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.player.displayClientMessage(Component.literal("[" + prefix + "] ").withStyle(ChatFormatting.RED)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE)), false);
    }

    public static void invalid(String prefix, String hint) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.player.displayClientMessage(Component.literal("[" + prefix + "] ").withStyle(ChatFormatting.RED)
                .append(Component.literal("Invalid argument").withStyle(ChatFormatting.WHITE))
                .append(Component.literal(" (" + hint + ")").withStyle(ChatFormatting.GRAY)), false);
    }
}
