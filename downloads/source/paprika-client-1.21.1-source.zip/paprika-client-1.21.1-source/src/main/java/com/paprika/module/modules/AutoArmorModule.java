package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class AutoArmorModule extends Module {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private int cooldown;

    public AutoArmorModule() {
        super("AutoArmor", "Automatically wears your best armor", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) return;
        if (cooldown-- > 0) return;
        cooldown = 5;
        if (mc.screen != null && !(mc.screen instanceof InventoryScreen)) return;
        if (mc.player.containerMenu != mc.player.inventoryMenu) return;

        for (int s = 0; s < SLOTS.length; s++) {
            EquipmentSlot slot = SLOTS[s];
            ItemStack worn = mc.player.getItemBySlot(slot);
            if (slot == EquipmentSlot.CHEST && worn.is(Items.ELYTRA)) continue;

            int bestInv = -1;
            double best = score(worn, slot);
            for (int i = 0; i < 36; i++) {
                double sc = score(mc.player.getInventory().getItem(i), slot);
                if (sc > best) {
                    best = sc;
                    bestInv = i;
                }
            }
            if (bestInv < 0) continue;

            int armorMenuSlot = 5 + s;
            int itemMenuSlot = bestInv < 9 ? bestInv + 36 : bestInv;
            int id = mc.player.inventoryMenu.containerId;
            if (worn.isEmpty()) {
                mc.gameMode.handleInventoryMouseClick(id, itemMenuSlot, 0, ClickType.QUICK_MOVE, mc.player);
            } else {
                mc.gameMode.handleInventoryMouseClick(id, itemMenuSlot, 0, ClickType.PICKUP, mc.player);
                mc.gameMode.handleInventoryMouseClick(id, armorMenuSlot, 0, ClickType.PICKUP, mc.player);
                mc.gameMode.handleInventoryMouseClick(id, itemMenuSlot, 0, ClickType.PICKUP, mc.player);
            }
            return;
        }
    }

    private static double score(ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty() || !(stack.getItem() instanceof ArmorItem armor)) return -1;
        if (armor.getEquipmentSlot() != slot) return -1;
        return armor.getDefense() + armor.getToughness() * 0.5 + (stack.isEnchanted() ? 0.25 : 0);
    }
}
