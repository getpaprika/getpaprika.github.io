package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.FullbrightModule;
import com.paprika.module.modules.XrayModule;
import net.minecraft.client.renderer.LightTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(LightTexture.class)
public abstract class LightTextureMixin {
    @ModifyArg(
            method = "updateLightTexture",
            at = @At(value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/platform/NativeImage;setPixelRGBA(III)V"),
            index = 2
    )
    private int paprika$fullbright(int color) {
        if (ModuleManager.isOn(FullbrightModule.class) || ModuleManager.isOn(XrayModule.class)) {
            return 0xFFFFFFFF;
        }
        return color;
    }
}
