package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public class FreecamModule extends Module {
    private static final double SPEED = 0.8;

    public final com.paprika.module.setting.BoolSetting showHand = bool("Show hand",
            "Show the item you're holding in front of the free camera (moves with your real player)", true);

    private boolean ready;
    private double x, y, z;
    private double prevX, prevY, prevZ;
    private float yaw, pitch;

    public FreecamModule() {
        super("Freecam", "Fly your camera around while your body stays still", Category.UTILITY);
    }

    public static FreecamModule active() {
        FreecamModule f = ModuleManager.get(FreecamModule.class);
        return (f != null && f.isEnabled() && f.ready) ? f : null;
    }

    @Override
    public boolean shouldSave() {
        return false;
    }

    @Override
    protected void onEnable() {
        ready = false;
        XrayModule.updateCulling();
        if (mc.player != null) start();
    }

    @Override
    protected void onDisable() {
        ready = false;
        XrayModule.updateCulling();
    }

    private void start() {
        Vec3 eye = mc.player.getEyePosition();
        x = prevX = eye.x;
        y = prevY = eye.y;
        z = prevZ = eye.z;
        yaw = mc.player.getYRot();
        pitch = mc.player.getXRot();
        ready = true;
    }

    @Override
    public void onTick() {
        if (mc.player == null) {
            ready = false;
            return;
        }
        if (!ready) start();

        prevX = x;
        prevY = y;
        prevZ = z;

        if (mc.screen != null) return;

        double forward = 0, strafe = 0, vertical = 0;
        if (mc.options.keyUp.isDown()) forward++;
        if (mc.options.keyDown.isDown()) forward--;
        if (mc.options.keyLeft.isDown()) strafe++;
        if (mc.options.keyRight.isDown()) strafe--;
        if (mc.options.keyJump.isDown()) vertical++;
        if (mc.options.keyShift.isDown()) vertical--;

        double len = Math.sqrt(forward * forward + strafe * strafe);
        if (len > 1) {
            forward /= len;
            strafe /= len;
        }
        double speed = mc.options.keySprint.isDown() ? SPEED * 2 : SPEED;

        double rad = Math.toRadians(yaw);
        double sin = Math.sin(rad), cos = Math.cos(rad);
        x += (strafe * cos - forward * sin) * speed;
        z += (forward * cos + strafe * sin) * speed;
        y += vertical * speed;
    }

    public void turn(double yRotDelta, double xRotDelta) {
        yaw += (float) yRotDelta * 0.15F;
        pitch = Mth.clamp(pitch + (float) xRotDelta * 0.15F, -90.0F, 90.0F);
    }

    public Vec3 position(float partialTick) {
        return new Vec3(Mth.lerp(partialTick, prevX, x), Mth.lerp(partialTick, prevY, y), Mth.lerp(partialTick, prevZ, z));
    }

    public float yaw() { return yaw; }
    public float pitch() { return pitch; }
}
