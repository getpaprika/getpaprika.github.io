package com.paprika.mixin;

import com.paprika.module.modules.ElytraFlyModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityTravelMixin {
    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void paprika$elytraFly(Vec3 input, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        LivingEntity self = (LivingEntity) (Object) this;
        if (self != mc.player || !ElytraFlyModule.isGliding()) return;

        boolean boost = mc.options.keySprint.isDown() && mc.screen == null;
        Vec3 vel = ElytraFlyModule.glide(self.getDeltaMovement(), self.getLookAngle(), self.getXRot(), boost);
        self.setDeltaMovement(vel);
        self.move(MoverType.SELF, vel);
        if (vel.y > -0.5) self.fallDistance = 1.0F;
        ci.cancel();
    }
}
