package com.paprika.module.modules;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;

public final class AttackClick {
    private static Entity pending;
    private static long pendingSince;

    private AttackClick() {}

    public static void request(Entity target) {
        long now = System.currentTimeMillis();
        if (pending != null && now - pendingSince < 150) return;
        Minecraft mc = Minecraft.getInstance();
        pending = target;
        pendingSince = now;
        KeyMapping.click(net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.getBoundKeyOf(mc.options.keyAttack));
    }

    public static void beforeKeybinds() {
        Entity target = pending;
        pending = null;
        Minecraft mc = Minecraft.getInstance();
        if (target == null || mc.player == null || !target.isAlive()) return;
        mc.hitResult = new EntityHitResult(target);
    }
}
