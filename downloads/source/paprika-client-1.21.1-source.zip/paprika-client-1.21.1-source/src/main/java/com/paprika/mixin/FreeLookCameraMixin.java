package com.paprika.mixin;

import com.paprika.module.modules.FreeLookModule;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Camera.class)
public abstract class FreeLookCameraMixin {
    @Shadow protected abstract void setRotation(float yRot, float xRot);

    @Redirect(method = "setup", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setRotation(FF)V", ordinal = 0))
    private void paprika$freeLook(Camera camera, float yRot, float xRot) {
        FreeLookModule look = FreeLookModule.active();
        if (look != null) {
            yRot = look.yaw();
            xRot = look.pitch();
        }
        this.setRotation(yRot, xRot);
    }
}
