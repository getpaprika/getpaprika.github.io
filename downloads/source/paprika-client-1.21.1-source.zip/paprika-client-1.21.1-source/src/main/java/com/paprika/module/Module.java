package com.paprika.module;

import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.NumberSetting;
import com.paprika.module.setting.ModeSetting;
import com.paprika.module.setting.Setting;
import com.paprika.module.setting.TextSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final Minecraft mc = Minecraft.getInstance();

    private final String name;
    private final String description;
    private final Category category;
    private volatile boolean enabled;

    private int keybind = -1;
    private boolean keyWasDown;

    private final List<Setting> settings = new ArrayList<>();

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public List<Setting> getSettings() { return settings; }
    public boolean hasSettings() { return !settings.isEmpty(); }

    public void resetSettings() {
        for (Setting s : settings) s.reset();
    }

    protected NumberSetting number(String name, String description, double def, double min, double max, double step, String unit) {
        NumberSetting s = new NumberSetting(name, description, def, min, max, step, unit);
        settings.add(s);
        return s;
    }

    protected ModeSetting mode(String name, String description, String def, String... options) {
        ModeSetting s = new ModeSetting(name, description, def, options);
        settings.add(s);
        return s;
    }

    protected TextSetting text(String name, String description, String def) {
        TextSetting s = new TextSetting(name, description, def);
        settings.add(s);
        return s;
    }

    protected BoolSetting bool(String name, String description, boolean def) {
        BoolSetting s = new BoolSetting(name, description, def);
        settings.add(s);
        return s;
    }

    public int getKeybind() { return keybind; }
    public void setKeybind(int key) { keybind = key; }

    public boolean keyPressedNow(boolean down) {
        boolean pressed = down && !keyWasDown;
        keyWasDown = down;
        return pressed;
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public boolean shouldSave() { return true; }

    public String warning() { return null; }

    protected void onEnable() {}
    protected void onDisable() {}

    public void onTick() {}

    public int onRender(GuiGraphics graphics, int x, int y) { return 0; }

    public int onRenderPreview(GuiGraphics graphics, int x, int y) { return onRender(graphics, x, y); }
}
