package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.phys.Vec3;

public class AirJumpModule extends Module {
    private boolean jumpWasDown;

    public AirJumpModule() {
        super("AirJump", "Jump again while you're in the air", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        boolean down = mc.options.keyJump.isDown();
        boolean pressed = down && !jumpWasDown;
        jumpWasDown = down;
        if (!pressed || mc.screen != null) return;
        if (mc.player.onGround() || mc.player.isInWater() || mc.player.isInLava()
                || mc.player.getAbilities().flying || mc.player.isPassenger()) return;
        Vec3 v = mc.player.getDeltaMovement();
        mc.player.setDeltaMovement(v.x, 0.42, v.z);
        mc.player.fallDistance = 0;
    }
}
