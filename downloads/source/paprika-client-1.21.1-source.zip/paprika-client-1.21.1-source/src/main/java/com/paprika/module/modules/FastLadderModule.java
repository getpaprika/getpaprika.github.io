package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.phys.Vec3;

public class FastLadderModule extends Module {
    public final NumberSetting multiplier = number("Climb speed", "How many times faster than normal you climb", 2, 1.5, 5, 0.5, "x");

    public FastLadderModule() {
        super("FastLadder", "Climb ladders and vines twice as fast", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || !mc.player.onClimbable() || mc.player.isShiftKeyDown()) return;
        boolean up = mc.player.horizontalCollision || (mc.options.keyJump.isDown() && mc.screen == null);
        if (!up) return;
        Vec3 v = mc.player.getDeltaMovement();
        mc.player.setDeltaMovement(v.x, 0.2 * multiplier.get(), v.z);
    }
}
