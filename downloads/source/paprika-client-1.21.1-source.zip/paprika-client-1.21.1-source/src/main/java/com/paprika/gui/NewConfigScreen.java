package com.paprika.gui;

import com.paprika.ConfigProfiles;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class NewConfigScreen extends Screen {
    private static final int W = 220, H = 96;
    private final Screen parent;
    private EditBox name;
    private String error = "";

    public NewConfigScreen(Screen parent) {
        super(Component.literal("New preset"));
        this.parent = parent;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    protected void init() {
        int x = (width - W) / 2, y = (height - H) / 2;
        String old = name == null ? "" : name.getValue();
        name = new EditBox(font, x + 10, y + 34, W - 20, 18, Component.literal("Preset name"));
        name.setMaxLength(24);
        name.setValue(old);
        name.setHint(Component.literal("Preset name").withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
        name.setResponder(t -> error = "");
        addRenderableWidget(name);
        setInitialFocus(name);
        addRenderableWidget(Button.builder(Component.literal("OK"), b -> create()).bounds(x + 10, y + H - 28, (W - 24) / 2, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose()).bounds(x + W / 2 + 2, y + H - 28, (W - 24) / 2, 18).build());
    }

    private void create() {
        String n = name.getValue().trim();
        if (!ConfigProfiles.validName(n)) {
            error = "1-24 letters, numbers, spaces, _ or -";
            return;
        }
        if (ConfigProfiles.exists(n)) {
            error = "You already have a preset called that";
            return;
        }
        if (!ConfigProfiles.create(n)) {
            error = "Couldn't save it, try another name";
            return;
        }
        onClose();
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
    }
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        Theme theme = Theme.current();
        int x = (width - W) / 2, y = (height - H) / 2;
        Ui.round(g, x, y, W, H, 6, 0xE8141414);
        Ui.roundTop(g, x, y, W, 16, 6, theme.accentArgb(0xFF));
        Ui.centered(g, font, "New preset", x + W / 2, y + 4, 0xFFFFFFFF);
        Ui.draw(g, font, "Name of the preset:", x + 10, y + 22, 0xFFBBBBBB);
        if (!error.isEmpty()) Ui.centered(g, font, error, width / 2, y + H + 6, 0xFFFF5555);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            create();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        if (minecraft != null) minecraft.setScreen(parent);
    }
}
