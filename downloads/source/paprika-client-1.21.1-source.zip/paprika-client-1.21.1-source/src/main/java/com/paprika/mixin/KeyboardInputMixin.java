package com.paprika.mixin;

import com.paprika.module.modules.FreecamModule;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void paprika$freecamFreeze(boolean isSneaking, float sneakSpeed, CallbackInfo ci) {
        if (FreecamModule.active() == null) return;
        Input input = (Input) (Object) this;
        input.up = false;
        input.down = false;
        input.left = false;
        input.right = false;
        input.jumping = false;
        input.shiftKeyDown = false;
        input.forwardImpulse = 0;
        input.leftImpulse = 0;
    }
}
