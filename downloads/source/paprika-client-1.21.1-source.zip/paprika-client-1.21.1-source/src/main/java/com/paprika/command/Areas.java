package com.paprika.command;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

public final class Areas {
    public record Area(String dim, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        public static Area of(String dim, BlockPos a, BlockPos b) {
            return new Area(dim, Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ()),
                    Math.max(a.getX(), b.getX()), Math.max(a.getY(), b.getY()), Math.max(a.getZ(), b.getZ()));
        }

        public boolean contains(BlockPos p) {
            return p.getX() >= minX && p.getX() <= maxX && p.getY() >= minY && p.getY() <= maxY
                    && p.getZ() >= minZ && p.getZ() <= maxZ;
        }

        public long volume() {
            return (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
        }

        public AABB box() {
            return new AABB(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1);
        }
    }

    private static final List<Area> AREAS = new ArrayList<>();

    private Areas() {}

    public static String currentDim() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? "" : mc.level.dimension().location().toString();
    }

    public static void add(Area area) { AREAS.add(area); }

    public static void clear() { AREAS.clear(); }

    public static List<Area> current() {
        String dim = currentDim();
        List<Area> list = new ArrayList<>();
        for (Area a : AREAS) if (a.dim().equals(dim)) list.add(a);
        return list;
    }

    public static boolean inAnyArea(BlockPos p, List<Area> areas) {
        for (Area a : areas) if (a.contains(p)) return true;
        return false;
    }

    public static JsonArray save() {
        JsonArray arr = new JsonArray();
        for (Area a : AREAS) {
            JsonObject o = new JsonObject();
            o.addProperty("dim", a.dim());
            o.addProperty("minX", a.minX()); o.addProperty("minY", a.minY()); o.addProperty("minZ", a.minZ());
            o.addProperty("maxX", a.maxX()); o.addProperty("maxY", a.maxY()); o.addProperty("maxZ", a.maxZ());
            arr.add(o);
        }
        return arr;
    }

    public static void load(JsonArray arr) {
        AREAS.clear();
        for (JsonElement e : arr) {
            JsonObject o = e.getAsJsonObject();
            AREAS.add(new Area(o.get("dim").getAsString(),
                    o.get("minX").getAsInt(), o.get("minY").getAsInt(), o.get("minZ").getAsInt(),
                    o.get("maxX").getAsInt(), o.get("maxY").getAsInt(), o.get("maxZ").getAsInt()));
        }
    }
}
