package com.paprika.module;

import com.paprika.module.modules.*;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        MODULES.add(new FpsModule());
        MODULES.add(new PingModule());
        MODULES.add(new CoordsHudModule());
        MODULES.add(new PotionHudModule());
        MODULES.add(new AiidModule());
        MODULES.add(new FullbrightModule());
        MODULES.add(new XrayModule());
        MODULES.add(new NoFallModule());
        MODULES.add(new VelocityModule());
        MODULES.add(new FlyModule());
        MODULES.add(new JesusModule());
        MODULES.add(new SpiderModule());
        MODULES.add(new EntityCullingModule());
        MODULES.add(new ShulkerBoxTooltipModule());
        MODULES.add(new SaturationModule());
        MODULES.add(new EspPModule());
        MODULES.add(new EspEModule());
        MODULES.add(new EspMModule());
        MODULES.add(new TracersPModule());
        MODULES.add(new TracersEModule());
        MODULES.add(new TracersMModule());
        MODULES.add(new AutoCrystalModule());
        MODULES.add(new AutoCritsModule());
        MODULES.add(new NExpModule());
        MODULES.add(new PlayerWModule());
        MODULES.add(new SpecWModule());
        MODULES.add(new BaseWModule());
        MODULES.add(new BaritoneModule());
        MODULES.add(new AutoTotemModule());
        MODULES.add(new TNTCountdownModule());
        MODULES.add(new AutoMLGModule());
        MODULES.add(new ToggleSprintModule());
        MODULES.add(new BoatFlyModule());
        MODULES.add(new AntiCobwebModule());
        MODULES.add(new AntiEdgeFallModule());
        MODULES.add(new PKillAuraModule());
        MODULES.add(new EKillAuraModule());
        MODULES.add(new MKillAuraModule());
        MODULES.add(new FreecamModule());
        MODULES.add(new ScaffoldModule());
        MODULES.add(new AutoAnchorModule());
        MODULES.add(new StrongholdWModule());
        MODULES.add(new FortressWModule());
        MODULES.add(new BastionWModule());
        MODULES.add(new AncientCityWModule());
        MODULES.add(new VillageWModule());
        MODULES.add(new HealthHudModule());
        MODULES.add(new FastLadderModule());
        MODULES.add(new NoHurtCamModule());
        MODULES.add(new NoFireModule());
        MODULES.add(new NoPumpkinModule());
        MODULES.add(new AutoReplenishModule());
        MODULES.add(new ArrayListModule());
        MODULES.add(new NukerModule());
        MODULES.add(new TunnelModule());
        MODULES.add(new DangerousNetherrackModule());
        MODULES.add(new BlockEspModule());
        MODULES.add(new BlockTracersModule());
        MODULES.add(new StorageEspModule());
        MODULES.add(new StreamerModeModule());
        MODULES.add(new LavaEspModule());
        MODULES.add(new ItemEspModule());
        MODULES.add(new ItemTracersModule());
        MODULES.add(new NewChunksModule());
        MODULES.add(new FreeLookModule());
        MODULES.add(new WebAuraModule());
        MODULES.add(new FriendWModule());
        MODULES.add(new FastMineModule());
        MODULES.add(new AirJumpModule());
        MODULES.add(new ClickTpModule());
        MODULES.add(new NoclipModule());
        MODULES.add(new FakeLagModule());
        MODULES.add(new BlinkModule());
        MODULES.add(new SpeedometerModule());
        MODULES.add(new TriggerBotPModule());
        MODULES.add(new TriggerBotEModule());
        MODULES.add(new TriggerBotMModule());
        MODULES.add(new AimAssistPModule());
        MODULES.add(new AimAssistEModule());
        MODULES.add(new AimAssistMModule());
        MODULES.add(new AutoGapModule());
        MODULES.add(new HitboxesModule());
        MODULES.add(new BlockOutlineModule());
        MODULES.add(new ReachModule());
        MODULES.add(new AntiSpamModule());
        MODULES.add(new AutoLogoutModule());
        MODULES.add(new AutoArmorModule());
        MODULES.add(new AutoEatModule());
        MODULES.add(new BowAimbotModule());
        MODULES.add(new CrystalAuraModule());
        MODULES.add(new SpeedModule());
        MODULES.add(new NoSlowModule());
        MODULES.add(new ElytraFlyModule());
        MODULES.add(new TrajectoriesModule());
        MODULES.add(new NoWeatherModule());
        MODULES.add(new ZoomModule());
        MODULES.add(new BreadcrumbsModule());
        MODULES.add(new PChamsModule());
        MODULES.add(new EChamsModule());
        MODULES.add(new MChamsModule());
        MODULES.add(new FastBlocksModule());
        MODULES.add(new AutoFishModule());
        MODULES.add(new AntiAfkModule());
        MODULES.add(new ChestStealerModule());
        MODULES.add(new DeathWModule());
        MODULES.add(new ArmorHudModule());
        CACHE.clear();
    }

    private static final java.util.Map<Class<?>, java.util.Optional<Module>> CACHE = new java.util.concurrent.ConcurrentHashMap<>();

    public static <T extends Module> T get(Class<T> type) {
        java.util.Optional<Module> cached = CACHE.get(type);
        if (cached == null) {
            Module found = null;
            for (Module m : MODULES) if (type.isInstance(m)) { found = m; break; }
            if (MODULES.isEmpty()) return null;
            cached = java.util.Optional.ofNullable(found);
            CACHE.put(type, cached);
        }
        return cached.isPresent() ? type.cast(cached.get()) : null;
    }

    public static boolean isOn(Class<? extends Module> type) {
        Module m = get(type);
        return m != null && m.isEnabled();
    }

    public static List<Module> getModules() { return MODULES; }

    public static List<Module> getByCategory(Category category) {
        List<Module> list = new ArrayList<>();
        for (Module m : MODULES) if (m.getCategory() == category) list.add(m);
        return list;
    }
}
