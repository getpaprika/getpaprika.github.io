package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.setting.BoolSetting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.HashSet;
import java.util.Set;

public class NewChunksModule extends Module {
    public final BoolSetting showOld = bool("Show old", "Also show chunks that already existed before (green)", false);

    private static final Set<Long> NEW = new HashSet<>();
    private static final Set<Long> OLD = new HashSet<>();
    private ClientLevel lastLevel;

    public NewChunksModule() {
        super("NewChunks", "New chunks in red (never generated before), old chunks in green (setting)", Category.RENDER);
    }

    public static Set<Long> newChunks() { return NEW; }
    public static Set<Long> oldChunks() { return OLD; }

    @Override
    protected void onDisable() {
        NEW.clear();
        OLD.clear();
    }

    @Override
    public void onTick() {
        if (mc.level != lastLevel) {
            NEW.clear();
            OLD.clear();
            lastLevel = mc.level;
        }
    }

    private static boolean flowing(BlockState state) {
        return !state.getFluidState().isEmpty() && !state.getFluidState().isSource();
    }

    public static void onBlockUpdate(BlockPos pos, BlockState state) {
        if (!ModuleManager.isOn(NewChunksModule.class) || !flowing(state)) return;
        long key = ChunkPos.asLong(pos.getX() >> 4, pos.getZ() >> 4);
        if (!OLD.contains(key)) NEW.add(key);
    }

    public static void onChunkLoad(int x, int z) {
        if (!ModuleManager.isOn(NewChunksModule.class) || mc.level == null) return;
        long key = ChunkPos.asLong(x, z);
        if (NEW.contains(key)) return;
        LevelChunk chunk = mc.level.getChunkSource().getChunk(x, z, false);
        if (chunk == null) return;
        for (LevelChunkSection section : chunk.getSections()) {
            if (section == null || section.hasOnlyAir()) continue;
            if (section.maybeHas(NewChunksModule::flowing)) {
                OLD.add(key);
                return;
            }
        }
    }
}
