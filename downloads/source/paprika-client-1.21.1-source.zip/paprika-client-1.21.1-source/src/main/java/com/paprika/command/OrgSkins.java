package com.paprika.command;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.client.Minecraft;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class OrgSkins {
    public static boolean enabled = false;

    public record Skin(PlayerSkin skin) {}

    private static final Map<String, Optional<Skin>> CACHE = new ConcurrentHashMap<>();
    private static final Set<String> LOADING = ConcurrentHashMap.newKeySet();
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Paprika-OrgSkin");
        t.setDaemon(true);
        return t;
    });
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

    private OrgSkins() {}

    public static Skin get(String name) {
        if (!enabled || name == null || !name.matches("[A-Za-z0-9_]{1,16}")) return null;
        String key = name.toLowerCase(Locale.ROOT);
        Optional<Skin> known = CACHE.get(key);
        if (known != null) return known.orElse(null);
        if (LOADING.add(key)) EXEC.execute(() -> load(name, key));
        return null;
    }

    public static void retryMisses() {
        CACHE.values().removeIf(Optional::isEmpty);
    }

    private static void load(String name, String key) {
        try {
            UUID uuid = lookupUuid(name);
            if (uuid == null) {
                CACHE.put(key, Optional.empty());
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            var result = mc.getMinecraftSessionService().fetchProfile(uuid, false);
            if (result == null) {
                CACHE.put(key, Optional.empty());
                return;
            }
            GameProfile profile = result.profile();
            CACHE.put(key, Optional.empty());
            mc.execute(() -> mc.getSkinManager().getOrLoad(profile)
                    .thenAccept(skin -> CACHE.put(key, Optional.of(new Skin(skin)))));
        } catch (Exception e) {
            CACHE.put(key, Optional.empty());
        } finally {
            LOADING.remove(key);
        }
    }

    private static UUID lookupUuid(String name) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(URI.create("https://api.mojang.com/users/profiles/minecraft/" + name))
                .timeout(Duration.ofSeconds(8)).GET().build();
        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200 || response.body().isBlank()) return null;
        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        String id = json.get("id").getAsString();
        return UUID.fromString(id.replaceFirst("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5"));
    }
}
