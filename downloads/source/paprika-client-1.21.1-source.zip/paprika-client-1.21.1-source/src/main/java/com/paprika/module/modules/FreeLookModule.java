package com.paprika.module.modules;

import com.mojang.blaze3d.platform.InputConstants;
import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import net.minecraft.client.CameraType;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

public class FreeLookModule extends Module {
    private boolean looking;
    private CameraType before;
    private float yaw, pitch;

    public FreeLookModule() {
        super("FreeLook", "Hold Alt to look around your character in third person without turning it", Category.RENDER);
    }

    public static FreeLookModule active() {
        FreeLookModule f = ModuleManager.get(FreeLookModule.class);
        return f != null && f.isEnabled() && f.looking ? f : null;
    }

    @Override
    public void onTick() {
        if (mc.player == null) {
            stop();
            return;
        }
        long window = mc.getWindow().getWindow();
        boolean alt = mc.screen == null && (InputConstants.isKeyDown(window, GLFW.GLFW_KEY_LEFT_ALT)
                || InputConstants.isKeyDown(window, GLFW.GLFW_KEY_RIGHT_ALT));
        if (alt && !looking) {
            looking = true;
            before = mc.options.getCameraType();
            yaw = mc.player.getYRot();
            pitch = mc.player.getXRot();
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
        } else if (!alt && looking) {
            stop();
        }
    }

    @Override
    protected void onDisable() {
        stop();
    }

    private void stop() {
        if (!looking) return;
        looking = false;
        if (before != null) mc.options.setCameraType(before);
    }

    public void turn(double yRotDelta, double xRotDelta) {
        yaw += (float) yRotDelta * 0.15F;
        pitch = Mth.clamp(pitch + (float) xRotDelta * 0.15F, -90.0F, 90.0F);
    }

    public float yaw() { return yaw; }
    public float pitch() { return pitch; }
}
