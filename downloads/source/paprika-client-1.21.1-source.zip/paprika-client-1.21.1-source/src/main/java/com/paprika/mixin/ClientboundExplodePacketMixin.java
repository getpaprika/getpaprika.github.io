package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.VelocityModule;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientboundExplodePacket.class)
public abstract class ClientboundExplodePacketMixin {
    @Inject(method = {"getKnockbackX", "getKnockbackZ"}, at = @At("RETURN"), cancellable = true)
    private void paprika$explosionSideways(CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.isOn(VelocityModule.class)) {
            float keep = (float) (ModuleManager.get(VelocityModule.class).horizontal.get() / 100.0);
            cir.setReturnValue(cir.getReturnValue() * keep);
        }
    }

    @Inject(method = "getKnockbackY", at = @At("RETURN"), cancellable = true)
    private void paprika$explosionUp(CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.isOn(VelocityModule.class)) {
            float keep = (float) (ModuleManager.get(VelocityModule.class).vertical.get() / 100.0);
            cir.setReturnValue(cir.getReturnValue() * keep);
        }
    }
}
