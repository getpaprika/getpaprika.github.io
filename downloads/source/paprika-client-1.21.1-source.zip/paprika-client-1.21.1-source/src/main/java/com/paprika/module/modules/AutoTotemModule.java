package com.paprika.module.modules;

import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

public class AutoTotemModule extends Module {
    private static final int OFFHAND_BUTTON = 40;
    public final NumberSetting delay = number("Delay", "How long to wait after a totem pops", 0.2, 0, 1, 0.05, " s");
    public final BoolSetting onlyInFights = bool("Only in fights", "Only works when another player is close", true);
    public final NumberSetting fightRange = number("Fight range", "How close a player has to be to count as a fight", 40, 5, 100, 1, " blocks");
    private int cooldown;
    private int missingTicks;

    public AutoTotemModule() {
        super("AutoTotem", "In a fight (player within 40 blocks), puts a totem in your off hand 0.2s after one pops", Category.COMBAT);
    }

    private boolean enemyNearby() {
        if (mc.level == null) return false;
        for (net.minecraft.world.entity.player.Player p : mc.level.players()) {
            if (com.paprika.module.modules.BlinkModule.isClone(p)) continue;
            if (p == mc.player || p.isSpectator() || !p.isAlive() || com.paprika.command.Friends.is(p)) continue;
            if (p.distanceTo(mc.player) <= fightRange.get()) return true;
        }
        return false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) return;
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            missingTicks = 0;
            return;
        }
        if (onlyInFights.get() && !enemyNearby()) {
            missingTicks = 0;
            return;
        }
        if (missingTicks++ < (int) Math.round(delay.get() * 20)) return;

        if (mc.screen != null && !(mc.screen instanceof InventoryScreen)) return;
        if (mc.player.containerMenu != mc.player.inventoryMenu) return;

        int invSlot = -1;
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                invSlot = i;
                break;
            }
        }
        if (invSlot < 0) return;

        int menuSlot = invSlot < 9 ? invSlot + 36 : invSlot;
        mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, menuSlot,
                OFFHAND_BUTTON, ClickType.SWAP, mc.player);
        cooldown = 2;
    }
}
