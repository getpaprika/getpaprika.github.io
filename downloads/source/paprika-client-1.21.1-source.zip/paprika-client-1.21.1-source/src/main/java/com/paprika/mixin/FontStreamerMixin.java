package com.paprika.mixin;

import com.paprika.module.modules.StreamerModeModule;
import net.minecraft.client.gui.Font;
import net.minecraft.util.FormattedCharSequence;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Font.class)
public abstract class FontStreamerMixin {
    @ModifyVariable(method = "drawInBatch(Ljava/lang/String;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/client/gui/Font$DisplayMode;IIZ)I",
            at = @At("HEAD"), argsOnly = true)
    private String paprika$coverString(String text) {
        return StreamerModeModule.cover(text);
    }

    @ModifyVariable(method = "drawInBatch(Lnet/minecraft/util/FormattedCharSequence;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/client/gui/Font$DisplayMode;II)I",
            at = @At("HEAD"), argsOnly = true)
    private FormattedCharSequence paprika$coverSequence(FormattedCharSequence text) {
        return StreamerModeModule.cover(text);
    }

    @ModifyVariable(method = "drawInBatch8xOutline", at = @At("HEAD"), argsOnly = true)
    private FormattedCharSequence paprika$coverOutline(FormattedCharSequence text) {
        return StreamerModeModule.cover(text);
    }

    @ModifyVariable(method = "width(Ljava/lang/String;)I", at = @At("HEAD"), argsOnly = true)
    private String paprika$coverWidth(String text) {
        return StreamerModeModule.cover(text);
    }

    @ModifyVariable(method = "width(Lnet/minecraft/util/FormattedCharSequence;)I", at = @At("HEAD"), argsOnly = true)
    private FormattedCharSequence paprika$coverWidthSequence(FormattedCharSequence text) {
        return StreamerModeModule.cover(text);
    }
}
