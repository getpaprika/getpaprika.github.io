package com.paprika.mixin;

import com.paprika.module.modules.FreecamModule;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "renderItemInHand", at = @At("HEAD"), cancellable = true)
    private void paprika$noHandInFreecam(CallbackInfo ci) {
        FreecamModule freecam = FreecamModule.active();
        if (freecam != null && !freecam.showHand.get()) ci.cancel();
    }
}
