package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class ClickTpModule extends Module {
    public final NumberSetting range = number("Range", "How far away you can click", 50, 5, 100, 1, " blocks");
    private static final double HOP = 8.0;

    public ClickTpModule() {
        super("ClickTP", "Left click a block to teleport there", Category.MOVEMENT);
    }

    @Override
    public String warning() {
        return "MAY NOT WORK!";
    }

    public static ClickTpModule active() {
        ClickTpModule m = ModuleManager.get(ClickTpModule.class);
        return m != null && m.isEnabled() ? m : null;
    }

    public void teleport() {
        if (mc.player == null || mc.level == null || mc.getConnection() == null) return;
        HitResult hit = mc.player.pick(range.get(), 1.0F, false);
        if (!(hit instanceof BlockHitResult block) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos stand = block.getDirection() == Direction.UP ? block.getBlockPos().above() : block.getBlockPos().relative(block.getDirection());
        for (int k = 0; k < 4 && !fits(stand); k++) stand = stand.above();
        if (!fits(stand)) return;

        Vec3 from = mc.player.position(), to = Vec3.atBottomCenterOf(stand);
        int hops = Math.max(1, (int) Math.ceil(from.distanceTo(to) / HOP));
        for (int i = 1; i <= hops; i++) {
            Vec3 p = from.lerp(to, i / (double) hops);
            mc.getConnection().send(new ServerboundMovePlayerPacket.Pos(p.x, p.y, p.z, i == hops));
        }
        mc.player.setPos(to.x, to.y, to.z);
        mc.player.setDeltaMovement(Vec3.ZERO);
        mc.player.fallDistance = 0;
    }

    private boolean fits(BlockPos feet) {
        return mc.level.getBlockState(feet).getCollisionShape(mc.level, feet).isEmpty()
                && mc.level.getBlockState(feet.above()).getCollisionShape(mc.level, feet.above()).isEmpty();
    }
}
