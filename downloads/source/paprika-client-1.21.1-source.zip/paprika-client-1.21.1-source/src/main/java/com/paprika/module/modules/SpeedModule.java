package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.phys.Vec3;

public class SpeedModule extends Module {
    public final NumberSetting speed = number("Speed", "How fast you walk", 10, 1, 100, 0.5, " blocks/s");

    public SpeedModule() {
        super("Speed", "Walk faster", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.player.input == null) return;
        if (!mc.player.onGround() || mc.player.isInWater() || mc.player.isInLava() || mc.player.isPassenger()
                || mc.player.getAbilities().flying || mc.player.isFallFlying() || mc.player.isShiftKeyDown()) return;

        float forward = mc.player.input.forwardImpulse;
        float strafe = mc.player.input.leftImpulse;
        if (Math.abs(forward) < 0.01F && Math.abs(strafe) < 0.01F) return;

        double len = Math.sqrt(forward * forward + strafe * strafe);
        double f = forward / len, s = strafe / len;
        double yaw = Math.toRadians(mc.player.getYRot());
        double x = s * Math.cos(yaw) - f * Math.sin(yaw);
        double z = f * Math.cos(yaw) + s * Math.sin(yaw);
        double perTick = speed.get() / 20.0;

        Vec3 v = mc.player.getDeltaMovement();
        mc.player.setDeltaMovement(x * perTick, v.y, z * perTick);
    }
}
