package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.BoatFlyModule;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Boat.class)
public abstract class BoatMixin {
    @Inject(method = "controlBoat", at = @At("TAIL"))
    private void paprika$boatFly(CallbackInfo ci) {
        if (!ModuleManager.isOn(BoatFlyModule.class)) return;
        Minecraft mc = Minecraft.getInstance();
        Boat boat = (Boat) (Object) this;
        if (mc.player == null || boat.getControllingPassenger() != mc.player) return;

        boat.setYRot(mc.player.getYRot());

        if (mc.options.keyUp.isDown() && mc.screen == null) {
            Vec3 look = mc.player.getLookAngle();
            boat.setDeltaMovement(look.scale(BoatFlyModule.speedPerTick()));
        } else {
            boat.setDeltaMovement(Vec3.ZERO);
        }
    }
}
