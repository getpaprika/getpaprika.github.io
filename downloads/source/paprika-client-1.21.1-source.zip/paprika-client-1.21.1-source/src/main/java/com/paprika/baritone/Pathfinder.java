package com.paprika.baritone;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public final class Pathfinder {
    public static final double INF = 1e9;

    private static final double WALK = 1.0;
    private static final double STEP_UP = 1.6;
    private static final double FALL_PER_BLOCK = 0.3;
    private static final double BREAK_EXTRA = 1.5;
    private static final double TICKS_PER_BLOCK = 4.6;
    private static final int MAX_FALL = 3;
    private static final int MAX_FALL_INTO_WATER = 20;
    private static final double SWIM = 1.5;
    private static final double SWIM_UP = 2.0;
    private static final double BRIDGE = 4.0;
    private static final double PILLAR = 4.0;
    private static final double AVOID = 10.0;

    private static final Direction[] HORIZONTAL = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    public record Result(List<BlockPos> path, boolean complete) {}

    private record Move(BlockPos pos, double cost) {}

    private record Entry(Node node, double f) {}

    private static final class Node {
        final BlockPos pos;
        double g = INF;
        Node parent;
        boolean closed;

        Node(BlockPos pos) { this.pos = pos; }
    }

    private final Level level;
    private final Player player;
    private final boolean canPlace;
    private final Map<BlockState, Double> breakCache = new HashMap<>();
    private java.util.Set<Long> avoid = java.util.Set.of();

    private Pathfinder(Level level, Player player) {
        this.level = level;
        this.player = player;
        this.canPlace = throwawaySlot(player) >= 0;
    }

    public static Result find(Level level, Player player, BlockPos start, Goal goal, int maxNodes) {
        return new Pathfinder(level, player).search(start, goal, maxNodes);
    }

    public static Result find(Level level, Player player, BlockPos start, Goal goal, int maxNodes, java.util.Set<Long> avoid) {
        Pathfinder p = new Pathfinder(level, player);
        p.avoid = avoid;
        return p.search(start, goal, maxNodes);
    }

    private Result search(BlockPos start, Goal goal, int maxNodes) {
        Map<Long, Node> nodes = new HashMap<>();
        PriorityQueue<Entry> open = new PriorityQueue<>(Comparator.comparingDouble(Entry::f));

        Node startNode = new Node(start);
        startNode.g = 0;
        nodes.put(start.asLong(), startNode);
        open.add(new Entry(startNode, goal.heuristic(start)));

        Node best = startNode;
        double bestH = goal.heuristic(start);
        int expanded = 0;

        while (!open.isEmpty() && expanded < maxNodes) {
            Node cur = open.poll().node();
            if (cur.closed) continue;
            cur.closed = true;
            expanded++;

            if (goal.isGoal(cur.pos)) return new Result(build(cur), true);

            double h = goal.heuristic(cur.pos);
            if (h < bestH) {
                bestH = h;
                best = cur;
            }

            for (Move m : neighbors(cur.pos)) {
                double g = cur.g + m.cost() + (avoid.contains(m.pos().asLong()) ? AVOID : 0);
                Node n = nodes.computeIfAbsent(m.pos().asLong(), k -> new Node(m.pos()));
                if (n.closed || g >= n.g) continue;
                n.g = g;
                n.parent = cur;
                open.add(new Entry(n, g + goal.heuristic(m.pos())));
            }
        }

        if (best == startNode) return new Result(List.of(start), false);
        return new Result(build(best), false);
    }

    private static List<BlockPos> build(Node end) {
        List<BlockPos> list = new ArrayList<>();
        for (Node n = end; n != null; n = n.parent) list.add(n.pos);
        Collections.reverse(list);
        return list;
    }

    private List<Move> neighbors(BlockPos pos) {
        List<Move> out = new ArrayList<>(12);
        boolean inWater = water(pos);
        boolean onSolid = standable(pos.below());

        for (Direction d : HORIZONTAL) {
            BlockPos t = pos.relative(d);

            double feet = clearCost(t);
            double head = clearCost(t.above());
            if (feet < INF && head < INF) {
                if (supported(t) && !water(t.above())) {
                    out.add(new Move(t, ((inWater || water(t)) ? SWIM : WALK) + feet + head));
                } else {
                    if (feet == 0 && head == 0) {
                        for (int k = 1; k <= MAX_FALL_INTO_WATER; k++) {
                            BlockPos f = t.below(k);
                            if (!loaded(f) || !passable(f)) break;
                            if (water(f)) {
                                if (!water(f.above())) out.add(new Move(f, WALK + k * FALL_PER_BLOCK));
                                break;
                            }
                            if (standable(f.below())) {
                                if (k <= MAX_FALL) out.add(new Move(f, WALK + k * FALL_PER_BLOCK));
                                break;
                            }
                        }
                    }

                    if (canPlace && onSolid && !inWater && replaceable(t.below())) {
                        out.add(new Move(t, BRIDGE + feet + head));
                    }
                }
            }

            if (standable(t)) {
                double above = clearCost(pos.above(2));
                double upFeet = clearCost(t.above());
                double upHead = clearCost(t.above(2));
                if (above < INF && upFeet < INF && upHead < INF && !water(t.above(2))) {
                    out.add(new Move(t.above(), STEP_UP + above + upFeet + upHead));
                }
            }
        }

        BlockPos down = pos.below();
        if (!inWater) {
            double digDown = breakCost(down);
            if (digDown > 0 && digDown < INF && standable(down.below())) {
                out.add(new Move(down, WALK + digDown));
            }
        }

        if (inWater && water(pos.above()) && passable(pos.above()) && clearCost(pos.above(2)) == 0) {
            out.add(new Move(pos.above(), SWIM_UP));
        }

        if (canPlace && onSolid && !inWater) {
            double ceiling = clearCost(pos.above(2));
            if (ceiling < INF && passable(pos.above())) out.add(new Move(pos.above(), PILLAR + ceiling));
        }

        return out;
    }

    private boolean loaded(BlockPos pos) {
        return !level.isOutsideBuildHeight(pos) && level.hasChunkAt(pos);
    }

    private double clearCost(BlockPos pos) {
        if (!loaded(pos)) return INF;
        if (passable(pos)) return 0;
        return breakCost(pos);
    }

    public static boolean isPassable(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return state.getCollisionShape(level, pos).isEmpty()
                && (state.getFluidState().isEmpty() || state.getFluidState().is(FluidTags.WATER))
                && !isDangerous(state);
    }

    public static boolean isWater(Level level, BlockPos pos) {
        return level.getFluidState(pos).is(FluidTags.WATER);
    }

    public static boolean isStandable(Level level, BlockPos pos) {
        if (level.isOutsideBuildHeight(pos) || !level.hasChunkAt(pos)) return false;
        BlockState state = level.getBlockState(pos);
        if (isDangerous(state) || !state.getFluidState().isEmpty()) return false;
        VoxelShape shape = state.getCollisionShape(level, pos);
        return !shape.isEmpty() && shape.max(Direction.Axis.Y) >= 0.8;
    }

    public static boolean isReplaceable(Level level, BlockPos pos) {
        if (level.isOutsideBuildHeight(pos) || !level.hasChunkAt(pos)) return false;
        BlockState state = level.getBlockState(pos);
        return state.canBeReplaced() && !isDangerous(state);
    }

    private boolean water(BlockPos pos) {
        return loaded(pos) && isWater(level, pos);
    }

    private boolean supported(BlockPos pos) {
        return standable(pos.below()) || water(pos);
    }

    private boolean replaceable(BlockPos pos) {
        return isReplaceable(level, pos);
    }

    private boolean passable(BlockPos pos) {
        return isPassable(level, pos);
    }

    private boolean standable(BlockPos pos) {
        return isStandable(level, pos);
    }

    private double breakCost(BlockPos pos) {
        if (!loaded(pos)) return INF;
        BlockState state = level.getBlockState(pos);
        if (state.isAir()) return 0;
        if (isDangerous(state) || !state.getFluidState().isEmpty()) return INF;
        if (state.getDestroySpeed(level, pos) < 0) return INF;
        if (com.paprika.module.modules.DangerousNetherrackModule.isDangerous(level, pos)) return INF;

        for (Direction d : Direction.values()) {
            if (!loaded(pos.relative(d))) return INF;
        }
        if (touchesFluid(level, pos)) return INF;

        Double cached = breakCache.get(state);
        if (cached == null) {
            cached = breakTicks(level, pos, state, player) / TICKS_PER_BLOCK + BREAK_EXTRA;
            breakCache.put(state, cached);
        }
        return cached;
    }

    public static boolean touchesFluid(Level level, BlockPos pos) {
        if (nextToFluid(level, pos)) return true;

        BlockPos above = pos.above();
        for (int k = 0; k < 64 && level.getBlockState(above).getBlock() instanceof net.minecraft.world.level.block.FallingBlock; k++) {
            if (nextToFluid(level, above)) return true;
            above = above.above();
        }
        return false;
    }

    private static boolean nextToFluid(Level level, BlockPos pos) {
        for (Direction d : Direction.values()) {
            var fluid = level.getFluidState(pos.relative(d));
            if (fluid.isEmpty()) continue;
            if (fluid.is(FluidTags.LAVA)) return true;
            if (d != Direction.DOWN && fluid.is(FluidTags.WATER)) return true;
        }
        return false;
    }

    public static boolean isDangerous(BlockState state) {
        return state.is(Blocks.LAVA) || state.is(Blocks.FIRE) || state.is(Blocks.SOUL_FIRE)
                || state.is(Blocks.SWEET_BERRY_BUSH) || state.is(Blocks.CACTUS) || state.is(Blocks.MAGMA_BLOCK)
                || state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE) || state.is(Blocks.WITHER_ROSE)
                || state.is(Blocks.POWDER_SNOW) || state.getFluidState().is(FluidTags.LAVA);
    }

    public static double breakTicks(Level level, BlockPos pos, BlockState state, Player player) {
        float hardness = state.getDestroySpeed(level, pos);
        if (hardness < 0) return INF;
        if (hardness == 0) return 1;
        double best = 0;
        for (int i = 0; i < 9; i++) best = Math.max(best, damagePerTick(player.getInventory().getItem(i), state, hardness));
        if (best <= 0) return INF;
        return Math.ceil(1.0 / best);
    }

    public static int bestToolSlot(Level level, BlockPos pos, BlockState state, Player player) {
        float hardness = state.getDestroySpeed(level, pos);
        int bestSlot = player.getInventory().selected;
        double best = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            double dmg = damagePerTick(stack, state, Math.max(hardness, 0.01F));
            boolean drops = !state.requiresCorrectToolForDrops() || stack.isCorrectToolForDrops(state);
            if (drops) dmg *= 1.5;
            if (dmg > best) {
                best = dmg;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    public static boolean isThrowaway(ItemStack stack) {
        if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem bi)) return false;
        net.minecraft.world.level.block.Block b = bi.getBlock();
        return b == Blocks.COBBLESTONE || b == Blocks.COBBLED_DEEPSLATE || b == Blocks.DIRT
                || b == Blocks.NETHERRACK || b == Blocks.STONE || b == Blocks.ANDESITE
                || b == Blocks.DIORITE || b == Blocks.GRANITE || b == Blocks.TUFF
                || b == Blocks.DEEPSLATE || b == Blocks.BLACKSTONE || b == Blocks.END_STONE
                || stack.is(ItemTags.PLANKS);
    }

    public static int throwawaySlot(Player player) {
        for (int i = 0; i < 9; i++) {
            if (isThrowaway(player.getInventory().getItem(i))) return i;
        }
        return -1;
    }

    private static double damagePerTick(ItemStack stack, BlockState state, float hardness) {
        float speed = stack.getDestroySpeed(state);
        boolean canHarvest = !state.requiresCorrectToolForDrops() || stack.isCorrectToolForDrops(state);
        return speed / hardness / (canHarvest ? 30.0 : 100.0);
    }
}
