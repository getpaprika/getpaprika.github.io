package com.paprika.render;

import com.paprika.command.Markers;
import com.paprika.module.ModuleManager;
import com.paprika.module.modules.BaseWModule;
import com.paprika.module.modules.StructureWModule;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public final class MarkerRenderer {
    private static final Matrix4f VIEW = new Matrix4f();
    private static final Matrix4f PROJECTION = new Matrix4f();
    private static Vec3 camPos = Vec3.ZERO;
    private static boolean captured;

    private MarkerRenderer() {}

    public static void capture(WorldRenderContext ctx) {
        VIEW.set(RenderUtil.viewMatrix(ctx.camera()));
        PROJECTION.set(ctx.projectionMatrix());
        camPos = ctx.camera().getPosition();
        captured = true;
    }

    private record ScreenPos(float x, float y, boolean visible) {}

    private static ScreenPos project(Vec3 world, int width, int height) {
        Vector4f v = new Vector4f((float) (world.x - camPos.x), (float) (world.y - camPos.y), (float) (world.z - camPos.z), 1.0F);
        VIEW.transform(v);
        PROJECTION.transform(v);
        boolean behind = v.w() <= 0.0001F;
        float w = Math.max(Math.abs(v.w()), 0.0001F);
        float nx = v.x() / w, ny = v.y() / w;
        if (behind) {
            nx = -nx;
            ny = -ny;
        }
        float sx = (nx * 0.5F + 0.5F) * width;
        float sy = (1.0F - (ny * 0.5F + 0.5F)) * height;
        boolean visible = !behind && sx >= 0 && sx <= width && sy >= 0 && sy <= height;
        return new ScreenPos(sx, sy, visible);
    }

    public static void renderHud(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (!captured || mc.level == null || mc.player == null) return;
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();
        Font font = mc.font;

        BaseWModule baseW = ModuleManager.get(BaseWModule.class);
        if (baseW != null && baseW.isEnabled()) {
            for (BaseWModule.Group group : baseW.espGroups()) label(g, font, group, baseW.colorOf(group), width, height);

            for (BaseWModule.Group group : baseW.baseGroups()) {
                if (inView(group.box(), width, height)) continue;
                AABB box = group.box();
                ScreenPos p = project(box.getCenter(), width, height);
                int[] e = toEdge(p, width, height, 10);
                String warn = "!!!";
                int ww = font.width(warn);
                g.fill(e[0] - ww / 2 - 2, e[1] - 6, e[0] + ww / 2 + 3, e[1] + 5, 0x80000000);
                g.drawString(font, warn, e[0] - ww / 2, e[1] - 4, 0xFFFF2020, true);
            }
        }
        for (com.paprika.module.Module m : ModuleManager.getModules()) {
            if (m instanceof StructureWModule s && s.isEnabled()) {
                for (BaseWModule.Group group : s.espGroups()) label(g, font, group, s.labelColor(), width, height);
            }
        }

        for (Markers.Marker m : Markers.current()) {
            if (Markers.isHidden(m)) continue;
            Vec3 pos = new Vec3(m.x(), m.y() + 1.0, m.z());
            ScreenPos p = project(pos, width, height);
            int margin = 12;
            int x = (int) p.x(), y = (int) p.y();
            if (!p.visible()) {
                int[] e = toEdge(p, width, height, margin);
                x = e[0];
                y = e[1];
            }
            int color = 0xFF000000 | m.color();
            diamond(g, x, y, 6, 0xFF000000);
            diamond(g, x, y, 5, color);

            int dist = (int) Math.round(mc.player.position().distanceTo(pos));
            String text = m.name() + " (" + dist + "m)";
            int tx = x - font.width(text) / 2;
            int ty = y - 8 - font.lineHeight;
            tx = Math.max(2, Math.min(width - font.width(text) - 2, tx));
            g.drawString(font, text, tx, ty, color, true);
        }
    }

    private static int[] toEdge(ScreenPos p, int width, int height, int margin) {
        float cx = width / 2.0F, cy = height / 2.0F;
        float dx = p.x() - cx, dy = p.y() - cy;
        if (Math.abs(dx) < 0.001F && Math.abs(dy) < 0.001F) dy = 1.0F;
        float sx = Math.abs(dx) < 0.001F ? Float.MAX_VALUE : (cx - margin) / Math.abs(dx);
        float sy = Math.abs(dy) < 0.001F ? Float.MAX_VALUE : (cy - margin - 10) / Math.abs(dy);
        float scale = Math.min(sx, sy);
        return new int[] {(int) (cx + dx * scale), (int) (cy + dy * scale)};
    }

    private static boolean inView(AABB b, int width, int height) {
        if (project(b.getCenter(), width, height).visible()) return true;
        for (int i = 0; i < 8; i++) {
            Vec3 corner = new Vec3((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            if (project(corner, width, height).visible()) return true;
        }
        return false;
    }

    private static void label(GuiGraphics g, Font font, BaseWModule.Group group, int color, int width, int height) {
        AABB box = group.box();
        ScreenPos p = project(new Vec3((box.minX + box.maxX) / 2, box.maxY + 0.5, (box.minZ + box.maxZ) / 2), width, height);
        if (!p.visible()) return;
        int w = font.width(group.label());
        int tx = Math.max(2, Math.min(width - w - 2, (int) p.x() - w / 2));
        int ty = (int) p.y() - font.lineHeight;
        g.fill(tx - 2, ty - 2, tx + w + 2, ty + font.lineHeight, 0x80000000);
        g.drawString(font, group.label(), tx, ty, color, true);
    }

    private static void diamond(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = r - Math.abs(dy);
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }
}
