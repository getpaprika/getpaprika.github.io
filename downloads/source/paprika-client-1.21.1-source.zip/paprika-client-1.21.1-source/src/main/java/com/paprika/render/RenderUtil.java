package com.paprika.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Camera;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Quaternionf;

public final class RenderUtil {
    private RenderUtil() {}

    public static float partialTick(WorldRenderContext ctx) {
        return ctx.tickCounter().getGameTimeDeltaPartialTick(false);
    }

    public static Matrix4f viewMatrix(Camera camera) {
        return new Matrix4f().rotation(camera.rotation().conjugate(new Quaternionf()));
    }

    public static PoseStack worldPose(Camera camera) {
        PoseStack pose = new PoseStack();
        pose.mulPose(camera.rotation().conjugate(new Quaternionf()));
        return pose;
    }

    public static void beginWorld() {
        Matrix4fStack stack = RenderSystem.getModelViewStack();
        stack.pushMatrix();
        stack.identity();
        RenderSystem.applyModelViewMatrix();
    }

    public static void endWorld() {
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();
    }
}
