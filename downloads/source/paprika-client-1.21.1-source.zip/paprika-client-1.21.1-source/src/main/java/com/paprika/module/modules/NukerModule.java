package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.baritone.Pathfinder;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class NukerModule extends Module {
    private static final double REACH = 4.5;
    private int previousSlot = -1;

    private final int side, minY, maxY;

    private NumberSetting radius;

    public NukerModule() {
        this("Nuker", "Digs out everything in a 5x5x5 area around you with the right tools", 2, -1, 3);
        radius = number("Radius", "Blocks to each side (2 = 5x5x5)", 2, 1, 4, 1, " blocks");
    }

    protected NukerModule(String name, String description, int side, int minY, int maxY) {
        super(name, description, Category.PLAYER);
        this.side = side;
        this.minY = minY;
        this.maxY = maxY;
    }

    @Override
    protected void onEnable() {
        if (mc.player != null) previousSlot = mc.player.getInventory().selected;
    }

    @Override
    protected void onDisable() {
        if (mc.player != null && previousSlot >= 0) mc.player.getInventory().selected = previousSlot;
        previousSlot = -1;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (mc.player.isSpectator()) return;

        BlockPos target = pickTarget();
        if (target == null) return;

        BlockState state = mc.level.getBlockState(target);
        mc.player.getInventory().selected = Pathfinder.bestToolSlot(mc.level, target, state, mc.player);
        Vec3 fromBlock = mc.player.getEyePosition().subtract(Vec3.atCenterOf(target));
        Direction face = Direction.getNearest(fromBlock.x, fromBlock.y, fromBlock.z);
        mc.gameMode.continueDestroyBlock(target, face);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private BlockPos pickTarget() {
        BlockPos feet = mc.player.blockPosition();
        Vec3 eye = mc.player.getEyePosition();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        int s = radius != null ? radius.getInt() : side;
        int lo = radius != null ? -1 : minY, hi = radius != null ? 2 * s - 1 : maxY;
        for (BlockPos p : BlockPos.betweenClosed(feet.offset(-s, lo, -s), feet.offset(s, hi, s))) {
            BlockState state = mc.level.getBlockState(p);
            if (state.isAir() || state.getBlock() instanceof LiquidBlock) continue;
            if (state.getDestroySpeed(mc.level, p) < 0) continue;
            double dist = eye.distanceTo(Vec3.atCenterOf(p));
            if (dist > REACH) continue;
            double score = dist + (p.getY() < feet.getY() ? 100 : 0);
            if (score < bestScore) {
                bestScore = score;
                best = p.immutable();
            }
        }
        return best;
    }
}
