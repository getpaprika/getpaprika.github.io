package com.paprika.mixin;

import com.paprika.module.modules.NoclipModule;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ScreenEffectRenderer.class)
public abstract class NoclipOverlayMixin {
    @Inject(method = "getViewBlockingState", at = @At("HEAD"), cancellable = true)
    private static void paprika$noWallOverlay(Player player, CallbackInfoReturnable<BlockState> cir) {
        if (NoclipModule.on()) cir.setReturnValue(null);
    }
}
