package com.paprika.module.modules;

import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Random;

public class AutoCrystalModule extends Module {
    private static final double REACH = 5.0;

    public final NumberSetting perSecond = number("Speed", "Places + breaks per second", 5, 1, 20, 1, "/s");
    public final BoolSetting randomize = bool("Random timing", "Makes the rhythm uneven so it looks more natural", true);
    private static final Random RANDOM = new Random();

    private BlockPos target;
    private int cooldown;

    public AutoCrystalModule() {
        super("AutoCrystal", "Hold right click with crystals to place + break them in a loop", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        target = null;
        cooldown = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (!mc.options.keyUse.isDown()) {
            target = null;
            return;
        }

        InteractionHand hand;
        if (mc.player.getMainHandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.MAIN_HAND;
        else if (mc.player.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
        else return;

        HitResult hit = mc.hitResult;
        if (hit instanceof BlockHitResult bhr && hit.getType() == HitResult.Type.BLOCK) {
            BlockState state = mc.level.getBlockState(bhr.getBlockPos());
            if (state.is(Blocks.OBSIDIAN) || state.is(Blocks.BEDROCK)) target = bhr.getBlockPos();
        } else if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystal crystal) {
            target = crystal.blockPosition().below();
        }
        if (target == null) return;

        if (cooldown > 0) {
            cooldown--;
            return;
        }
        cooldown = nextCycle();

        if (mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(target)) > REACH + 1) {
            target = null;
            return;
        }

        List<EndCrystal> crystals = mc.level.getEntitiesOfClass(EndCrystal.class,
                new AABB(target.above()).expandTowards(0, 1, 0));
        for (EndCrystal crystal : crystals) {
            if (crystal.isAlive() && mc.player.distanceTo(crystal) <= REACH + 1) {
                mc.gameMode.attack(mc.player, crystal);
                mc.player.swing(InteractionHand.MAIN_HAND);
            }
        }

        BlockState base = mc.level.getBlockState(target);
        if (!(base.is(Blocks.OBSIDIAN) || base.is(Blocks.BEDROCK))) return;
        if (!mc.level.getBlockState(target.above()).isAir()) return;

        Vec3 hitVec = Vec3.atCenterOf(target).add(0, 0.5, 0);
        BlockHitResult place = new BlockHitResult(hitVec, Direction.UP, target, false);
        mc.gameMode.useItemOn(mc.player, hand, place);
        mc.player.swing(hand);
    }

    private int nextCycle() {
        int ticks = (int) Math.round(20.0 / perSecond.get());
        if (randomize.get()) ticks += RANDOM.nextInt(3) - 1;
        return Math.max(1, ticks) - 1;
    }
}
