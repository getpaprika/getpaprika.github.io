package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public class StreamerModeModule extends Module {
    private static final long CHANGE_MS = 500;
    private static final String LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    private static String fake = "";
    private static long fakeSlot = -1;

    public StreamerModeModule() {
        super("StreamerMode", "Covers your username anywhere it's shown with 8 random letters that change every 0.5 seconds", Category.UTILITY);
    }

    private static String hiddenName() {
        if (!ModuleManager.isOn(StreamerModeModule.class)) return null;
        String name = net.minecraft.client.Minecraft.getInstance().getUser().getName();
        return name == null || name.isEmpty() ? null : name;
    }

    public static String fake() {
        long slot = System.currentTimeMillis() / CHANGE_MS;
        if (slot != fakeSlot) {
            StringBuilder sb = new StringBuilder(8);
            ThreadLocalRandom r = ThreadLocalRandom.current();
            for (int i = 0; i < 8; i++) sb.append(LETTERS.charAt(r.nextInt(LETTERS.length())));
            fake = sb.toString();
            fakeSlot = slot;
        }
        return fake;
    }

    public static String cover(String text) {
        String name = hiddenName();
        if (name == null || text == null || text.length() < name.length()) return text;
        String lower = text.toLowerCase(Locale.ROOT), target = name.toLowerCase(Locale.ROOT);
        int at = lower.indexOf(target);
        if (at < 0) return text;
        String f = fake();
        StringBuilder sb = new StringBuilder(text.length());
        int from = 0;
        while (at >= 0) {
            sb.append(text, from, at).append(f);
            from = at + name.length();
            at = lower.indexOf(target, from);
        }
        return sb.append(text, from, text.length()).toString();
    }

    public static FormattedCharSequence cover(FormattedCharSequence text) {
        String name = hiddenName();
        if (name == null || text == null) return text;
        List<Integer> cps = new ArrayList<>();
        List<Style> styles = new ArrayList<>();
        text.accept((index, style, cp) -> {
            cps.add(cp);
            styles.add(style);
            return true;
        });
        StringBuilder plain = new StringBuilder();
        for (int cp : cps) plain.append(cp > 0xFFFF ? '?' : Character.toLowerCase((char) cp));
        String target = name.toLowerCase(Locale.ROOT);
        int at = plain.indexOf(target);
        if (at < 0) return text;
        String f = fake();
        List<Integer> outCp = new ArrayList<>();
        List<Style> outStyle = new ArrayList<>();
        int i = 0;
        while (i < cps.size()) {
            if (i == at) {
                Style s = styles.get(i);
                for (int k = 0; k < f.length(); k++) { outCp.add((int) f.charAt(k)); outStyle.add(s); }
                i += name.length();
                at = plain.indexOf(target, i);
            } else {
                outCp.add(cps.get(i));
                outStyle.add(styles.get(i));
                i++;
            }
        }
        return sink -> {
            for (int k = 0; k < outCp.size(); k++) if (!sink.accept(k, outStyle.get(k), outCp.get(k))) return false;
            return true;
        };
    }
}
