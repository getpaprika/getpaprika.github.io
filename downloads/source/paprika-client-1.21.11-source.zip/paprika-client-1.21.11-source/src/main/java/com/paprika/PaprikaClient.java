package com.paprika;

import com.mojang.blaze3d.platform.InputConstants;
import com.paprika.gui.ClickGuiScreen;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.render.EspRenderer;
import com.paprika.render.HealthHudRenderer;
import com.paprika.render.MarkerRenderer;
import com.paprika.render.TntTimerRenderer;
import com.paprika.render.ShulkerTooltipComponent;
import com.paprika.render.ShulkerTooltipData;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

public class PaprikaClient implements ClientModInitializer {
    private static final KeyMapping.Category PAPRIKA_KEYS =
            KeyMapping.Category.register(net.minecraft.resources.Identifier.fromNamespaceAndPath("paprika", "main"));

    public static final String NAME = "Paprika Client";

    public static final int RED = 0xFFFF2B2B;

    public static boolean watermark = true;

    public static KeyMapping menuKey;
    public static KeyMapping menuKey2;

    public static KeyMapping zoomKey;

    public static KeyMapping markerKey;
    private static final ItemStack RED_DYE = new ItemStack(Items.RED_DYE);

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Config.load();
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Config.save());

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.paprika.menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_DELETE,
                PAPRIKA_KEYS
        ));

        menuKey2 = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.paprika.menu2",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                PAPRIKA_KEYS
        ));

        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.paprika.zoom",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_Z,
                PAPRIKA_KEYS
        ));

        markerKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.paprika.markers",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                PAPRIKA_KEYS
        ));

        net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (screen instanceof net.minecraft.client.gui.screens.worldselection.SelectWorldScreen
                    || screen instanceof net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen) {
                net.fabricmc.fabric.api.client.screen.v1.Screens.getButtons(screen).add(
                        net.minecraft.client.gui.components.Button.builder(net.minecraft.network.chat.Component.literal("Cracked"),
                                b -> client.setScreen(new com.paprika.gui.CrackedScreen(screen))).bounds(width - 84, 6, 78, 20).build());
            }
        });

        net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (!(screen instanceof net.minecraft.client.gui.screens.PauseScreen)) return;
            java.util.List<net.minecraft.client.gui.components.AbstractWidget> buttons = net.fabricmc.fabric.api.client.screen.v1.Screens.getButtons(screen);
            net.minecraft.client.gui.components.AbstractWidget last = null;
            for (net.minecraft.client.gui.components.AbstractWidget b : buttons) if (last == null || b.getY() > last.getY()) last = b;
            if (last == null) return;
            buttons.add(net.minecraft.client.gui.components.Button.builder(net.minecraft.network.chat.Component.literal("HUD Editor"),
                    b -> client.setScreen(new com.paprika.gui.HudEditorScreen(() -> screen)))
                    .bounds(last.getX(), last.getY() + 24, last.getWidth(), 20).build());
        });

        net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register(
                (client, screen, width, height) -> com.paprika.gui.ChestStealer.addButtons(screen, width, height));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean open = false;
            while (menuKey.consumeClick()) open = true;
            while (menuKey2.consumeClick()) open = true;
            if (open && mc.screen == null) {
                mc.setScreen(com.paprika.gui.GuiStyle.open());
            }
            boolean markers = false;
            while (markerKey.consumeClick()) markers = true;
            if (markers && mc.screen == null && mc.player != null) {
                mc.setScreen(new com.paprika.gui.MarkerScreen());
            }

            long window = mc.getWindow().handle();
            boolean changed = false;
            for (Module m : ModuleManager.getModules()) {
                if (m.getKeybind() == -1) continue;
                boolean down = com.paprika.gui.KeyCapture.isDown(window, m.getKeybind());
                if (m.keyPressedNow(down) && mc.screen == null) {
                    m.toggle();
                    changed = true;
                    mc.gui.setOverlayMessage(net.minecraft.network.chat.Component.literal(m.getName() + " "
                            + (m.isEnabled() ? "ON" : "OFF")), false);
                }
            }
            if (changed) Config.save();

            for (Module m : ModuleManager.getModules()) {
                if (m.isEnabled()) m.onTick();
            }
            com.paprika.module.modules.KillAuraFacing.tick();
        });

        WorldRenderEvents.END_MAIN.register(EspRenderer::render);

        WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register((context, outline) -> !ModuleManager.isOn(com.paprika.module.modules.BlockOutlineModule.class));

        WorldRenderEvents.AFTER_ENTITIES.register(TntTimerRenderer::render);

        WorldRenderEvents.AFTER_ENTITIES.register(HealthHudRenderer::render);

        TooltipComponentCallback.EVENT.register(data ->
                data instanceof ShulkerTooltipData shulker ? new ShulkerTooltipComponent(shulker) : null);

        HudRenderCallback.EVENT.register((graphics, tickCounter) -> {
            com.paprika.module.modules.AimSmoother.frame();
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui || mc.getDebugOverlay().showDebugScreen()) return;

            if (com.paprika.module.modules.FakeLagModule.active()) {
                com.paprika.network.PacketQueue.flushLag(ModuleManager.get(com.paprika.module.modules.FakeLagModule.class).delay.getInt(), false);
            }
            if (com.paprika.gui.ListGuiScreen.hidesHud(mc.screen)) return;

            MarkerRenderer.renderHud(graphics);

            com.paprika.gui.HudRenderer.render(graphics);
        });
    }
}
