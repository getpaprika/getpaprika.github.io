package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.FullbrightModule;
import com.paprika.module.modules.XrayModule;
import net.minecraft.client.renderer.LightTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LightTexture.class)
public abstract class LightTextureMixin {
    @org.spongepowered.asm.mixin.injection.Redirect(
            method = "updateLightTexture",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/player/LocalPlayer;hasEffect(Lnet/minecraft/core/Holder;)Z",
                    ordinal = 0)
    )
    private boolean paprika$fullbrightOn(net.minecraft.client.player.LocalPlayer player, net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> effect) {
        if (ModuleManager.isOn(FullbrightModule.class) || ModuleManager.isOn(XrayModule.class)) return true;
        return player.hasEffect(effect);
    }

    @org.spongepowered.asm.mixin.injection.Redirect(
            method = "updateLightTexture",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/GameRenderer;getNightVisionScale(Lnet/minecraft/world/entity/LivingEntity;F)F")
    )
    private float paprika$fullbrightScale(net.minecraft.world.entity.LivingEntity entity, float partialTick) {
        if (ModuleManager.isOn(FullbrightModule.class) || ModuleManager.isOn(XrayModule.class)) return 1.0F;
        return net.minecraft.client.renderer.GameRenderer.getNightVisionScale(entity, partialTick);
    }
}
