package com.paprika.module.modules;

import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.ChatFormatting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.monster.zombie.ZombieVillager;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class BaseWModule extends Module {
    private static final int SCAN_EVERY_TICKS = 20;
    private static final int CHECK_EVERY_TICKS = 200;
    private static final int MESSAGES_PER_TICK = 3;
    private static final int LOOK_RADIUS = 5;
    private static final int MAX_FINDS_CHECKED = 40;
    private static final int HOME_CHUNKS_PER_TICK = 4;
    private static final double VILLAGER_RANGE = 48;

    public final NumberSetting groupDistance = number("Group distance", "Finds closer together than this are one base", 64, 8, 128, 4, " blocks");
    public final BoolSetting showNatural = bool("Show natural", "Also show natural structures (dungeons, mineshafts...), labelled Natural", false);
    public final BoolSetting includeSpawners = bool("Include spawners", "ON: every spawner is a guaranteed base, and spawners no longer cancel the chests next to them", false);

    public record Group(AABB box, String label) {}

    private record Find(BlockPos pos, String type, String key) {}

    private record Check(boolean base, boolean guaranteed, String structure, List<String> clues, int timeChecked) {}

    private final Map<BlockPos, String> foundBlocks = new HashMap<>();
    private final Set<String> reported = new HashSet<>();
    private final Map<Long, Check> checks = new HashMap<>();
    private final Set<Long> announcedBases = new HashSet<>();
    private List<Group> groups = new ArrayList<>();
    private List<Group> naturalGroups = new ArrayList<>();
    private List<Group> guaranteedGroups = new ArrayList<>();
    private final List<Vec3> announcedGuaranteed = new ArrayList<>();

    private final Map<Long, Map<BlockPos, String>> homeBlocks = new HashMap<>();
    private final Deque<Long> homeQueue = new ArrayDeque<>();
    private final Deque<Component> messages = new ArrayDeque<>();
    private ClientLevel lastLevel;
    private boolean lastIncludeSpawners;
    private int timer;
    private int ticks;

    public BaseWModule() {
        super("BaseW", "Finds possible bases (chests, spawners, shulkers, armor stands, item frames that aren't natural)", Category.UTILITY);
    }

    @Override
    protected void onDisable() {
        reset();
    }

    private void reset() {
        foundBlocks.clear();
        reported.clear();
        checks.clear();
        announcedBases.clear();
        groups = new ArrayList<>();
        naturalGroups = new ArrayList<>();
        guaranteedGroups = new ArrayList<>();
        announcedGuaranteed.clear();
        homeBlocks.clear();
        homeQueue.clear();
        messages.clear();
        timer = 0;
    }

    @Override
    public void onTick() {
        ticks++;
        if (mc.player == null || mc.level == null) {
            lastLevel = null;
            return;
        }

        if (mc.level != lastLevel) {
            reset();
            lastLevel = mc.level;
        }

        scanHomeBlocks();
        if (includeSpawners.get() != lastIncludeSpawners) {
            lastIncludeSpawners = includeSpawners.get();
            checks.clear();
            timer = 0;
        }
        if (timer-- <= 0) {
            timer = SCAN_EVERY_TICKS;
            scan();
        }

        boolean printed = false;
        for (int i = 0; i < MESSAGES_PER_TICK && !messages.isEmpty(); i++) {
            mc.player.displayClientMessage(messages.poll(), false);
            printed = true;
        }
        if (printed) {
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.BEACON_ACTIVATE, 1.0F));
        }
    }

    public static final int GUARANTEED_COLOR = 0xFFDC143C;
    public static final int BASE_COLOR = 0xFFFFFF55;
    public static final int NATURAL_COLOR = 0xFFFFFFFF;

    public List<Group> baseGroups() {
        return groups;
    }

    public int colorOf(Group group) {
        if (guaranteedGroups.contains(group)) return GUARANTEED_COLOR;
        return groups.contains(group) ? BASE_COLOR : NATURAL_COLOR;
    }

    public List<Group> espGroups() {
        if (!showNatural.get() || naturalGroups.isEmpty()) return groups;
        List<Group> all = new ArrayList<>(groups);
        all.addAll(naturalGroups);
        return all;
    }

    private static final String[] TYPE_ORDER = {"chest", "spawner", "shulker", "craftingtable", "furnace", "bed", "anvil",
            "door", "ladder", "hopper", "piston", "observer", "sugarcane", "enchanting", "enderchest", "beacon", "lodestone",
            "conduit", "valuable", "concrete", "rail", "portal", "sign", "pet", "named", "minecart", "armorstand", "itemframe"};

    private static final Set<String> CLUES = Set.of("enchanting", "enderchest", "beacon", "lodestone", "conduit", "valuable",
            "concrete", "rail", "portal", "sign", "pet", "named", "minecart");
    private static final int MIN_CLUE_KINDS = 3;
    private static final int CANE_ROW = 6;

    private static String nice(String type, int count) {
        if (type.equals("sugarcane")) return count + " sugar cane (farm)";
        if (type.equals("portal")) return "lit nether portal";
        if (type.equals("concrete")) return count + " concrete";
        String name = switch (type) {
            case "armorstand" -> "armor stand";
            case "itemframe" -> "item frame";
            case "craftingtable" -> "crafting table";
            case "enchanting" -> "enchanting table";
            case "enderchest" -> "ender chest";
            case "valuable" -> "diamond/emerald/netherite/redstone block";
            case "rail" -> "powered/detector/activator rail";
            case "sign" -> "sign with text";
            case "pet" -> "tamed pet";
            case "named" -> "name-tagged mob";
            case "minecart" -> "furnace/hopper/TNT minecart";
            default -> type;
        };
        return count + " " + name + (count == 1 ? "" : name.endsWith("ch") ? "es" : "s");
    }

    private void scan() {
        foundBlocks.keySet().removeIf(p -> mc.level.hasChunkAt(p) && typeOf(mc.level.getBlockEntity(p)) == null);

        int radius = mc.options.getEffectiveRenderDistance() + 1;
        ChunkPos center = mc.player.chunkPosition();
        for (int cx = center.x - radius; cx <= center.x + radius; cx++) {
            for (int cz = center.z - radius; cz <= center.z + radius; cz++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    String type = typeOf(be);
                    if (type != null) foundBlocks.put(be.getBlockPos().immutable(), type);
                }
            }
        }
        rebuildGroups();
    }

    private void scanHomeBlocks() {
        if (homeQueue.isEmpty()) {
            int radius = mc.options.getEffectiveRenderDistance() + 1;
            ChunkPos center = mc.player.chunkPosition();
            Set<Long> loaded = new HashSet<>();
            for (int cx = center.x - radius; cx <= center.x + radius; cx++) {
                for (int cz = center.z - radius; cz <= center.z + radius; cz++) {
                    if (mc.level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false) == null) continue;
                    long key = ChunkPos.asLong(cx, cz);
                    loaded.add(key);
                    homeQueue.add(key);
                }
            }
            homeBlocks.keySet().retainAll(loaded);
            return;
        }
        for (int i = 0; i < HOME_CHUNKS_PER_TICK && !homeQueue.isEmpty(); i++) {
            long key = homeQueue.poll();
            LevelChunk chunk = mc.level.getChunkSource().getChunk(ChunkPos.getX(key), ChunkPos.getZ(key), ChunkStatus.FULL, false);
            if (chunk == null) {
                homeBlocks.remove(key);
                continue;
            }
            Map<BlockPos, String> found = new HashMap<>();
            LevelChunkSection[] sections = chunk.getSections();
            int baseX = chunk.getPos().getMinBlockX(), baseZ = chunk.getPos().getMinBlockZ();
            for (int s = 0; s < sections.length; s++) {
                LevelChunkSection section = sections[s];
                if (section == null || section.hasOnlyAir()) continue;
                if (!section.maybeHas(st -> homeType(st) != null)) continue;
                int baseY = SectionPos.sectionToBlockCoord(chunk.getSectionYFromSectionIndex(s));
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        for (int x = 0; x < 16; x++) {
                            String type = homeType(section.getBlockState(x, y, z));
                            if (type != null) found.put(new BlockPos(baseX + x, baseY + y, baseZ + z), type);
                        }
                    }
                }
            }
            if (found.isEmpty()) homeBlocks.remove(key);
            else homeBlocks.put(key, found);
        }
    }

    private static Set<Block> concrete;

    private static Set<Block> concrete() {
        if (concrete == null) {
            Set<Block> s = new HashSet<>();
            for (Block b : BuiltInRegistries.BLOCK) {
                String path = BuiltInRegistries.BLOCK.getKey(b).getPath();
                if (path.endsWith("_concrete") || path.endsWith("_concrete_powder")) s.add(b);
            }
            concrete = s;
        }
        return concrete;
    }

    private static java.util.Map<Block, String> homeTypes;

    private static String homeType(BlockState state) {
        if (homeTypes == null) {
            java.util.Map<Block, String> map = new java.util.IdentityHashMap<>();
            for (Block b : BuiltInRegistries.BLOCK) {
                String t = homeTypeOf(b);
                if (t != null) map.put(b, t);
            }
            homeTypes = map;
        }
        String type = homeTypes.get(state.getBlock());
        if (type == null) return null;
        if (type.equals("bed")) return state.getValue(BedBlock.PART) == BedPart.HEAD ? "bed" : null;
        if (type.equals("door")) return state.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER ? "door" : null;
        return type;
    }

    private static String homeTypeOf(Block b) {
        if (b == Blocks.CRAFTING_TABLE) return "craftingtable";
        if (b == Blocks.FURNACE) return "furnace";
        if (b == Blocks.LADDER) return "ladder";
        if (b == Blocks.HOPPER) return "hopper";
        if (b == Blocks.PISTON || b == Blocks.STICKY_PISTON) return "piston";
        if (b == Blocks.OBSERVER) return "observer";
        if (b == Blocks.ENCHANTING_TABLE) return "enchanting";
        if (b == Blocks.ENDER_CHEST) return "enderchest";
        if (b == Blocks.BEACON) return "beacon";
        if (b == Blocks.LODESTONE) return "lodestone";
        if (b == Blocks.CONDUIT) return "conduit";
        if (b == Blocks.DIAMOND_BLOCK || b == Blocks.EMERALD_BLOCK || b == Blocks.NETHERITE_BLOCK || b == Blocks.REDSTONE_BLOCK) return "valuable";
        if (b == Blocks.POWERED_RAIL || b == Blocks.DETECTOR_RAIL || b == Blocks.ACTIVATOR_RAIL) return "rail";
        if (b == Blocks.NETHER_PORTAL) return "portal";
        if (concrete().contains(b)) return "concrete";
        if (b == Blocks.SUGAR_CANE) return "cane";
        if (b instanceof AnvilBlock) return "anvil";
        if (b instanceof BedBlock) return "bed";
        if (b instanceof DoorBlock) return "door";
        return null;
    }

    private void rebuildGroups() {
        List<Find> finds = new ArrayList<>();
        for (Map.Entry<BlockPos, String> f : foundBlocks.entrySet()) {
            finds.add(new Find(f.getKey(), f.getValue(), "b" + f.getKey().asLong()));
        }
        Set<BlockPos> cane = new HashSet<>();
        for (Map<BlockPos, String> chunk : homeBlocks.values()) {
            for (Map.Entry<BlockPos, String> f : chunk.entrySet()) {
                if (f.getValue().equals("cane")) cane.add(f.getKey());
                else finds.add(new Find(f.getKey(), f.getValue(), "h" + f.getKey().asLong()));
            }
        }
        for (BlockPos p : caneFarms(cane)) finds.add(new Find(p, "sugarcane", "h" + p.asLong()));
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e instanceof ArmorStand || e instanceof ItemFrame) {
                finds.add(new Find(e.blockPosition(), e instanceof ArmorStand ? "armorstand" : "itemframe", "e" + e.getUUID()));
            } else if (e instanceof net.minecraft.world.entity.TamableAnimal pet && pet.isTame()) {
                finds.add(new Find(e.blockPosition(), "pet", "e" + e.getUUID()));
            } else if (e.hasCustomName() && e instanceof net.minecraft.world.entity.Mob) {
                finds.add(new Find(e.blockPosition(), "named", "e" + e.getUUID()));
            } else if (e instanceof net.minecraft.world.entity.vehicle.minecart.MinecartFurnace
                    || e instanceof net.minecraft.world.entity.vehicle.minecart.MinecartHopper
                    || e instanceof net.minecraft.world.entity.vehicle.minecart.MinecartTNT) {
                finds.add(new Find(e.blockPosition(), "minecart", "e" + e.getUUID()));
            }
        }

        int n = finds.size();
        int[] parent = new int[n];
        for (int i = 0; i < n; i++) parent[i] = i;
        double maxSq = groupDistance.get() * groupDistance.get();
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (finds.get(i).pos().distSqr(finds.get(j).pos()) <= maxSq) union(parent, i, j);
            }
        }
        Map<Integer, List<Find>> byGroup = new HashMap<>();
        for (int i = 0; i < n; i++) byGroup.computeIfAbsent(find(parent, i), k -> new ArrayList<>()).add(finds.get(i));

        List<Group> bases = new ArrayList<>();
        List<Group> natural = new ArrayList<>();
        List<Group> guaranteed = new ArrayList<>();
        Set<Long> stillHere = new HashSet<>();
        int recheckLeft = 2;
        for (List<Find> group : byGroup.values()) {
            long id = groupId(group);
            stillHere.add(id);
            Check check = checks.get(id);
            if (check == null || (ticks - check.timeChecked() > CHECK_EVERY_TICKS && recheckLeft-- > 0)) {
                check = check(group);
                checks.put(id, check);
            }

            AABB box = null;
            Map<String, Integer> counts = new HashMap<>();
            for (Find f : group) {
                box = box == null ? new AABB(f.pos()) : box.minmax(new AABB(f.pos()));
                counts.merge(f.type(), 1, Integer::sum);
            }
            List<String> parts = new ArrayList<>();
            for (String type : TYPE_ORDER) {
                Integer count = counts.get(type);
                if (count != null) parts.add(nice(type, count));
            }
            String what = String.join(", ", parts);

            if (check.guaranteed()) {
                Group g = new Group(box.inflate(1.0), "GUARANTEED BASE: " + what);
                bases.add(g);
                guaranteed.add(g);
                announceGuaranteed(group, box, check);
            } else if (check.base()) {
                String where = check.structure() != null ? " (next to a " + check.structure() + ")" : "";
                bases.add(new Group(box.inflate(1.0), "Possible base" + where + ": " + what));
                announce(group, box, check, id);
            } else {
                natural.add(new Group(box.inflate(1.0), "Natural" + (check.structure() != null ? " " + check.structure() : "") + ": " + what));
            }
        }
        checks.keySet().retainAll(stillHere);
        groups = bases;
        naturalGroups = natural;
        guaranteedGroups = guaranteed;
    }

    private static List<BlockPos> caneFarms(Set<BlockPos> cane) {
        Set<BlockPos> bottoms = new HashSet<>();
        for (BlockPos p : cane) if (!cane.contains(p.below())) bottoms.add(p);
        Set<BlockPos> farm = new HashSet<>();
        for (BlockPos p : bottoms) {
            for (int axis = 0; axis < 2; axis++) {
                int dx = axis == 0 ? 1 : 0, dz = axis == 0 ? 0 : 1;
                if (bottoms.contains(p.offset(-dx, 0, -dz))) continue;
                List<BlockPos> row = new ArrayList<>();
                for (BlockPos q = p; bottoms.contains(q); q = q.offset(dx, 0, dz)) row.add(q);
                if (row.size() >= CANE_ROW) farm.addAll(row);
            }
        }
        return new ArrayList<>(farm);
    }

    private static long groupId(List<Find> group) {
        long h = 1125899906842597L;
        List<String> keys = new ArrayList<>();
        for (Find f : group) keys.add(f.key());
        keys.sort(null);
        for (String k : keys) h = 31 * h + k.hashCode();
        return h;
    }

    private Check check(List<Find> group) {
        Map<String, Integer> counts = new HashMap<>();
        Map<String, Boolean> terrain = new HashMap<>();
        Map<Block, String> names = new HashMap<>();
        Set<Long> visited = new HashSet<>();
        int armorStands = 0, itemFrames = 0;
        int step = Math.max(1, group.size() / MAX_FINDS_CHECKED);

        for (int i = 0; i < group.size(); i++) {
            Find f = group.get(i);
            if (f.type().equals("armorstand")) armorStands++;
            if (f.type().equals("itemframe")) itemFrames++;
            if (i % step != 0) continue;
            for (BlockPos p : BlockPos.betweenClosed(f.pos().offset(-LOOK_RADIUS, -LOOK_RADIUS, -LOOK_RADIUS),
                    f.pos().offset(LOOK_RADIUS, LOOK_RADIUS, LOOK_RADIUS))) {
                if (!visited.add(p.asLong()) || !mc.level.hasChunkAt(p)) continue;
                BlockState state = mc.level.getBlockState(p);
                if (state.isAir()) continue;
                String path = names.computeIfAbsent(state.getBlock(), b -> BuiltInRegistries.BLOCK.getKey(b).getPath());
                counts.merge(path, 1, Integer::sum);
                terrain.computeIfAbsent(path, k -> NaturalStructures.isTerrain(state, k));
            }
        }

        Find first = group.get(0);
        int villagers = 0;
        for (Entity e : mc.level.entitiesForRendering()) {
            if ((e instanceof Villager || e instanceof ZombieVillager)
                    && e.blockPosition().distSqr(first.pos()) <= VILLAGER_RANGE * VILLAGER_RANGE) villagers++;
        }
        if (villagers > 0) counts.put(NaturalStructures.VILLAGER, villagers);
        boolean doubleChest = chestBase(group);
        NaturalStructures.Result r = NaturalStructures.classify(counts, terrain, armorStands, itemFrames, doubleChest);

        boolean somethingElse = false;
        for (Find f : group) if (!f.type().equals("chest")) somethingElse = true;
        boolean chestSure = doubleChest && somethingElse;

        boolean caneFarm = false;
        for (Find f : group) if (f.type().equals("sugarcane")) caneFarm = true;
        List<String> clues = r.clues();
        if (caneFarm) {
            clues = new ArrayList<>(clues);
            clues.add(0, "sugar cane farm");
        }

        Set<String> kinds = new java.util.LinkedHashSet<>();
        for (Find f : group) if (CLUES.contains(f.type())) kinds.add(f.type());
        if (!kinds.isEmpty()) {
            clues = new ArrayList<>(clues);
            for (String k : kinds) clues.add(0, nice(k, 1).replaceFirst("^1 ", ""));
        }
        boolean clueBase = !kinds.isEmpty();
        boolean clueSure = kinds.size() >= MIN_CLUE_KINDS;
        if (doubleChest) {
            clues = new ArrayList<>(clues);
            clues.remove("chest");
            clues.add(0, "double chest");
        }

        boolean spawnerSure = false;
        if (includeSpawners.get()) {
            for (Find f : group) if (f.type().equals("spawner")) spawnerSure = true;
            if (spawnerSure && !clues.contains("spawner")) {
                clues = new ArrayList<>(clues);
                clues.add(0, "spawner");
            }
        }
        return new Check(r.base() || caneFarm || clueBase || doubleChest || spawnerSure,
                r.guaranteed() || caneFarm || clueSure || chestSure || spawnerSure,
                r.structure(), clues, ticks);
    }

    private boolean chestBase(List<Find> group) {
        List<BlockPos> chests = new ArrayList<>();
        for (Find f : group) {
            if (f.type().equals("spawner") && !includeSpawners.get()) return false;
            if (f.type().equals("chest")) chests.add(f.pos());
        }
        for (BlockPos p : chests) {
            if (!mc.level.hasChunkAt(p)) continue;
            BlockState state = mc.level.getBlockState(p);
            if (state.getBlock() instanceof ChestBlock && state.getValue(ChestBlock.TYPE) != ChestType.SINGLE) return true;
        }
        return false;
    }

    private void announceGuaranteed(List<Find> group, AABB box, Check check) {
        Vec3 center = box.getCenter();
        for (Vec3 old : announcedGuaranteed) {
            if (old.distanceToSqr(center) <= groupDistance.get() * groupDistance.get()) return;
        }
        announcedGuaranteed.add(center);
        int cx = (int) Math.floor(center.x), cy = (int) Math.floor(center.y), cz = (int) Math.floor(center.z);
        mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.ELDER_GUARDIAN_CURSE, 1.0F));
        mc.gui.setTimes(10, 60, 20);
        mc.gui.setSubtitle(Component.literal("GUARANTEED BASE FOUND").withStyle(ChatFormatting.RED));
        mc.gui.setTitle(Component.literal("WARNING").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
        List<String> clues = check.clues().size() > 5 ? check.clues().subList(0, 5) : check.clues();
        mc.player.displayClientMessage(Component.literal("[BaseW] ").withStyle(ChatFormatting.RED)
                .append(Component.literal("GUARANTEED BASE at " + cx + ", " + cy + ", " + cz).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD))
                .append(Component.literal(clues.isEmpty() ? "" : " (" + String.join(", ", clues) + ")").withStyle(ChatFormatting.WHITE)), false);
    }

    private void announce(List<Find> group, AABB box, Check check, long id) {
        if (announcedBases.add(id)) {
            int cx = (int) Math.floor((box.minX + box.maxX) / 2), cy = (int) Math.floor((box.minY + box.maxY) / 2),
                    cz = (int) Math.floor((box.minZ + box.maxZ) / 2);
            List<String> clues = check.clues().size() > 4 ? check.clues().subList(0, 4) : check.clues();
            messages.add(Component.literal("[BaseW] ").withStyle(ChatFormatting.RED)
                    .append(Component.literal("Possible base at " + cx + ", " + cy + ", " + cz
                            + (clues.isEmpty() ? "" : " (player blocks: " + String.join(", ", clues) + ")")).withStyle(ChatFormatting.WHITE)));
        }
        for (Find f : group) {
            if (f.key().startsWith("h")) continue;
            if (!reported.add(f.key())) continue;
            BlockPos pos = f.pos();
            messages.add(Component.literal("[BaseW] ").withStyle(ChatFormatting.RED)
                    .append(Component.literal("Detected " + nice(f.type(), 1).replaceFirst("^1 ", "") + " at "
                            + pos.getX() + ", " + pos.getY() + ", " + pos.getZ()).withStyle(ChatFormatting.WHITE)));
        }
    }

    private static int find(int[] parent, int i) {
        while (parent[i] != i) {
            parent[i] = parent[parent[i]];
            i = parent[i];
        }
        return i;
    }

    private static void union(int[] parent, int a, int b) {
        parent[find(parent, a)] = find(parent, b);
    }

    private static boolean hasText(net.minecraft.world.level.block.entity.SignText text) {
        for (Component line : text.getMessages(false)) if (!line.getString().isBlank()) return true;
        return false;
    }

    private static String typeOf(BlockEntity be) {
        if (be == null) return null;
        if (be instanceof ChestBlockEntity) return "chest";
        if (be instanceof SpawnerBlockEntity) return "spawner";
        if (be instanceof ShulkerBoxBlockEntity) return "shulker";
        if (be instanceof net.minecraft.world.level.block.entity.SignBlockEntity sign
                && (hasText(sign.getFrontText()) || hasText(sign.getBackText()))) return "sign";
        return null;
    }
}
