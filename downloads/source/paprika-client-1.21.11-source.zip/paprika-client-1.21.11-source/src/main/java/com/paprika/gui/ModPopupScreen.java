package com.paprika.gui;

import com.paprika.Config;
import com.paprika.module.Module;
import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.ModeSetting;
import com.paprika.module.setting.NumberSetting;
import com.paprika.module.setting.Setting;
import com.paprika.module.setting.TextSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ModPopupScreen extends Screen {
    private static final int W = 220, HEADER = 14, PAD = 5, ROW = 16, SECTION = 14, LINE = 10;
    private static final int WHITE = 0xFFFFFFFF, LABEL = 0xFFDDDDDD, DESC = 0xFFBBBBBB;

    private enum Kind { DESC, WARN, SECTION, SETTING, BIND }

    private record Item(Kind kind, int y, int h, Setting setting, FormattedCharSequence text, String title) {}

    private final Module module;
    private final Screen parent;
    private int px, py, panelH, scroll;
    private NumberSetting dragging;
    private TextSetting typing;
    private boolean bindListening;
    private final KeyCapture capture = new KeyCapture();
    private static final int BIND_W = 90;

    public ModPopupScreen(Module module, Screen parent) {
        super(Component.literal(module.getName()));
        this.module = module;
        this.parent = parent;
    }

    @Override
    protected void init() {
        if (parent != null && minecraft != null) parent.init(width, height);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
    }

    private List<Item> items() {
        List<Item> list = new ArrayList<>();
        int y = 3;
        for (FormattedCharSequence line : font.split(Ui.text(module.getDescription()), W - PAD * 2)) {
            list.add(new Item(Kind.DESC, y, LINE, null, line, null));
            y += LINE;
        }
        if (module.warning() != null) {
            list.add(new Item(Kind.WARN, y + 2, LINE + 2, null, null, module.warning()));
            y += LINE + 4;
        }
        y += 2;
        if (module.hasSettings()) {
            list.add(new Item(Kind.SECTION, y, SECTION, null, null, "Settings"));
            y += SECTION;
            for (Setting s : module.getSettings()) {
                list.add(new Item(Kind.SETTING, y, ROW, s, null, null));
                y += ROW;
            }
        }
        list.add(new Item(Kind.SECTION, y, SECTION, null, null, "Bind"));
        y += SECTION;
        list.add(new Item(Kind.BIND, y, ROW, null, null, null));
        return list;
    }

    private int contentHeight(List<Item> items) {
        Item last = items.get(items.size() - 1);
        return last.y() + last.h() + 4;
    }

    private void layout(List<Item> items) {
        int maxH = height - 20;
        panelH = Math.min(HEADER + contentHeight(items), maxH);
        px = (width - W) / 2;
        py = (height - panelH) / 2;
        scroll = Math.max(0, Math.min(scroll, maxScroll(items)));
    }

    private int maxScroll(List<Item> items) {
        return Math.max(0, contentHeight(items) - (panelH - HEADER));
    }

    private int top() { return py + HEADER; }
    private int rowY(Item it) { return top() + it.y() - scroll; }
    private int labelX() { return px + PAD + 3; }
    private int controlX() { return px + 92; }
    private int resetX() { return px + W - PAD - 10; }
    private boolean visible(Item it) { return rowY(it) + it.h() > top() && rowY(it) < py + panelH; }

    private int sliderX() { return controlX() + 40; }
    private int sliderW() { return resetX() - 6 - sliderX(); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        List<Item> items = items();
        layout(items);
        Theme theme = Theme.current();

        Ui.round(g, px, py, W, panelH, 6, 0xE8141414);
        Ui.roundTop(g, px, py, W, HEADER, 6, theme.accentArgb(0xFF));
        Ui.centered(g, font, module.getName(), px + W / 2, py + 3, WHITE);

        g.enableScissor(px, top(), px + W, py + panelH);
        for (Item it : items) {
            if (!visible(it)) continue;
            int y = rowY(it);
            switch (it.kind()) {
                case DESC -> g.drawString(font, it.text(), px + PAD, y, DESC, false);
                case WARN -> Ui.centered(g, font, it.title(), px + W / 2, y, 0xFFFF3333);
                case SECTION -> section(g, it.title(), y);
                case SETTING -> drawSetting(g, it.setting(), y, mouseX, mouseY, theme);
                case BIND -> drawBind(g, y, mouseX, mouseY, theme);
            }
        }
        g.disableScissor();

        int max = maxScroll(items);
        if (max > 0) {
            int areaH = panelH - HEADER;
            int barH = Math.max(12, areaH * areaH / (areaH + max));
            int barY = top() + (areaH - barH) * scroll / max;
            Ui.round(g, px + W - 3, barY, 2, barH, 1, theme.accentArgb(0xC0));
        }
    }

    private void section(GuiGraphics g, String title, int y) {
        int tw = Ui.width(font, title);
        int cx = px + W / 2, ly = y + 6;
        g.fill(px + PAD, ly, cx - tw / 2 - 3, ly + 1, 0x80FFFFFF);
        g.fill(cx + tw / 2 + 3, ly, px + W - PAD, ly + 1, 0x80FFFFFF);
        Ui.centered(g, font, title, cx, y + 2, LABEL);
    }

    private void drawSetting(GuiGraphics g, Setting s, int y, int mouseX, int mouseY, Theme theme) {
        Ui.draw(g, font, s.getName(), labelX(), y + 4, LABEL);
        int cx = controlX(), cy = y + 3;
        if (s instanceof BoolSetting b) {
            Ui.round(g, cx, cy, 10, 10, 3, b.get() ? theme.accentArgb(0xFF) : 0xFF2A2A2A);
            if (b.get()) Ui.round(g, cx + 3, cy + 3, 4, 4, 2, 0xFFFFFFFF);
        } else if (s instanceof NumberSetting n) {
            Ui.round(g, cx, cy - 1, 36, 12, 3, 0xFF2A2A2A);
            String v = n.display();
            while (Ui.width(font, v) > 34 && v.length() > 1) v = v.substring(0, v.length() - 1);
            Ui.draw(g, font, v, cx + 2, cy + 1, WHITE);
            int sx = sliderX(), sw = sliderW(), ly = y + 8;
            int knob = sx + (int) Math.round(n.fraction() * sw);
            g.fill(sx, ly, sx + sw, ly + 1, 0xFF555555);
            g.fill(sx, ly, knob, ly + 1, theme.accentArgb(0xFF));
            Ui.circle(g, knob, ly, 3, theme.accentArgb(0xFF));
        } else if (s instanceof ModeSetting m) {
            int w = Math.min(90, resetX() - 6 - cx);
            boolean hover = inside(mouseX, mouseY, cx, cy - 1, w, 12);
            Ui.round(g, cx, cy - 1, w, 12, 3, hover ? 0xFF3A3A3A : 0xFF2A2A2A);
            Ui.draw(g, font, m.get(), cx + 4, cy + 1, WHITE);
            int ax = cx + w - 9, ay = cy + 3;
            g.fill(ax, ay, ax + 5, ay + 1, WHITE);
            g.fill(ax + 1, ay + 1, ax + 4, ay + 2, WHITE);
            g.fill(ax + 2, ay + 2, ax + 3, ay + 3, WHITE);
        } else if (s instanceof TextSetting t) {
            int w = resetX() - 6 - cx;
            Ui.round(g, cx, cy - 1, w, 12, 3, 0xFF2A2A2A);
            if (t == typing) g.fill(cx, cy + 10, cx + w, cy + 11, theme.accentArgb(0xFF));
            String shown = t.get();
            while (Ui.width(font, shown) > w - 8 && shown.length() > 1) shown = shown.substring(1);
            boolean cursor = t == typing && (System.currentTimeMillis() / 500) % 2 == 0;
            Ui.draw(g, font, shown + (cursor ? "_" : ""), cx + 2, cy + 1, WHITE);
        }
        resetIcon(g, resetX(), y + 3, inside(mouseX, mouseY, resetX(), y + 3, 10, 10));
    }

    private void drawBind(GuiGraphics g, int y, int mouseX, int mouseY, Theme theme) {
        Ui.draw(g, font, "Bind:", labelX(), y + 4, LABEL);
        Integer held = bindListening ? capture.current() : null;
        String key = bindListening ? (held != null ? KeyCapture.name(held) + "..." : "Press keys...")
                : KeyCapture.name(module.getKeybind());
        int cx = bindX(), w = BIND_W;
        boolean hover = inside(mouseX, mouseY, cx, y + 2, w, 12);
        Ui.round(g, cx, y + 2, w, 12, 3, 0xFF2A2A2A);
        if (hover || bindListening) g.fill(cx, y + 13, cx + w, y + 14, theme.accentArgb(0xFF));
        int tw = Ui.width(font, key);
        float s = tw > w - 6 ? Math.max(0.5F, (w - 6) / (float) tw) : 1.0F;
        g.pose().pushMatrix();
        g.pose().translate((float) (cx + 3), (float) (y + 8));
        g.pose().scale((float) (s), (float) (s));
        Ui.draw(g, font, key, 0, -4, WHITE);
        g.pose().popMatrix();
        resetIcon(g, resetX(), y + 3, inside(mouseX, mouseY, resetX(), y + 3, 10, 10));
    }

    private int bindX() {
        return labelX() + Ui.width(font, "Bind:") + 4;
    }

    private static void resetIcon(GuiGraphics g, int x, int y, boolean hover) {
        int c = hover ? WHITE : 0xFFAAAAAA;
        g.fill(x + 3, y, x + 8, y + 1, c);
        g.fill(x + 1, y + 1, x + 3, y + 2, c);
        g.fill(x, y + 2, x + 1, y + 7, c);
        g.fill(x + 1, y + 7, x + 3, y + 8, c);
        g.fill(x + 3, y + 8, x + 7, y + 9, c);
        g.fill(x + 7, y + 7, x + 9, y + 8, c);
        g.fill(x + 9, y + 4, x + 10, y + 7, c);
        g.fill(x + 6, y - 1, x + 7, y + 3, c);
        g.fill(x + 7, y, x + 9, y + 1, c);
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent paprika$e, boolean paprika$dbl) {
        double mouseX = paprika$e.x(), mouseY = paprika$e.y();
        int button = paprika$e.button();
        stopTyping();
        List<Item> items = items();
        layout(items);
        if (!inside(mouseX, mouseY, px, py, W, panelH)) {
            onClose();
            return true;
        }
        bindListening = false;
        if (button != 0 || mouseY < top()) return true;
        for (Item it : items) {
            if (!visible(it)) continue;
            int y = rowY(it);
            if (mouseY < y || mouseY >= y + it.h()) continue;
            if (it.kind() == Kind.SETTING) {
                Setting s = it.setting();
                if (inside(mouseX, mouseY, resetX() - 1, y + 2, 12, 12)) {
                    s.reset();
                    Config.save();
                    click();
                } else if (s instanceof BoolSetting b && inside(mouseX, mouseY, controlX() - 2, y + 1, 14, 14)) {
                    b.toggle();
                    Config.save();
                    click();
                } else if (s instanceof NumberSetting n && inside(mouseX, mouseY, sliderX() - 4, y, sliderW() + 8, ROW)) {
                    dragging = n;
                    slide(mouseX);
                } else if (s instanceof ModeSetting m && inside(mouseX, mouseY, controlX(), y + 2, Math.min(90, resetX() - 6 - controlX()), 12)) {
                    m.cycle();
                    Config.save();
                    click();
                } else if (s instanceof TextSetting t && mouseX >= controlX() && mouseX < resetX() - 6) {
                    typing = t;
                    click();
                }
            } else if (it.kind() == Kind.BIND) {
                if (inside(mouseX, mouseY, resetX() - 1, y + 2, 12, 12)) {
                    module.setKeybind(-1);
                    Config.save();
                    click();
                } else if (inside(mouseX, mouseY, bindX(), y + 2, BIND_W, 12)) {
                    bindListening = true;
                    capture.reset();
                    click();
                }
            }
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(net.minecraft.client.input.MouseButtonEvent paprika$e, double dx, double dy) {
        double mouseX = paprika$e.x(), mouseY = paprika$e.y();
        int button = paprika$e.button();
        if (dragging != null) {
            slide(mouseX);
            return true;
        }
        return super.mouseDragged(paprika$e, dx, dy);
    }

    @Override
    public boolean mouseReleased(net.minecraft.client.input.MouseButtonEvent paprika$e) {
        double mouseX = paprika$e.x(), mouseY = paprika$e.y();
        int button = paprika$e.button();
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(paprika$e);
    }

    private void slide(double mouseX) {
        dragging.setFraction(Math.max(0, Math.min(1, (mouseX - sliderX()) / sliderW())));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double delta) {
        scroll -= (int) (delta * ROW * 2);
        return true;
    }
    private void stopTyping() {
        if (typing != null) {
            typing.set(typing.get().trim());
            typing = null;
            Config.save();
        }
    }

    @Override
    public boolean charTyped(net.minecraft.client.input.CharacterEvent paprika$c) {
        char c = (char) paprika$c.codepoint();
        int modifiers = paprika$c.modifiers();
        if (typing != null && c >= ' ' && c != 127 && typing.get().length() < 200) {
            typing.set(typing.get() + c);
            return true;
        }
        return super.charTyped(paprika$c);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent paprika$k) {
        int keyCode = paprika$k.key(), scanCode = paprika$k.scancode(), modifiers = paprika$k.modifiers();
        if (bindListening) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                module.setKeybind(-1);
                bindListening = false;
                Config.save();
            } else {
                capture.press(keyCode);
            }
            return true;
        }
        if (typing != null) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                String v = typing.get();
                if (!v.isEmpty()) typing.set(v.substring(0, v.length() - 1));
            } else if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER || keyCode == GLFW.GLFW_KEY_ESCAPE) {
                stopTyping();
            } else if (keyCode == GLFW.GLFW_KEY_V && (modifiers & GLFW.GLFW_MOD_CONTROL) != 0 && minecraft != null) {
                typing.set(typing.get() + minecraft.keyboardHandler.getClipboard().replace("\n", ""));
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(paprika$k);
    }

    @Override
    public boolean keyReleased(net.minecraft.client.input.KeyEvent paprika$k) {
        int keyCode = paprika$k.key(), scanCode = paprika$k.scancode(), modifiers = paprika$k.modifiers();
        if (bindListening) {
            Integer bind = capture.release(keyCode);
            if (bind != null) {
                module.setKeybind(bind);
                bindListening = false;
                Config.save();
            }
            return true;
        }
        return super.keyReleased(paprika$k);
    }

    @Override
    public void onClose() {
        stopTyping();
        Config.save();
        if (minecraft != null) minecraft.setScreen(parent);
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void click() {
        if (minecraft != null) minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }
}
