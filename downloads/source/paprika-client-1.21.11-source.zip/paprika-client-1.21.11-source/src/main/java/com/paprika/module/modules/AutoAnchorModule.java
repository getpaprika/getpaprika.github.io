package com.paprika.module.modules;

import com.paprika.baritone.Pathfinder;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class AutoAnchorModule extends Module {
    private enum Step { IDLE, WAIT_ANCHOR, CHARGE, WAIT_CHARGE, SHIELD, EXPLODE }

    private Step step = Step.IDLE;
    private BlockPos anchor;
    private int timer;
    private int startSlot;
    private boolean useWasDown;

    public AutoAnchorModule() {
        super("AutoAnchor", "Place an anchor and it charges, shields and explodes it for you", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        step = Step.IDLE;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null) {
            step = Step.IDLE;
            return;
        }
        boolean useDown = mc.options.keyUse.isDown();
        boolean clicked = useDown && !useWasDown;
        useWasDown = useDown;

        switch (step) {
            case IDLE -> {
                if (clicked && mc.screen == null && canExplodeHere()
                        && mc.player.getMainHandItem().is(Items.RESPAWN_ANCHOR)
                        && mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
                    BlockPos clickedPos = hit.getBlockPos();
                    anchor = mc.level.getBlockState(clickedPos).canBeReplaced()
                            ? clickedPos : clickedPos.relative(hit.getDirection());
                    startSlot = mc.player.getInventory().getSelectedSlot();
                    timer = 0;
                    step = Step.WAIT_ANCHOR;
                }
            }
            case WAIT_ANCHOR -> {
                if (anchorState() != null) {
                    step = Step.CHARGE;
                } else if (++timer > 10) {
                    step = Step.IDLE;
                }
            }
            case CHARGE -> {
                int glow = slotOf(Items.GLOWSTONE);
                if (glow < 0) {
                    finish();
                    return;
                }
                select(glow);
                clickAnchor();
                timer = 0;
                step = Step.WAIT_CHARGE;
            }
            case WAIT_CHARGE -> {
                BlockState state = anchorState();
                if (state == null) {
                    finish();
                } else if (state.getValue(RespawnAnchorBlock.CHARGE) > 0) {
                    step = Step.SHIELD;
                } else if (++timer > 6) {
                    step = Step.CHARGE;
                }
            }
            case SHIELD -> {
                placeShield();
                step = Step.EXPLODE;
            }
            case EXPLODE -> {
                if (anchorState() == null) {
                    finish();
                    return;
                }
                int slot = slotOf(Items.TOTEM_OF_UNDYING);
                if (slot < 0) slot = swordSlot();
                if (slot >= 0) {
                    select(slot);
                    clickAnchor();
                }
                finish();
            }
        }
    }

    private void placeShield() {
        int glow = slotOf(Items.GLOWSTONE);
        if (glow < 0) return;

        Vec3 toMe = mc.player.position().subtract(Vec3.atCenterOf(anchor));
        Direction side = Direction.getApproximateNearest(toMe.x, 0, toMe.z);
        BlockPos shield = anchor.relative(side);

        if (!Pathfinder.isReplaceable(mc.level, shield)) return;
        if (mc.player.getBoundingBox().intersects(new net.minecraft.world.phys.AABB(shield))) return;

        BlockPos below = shield.below();
        if (Pathfinder.isReplaceable(mc.level, below)) return;
        select(glow);
        Vec3 hit = Vec3.atCenterOf(below).add(0, 0.5, 0);
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, Direction.UP, below, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private void clickAnchor() {
        Vec3 toMe = mc.player.getEyePosition().subtract(Vec3.atCenterOf(anchor));
        Direction face = Direction.getApproximateNearest(toMe.x, toMe.y, toMe.z);
        Vec3 hit = Vec3.atCenterOf(anchor).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, anchor, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private void finish() {
        if (mc.player != null && startSlot >= 0 && startSlot < 9) select(startSlot);
        step = Step.IDLE;
    }

    private BlockState anchorState() {
        BlockState state = mc.level.getBlockState(anchor);
        return state.is(Blocks.RESPAWN_ANCHOR) ? state : null;
    }

    private boolean canExplodeHere() {
        return !mc.level.environmentAttributes().getValue(net.minecraft.world.attribute.EnvironmentAttributes.RESPAWN_ANCHOR_WORKS, mc.player.position());
    }

    private void select(int slot) {
        mc.player.getInventory().setSelectedSlot(slot);
    }

    private int slotOf(net.minecraft.world.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getItem(i).is(item)) return i;
        }
        return -1;
    }

    private int swordSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getItem(i).is(net.minecraft.tags.ItemTags.SWORDS)) return i;
        }
        return -1;
    }
}
