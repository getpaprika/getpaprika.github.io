package com.paprika.mixin;

import com.paprika.module.modules.ZoomModule;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererFovMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void paprika$zoom(CallbackInfoReturnable<Float> cir) {
        double factor = ZoomModule.fovFactor();
        if (factor != 1.0) cir.setReturnValue((float) (cir.getReturnValue() * factor));
    }
}
