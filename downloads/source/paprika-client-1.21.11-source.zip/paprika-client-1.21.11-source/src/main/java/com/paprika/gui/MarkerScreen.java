package com.paprika.gui;

import com.paprika.Config;
import com.paprika.command.Areas;
import com.paprika.command.Markers;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class MarkerScreen extends Screen {
    private static final int PANEL_BG = 0x66000000;
    private static final int TAB_BG = 0x40FFFFFF;
    private static final int TAB_HOVER = 0x60FFFFFF;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFF888888;

    private static final int PANEL_W = 320;
    private static final int PANEL_H = 214;
    private static final int HEADER_H = 22;
    private static final int TAB_H = 16;
    private static final int GAP = 6;
    private static final int SWATCH = 14;
    private static final int ROW_H = 20;

    private static final int[] COLORS = {
            0xFF0000, 0xFF5500, 0xFFAA00, 0xFFFF00, 0xAAFF00, 0x00FF00, 0x00FF88, 0x00FFFF,
            0x0088FF, 0x0000FF, 0x8800FF, 0xFF00FF, 0xFF0088, 0xFF8888, 0x88FF88, 0x8888FF,
            0xFFFFFF, 0xAAAAAA, 0x555555, 0x000000, 0x8B4513, 0xFFD700, 0x40E0D0, 0xDC143C
    };

    private static boolean listTab;
    private static int selectedColor = 0xFF0000;

    private int px, py;
    private int scroll;
    private EditBox name, xBox, yBox, zBox;
    private String message = "";
    private int messageColor = WHITE;

    public MarkerScreen() {
        super(Component.literal("Markers"));
        listTab = false;
    }

    @Override
    protected void init() {
        px = (width - PANEL_W) / 2;
        py = (height - PANEL_H) / 2;
        int top = contentTop();

        name = new EditBox(font, px + 70, top, 160, 14, Component.literal("Name"));
        name.setMaxLength(24);
        name.setHint(Component.literal("e.g. home").withStyle(ChatFormatting.DARK_GRAY));

        BlockPos me = minecraft != null && minecraft.player != null ? minecraft.player.blockPosition() : BlockPos.ZERO;
        int cy = top + 22 + 3 * (SWATCH + 3) + 10;
        xBox = coordBox(px + 70, cy, me.getX(), "X");
        yBox = coordBox(px + 70 + 62, cy, me.getY(), "Y");
        zBox = coordBox(px + 70 + 124, cy, me.getZ(), "Z");

        if (!listTab) {
            addRenderableWidget(name);
            addRenderableWidget(xBox);
            addRenderableWidget(yBox);
            addRenderableWidget(zBox);
            setInitialFocus(name);
        }
    }

    private EditBox coordBox(int x, int y, int value, String label) {
        EditBox box = new EditBox(font, x, y, 56, 14, Component.literal(label));
        box.setMaxLength(9);
        box.setValue(String.valueOf(value));
        box.setFilter(s -> s.matches("-?\\d*"));
        return box;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
    }

    private int contentTop() { return py + HEADER_H + GAP + TAB_H + GAP + 4; }
    private int tabW() { return (PANEL_W - GAP * 3) / 2; }
    private int tabY() { return py + HEADER_H + GAP; }
    private int createX() { return px + (PANEL_W - 100) / 2; }
    private int createY() { return py + PANEL_H - 30; }
    private int swatchX(int i) { return px + 70 + (i % 8) * (SWATCH + 3); }
    private int swatchY(int i) { return contentTop() + 22 + (i / 8) * (SWATCH + 3); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        Theme theme = Theme.current();
        g.fill(px, py, px + PANEL_W, py + PANEL_H, PANEL_BG);
        outline(g, px, py, PANEL_W, PANEL_H, theme.accentArgb(0x88));
        g.drawString(font, "Markers", px + 8, py + 7, theme.accentArgb(0xFF), true);
        g.fill(px, py + HEADER_H, px + PANEL_W, py + HEADER_H + 1, theme.accentArgb(0x88));

        String[] tabs = {"Marker", "List"};
        for (int i = 0; i < 2; i++) {
            int tx = px + GAP + i * (tabW() + GAP);
            boolean selected = (i == 1) == listTab;
            boolean hover = inside(mouseX, mouseY, tx, tabY(), tabW(), TAB_H);
            g.fill(tx, tabY(), tx + tabW(), tabY() + TAB_H, selected ? theme.accentArgb(0x90) : hover ? TAB_HOVER : TAB_BG);
            g.drawCenteredString(font, tabs[i], tx + tabW() / 2, tabY() + 4, WHITE);
        }

        String tooltip = null;
        if (!listTab) {
            int top = contentTop();
            g.drawString(font, "Name", px + 12, top + 3, WHITE, true);
            g.drawString(font, "Color", px + 12, top + 25, WHITE, true);
            for (int i = 0; i < COLORS.length; i++) {
                int sx = swatchX(i), sy = swatchY(i);
                g.fill(sx, sy, sx + SWATCH, sy + SWATCH, 0xFF000000 | COLORS[i]);
                boolean picked = COLORS[i] == selectedColor;
                boolean hover = inside(mouseX, mouseY, sx, sy, SWATCH, SWATCH);
                if (picked || hover) outline(g, sx - 1, sy - 1, SWATCH + 2, SWATCH + 2, picked ? WHITE : 0xA0FFFFFF);
            }
            int cy = top + 22 + 3 * (SWATCH + 3) + 10;
            g.drawString(font, "Position", px + 12, cy + 3, WHITE, true);

            int prevX = px + PANEL_W - 30, prevY = top + 36;
            diamond(g, prevX, prevY, 7, 0xFF000000);
            diamond(g, prevX, prevY, 6, 0xFF000000 | selectedColor);

            boolean hover = inside(mouseX, mouseY, createX(), createY(), 100, 18);
            g.fill(createX(), createY(), createX() + 100, createY() + 18, theme.onArgb(hover));
            g.drawCenteredString(font, "Create", createX() + 50, createY() + 5, WHITE);
            if (!message.isEmpty()) g.drawCenteredString(font, message, px + PANEL_W / 2, createY() - 12, messageColor);
        } else {
            List<Markers.Marker> markers = Markers.current();
            int top = contentTop() - 4;
            int bottom = py + PANEL_H - 8;
            clampScroll(markers.size());
            if (markers.isEmpty()) {
                g.drawCenteredString(font, "No markers in this world yet", px + PANEL_W / 2, top + 10, 0xFFAAAAAA);
            }
            g.enableScissor(px + 1, top, px + PANEL_W - 1, bottom);
            Vec3 me = minecraft != null && minecraft.player != null ? minecraft.player.position() : Vec3.ZERO;
            for (int i = 0; i < markers.size(); i++) {
                Markers.Marker m = markers.get(i);
                int ry = top + i * (ROW_H + 3) - scroll;
                boolean rowHover = inside(mouseX, mouseY, px + GAP, ry, PANEL_W - GAP * 2, ROW_H) && mouseY >= top && mouseY < bottom;
                g.fill(px + GAP, ry, px + PANEL_W - GAP, ry + ROW_H, rowHover ? 0x50FFFFFF : 0x30FFFFFF);
                g.fill(px + GAP + 4, ry + 4, px + GAP + 16, ry + 16, 0xFF000000 | m.color());
                int dist = (int) Math.round(me.distanceTo(new Vec3(m.x(), m.y(), m.z())));
                g.drawString(font, m.name(), px + GAP + 22, ry + 6, Markers.isHidden(m) ? GRAY : 0xFF000000 | m.color(), true);
                String info = (int) Math.floor(m.x()) + " " + (int) m.y() + " " + (int) Math.floor(m.z()) + "  (" + dist + "m)";
                g.drawString(font, info, px + PANEL_W - GAP - 42 - font.width(info) - 4, ry + 6, 0xFFCCCCCC, true);

                int ex = px + PANEL_W - GAP - 40, ey = ry + 2;
                boolean hidden = Markers.isHidden(m);
                boolean overEye = inside(mouseX, mouseY, ex, ey, 16, 16) && mouseY >= top && mouseY < bottom;
                g.fill(ex, ey, ex + 16, ey + 16, overEye ? 0xE0777777 : 0xA0444444);
                drawEye(g, ex, ey, !hidden);
                if (overEye) tooltip = (hidden ? "Show " : "Hide ") + m.name();

                int bx = px + PANEL_W - GAP - 20, by = ry + 2;
                boolean overTrash = inside(mouseX, mouseY, bx, by, 16, 16) && mouseY >= top && mouseY < bottom;
                g.fill(bx, by, bx + 16, by + 16, overTrash ? 0xE0FF3333 : 0xA0CC2222);
                drawTrash(g, bx, by);
                if (overTrash) tooltip = "Delete " + m.name();
            }
            g.disableScissor();
        }

        super.render(g, mouseX, mouseY, partialTick);
        if (tooltip != null) g.setTooltipForNextFrame(font, Component.literal(tooltip), mouseX, mouseY);
    }

    private static void drawEye(GuiGraphics g, int x, int y, boolean open) {
        if (open) {
            g.fill(x + 5, y + 4, x + 11, y + 5, WHITE);
            g.fill(x + 3, y + 5, x + 5, y + 6, WHITE);
            g.fill(x + 11, y + 5, x + 13, y + 6, WHITE);
            g.fill(x + 2, y + 6, x + 3, y + 9, WHITE);
            g.fill(x + 13, y + 6, x + 14, y + 9, WHITE);
            g.fill(x + 3, y + 9, x + 5, y + 10, WHITE);
            g.fill(x + 11, y + 9, x + 13, y + 10, WHITE);
            g.fill(x + 5, y + 10, x + 11, y + 11, WHITE);
            g.fill(x + 6, y + 5, x + 10, y + 10, WHITE);
        } else {
            g.fill(x + 2, y + 6, x + 3, y + 7, WHITE);
            g.fill(x + 3, y + 7, x + 5, y + 8, WHITE);
            g.fill(x + 5, y + 8, x + 11, y + 9, WHITE);
            g.fill(x + 11, y + 7, x + 13, y + 8, WHITE);
            g.fill(x + 13, y + 6, x + 14, y + 7, WHITE);
            g.fill(x + 4, y + 9, x + 5, y + 11, WHITE);
            g.fill(x + 7, y + 9, x + 8, y + 12, WHITE);
            g.fill(x + 10, y + 9, x + 11, y + 11, WHITE);
        }
    }

    private static void drawTrash(GuiGraphics g, int x, int y) {
        g.fill(x + 6, y + 2, x + 10, y + 3, WHITE);
        g.fill(x + 3, y + 3, x + 13, y + 5, WHITE);
        g.fill(x + 4, y + 6, x + 12, y + 14, WHITE);
        g.fill(x + 6, y + 7, x + 7, y + 13, 0xFFCC2222);
        g.fill(x + 9, y + 7, x + 10, y + 13, 0xFFCC2222);
    }

    private static void diamond(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = r - Math.abs(dy);
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent paprika$e, boolean paprika$dbl) {
        double mouseX = paprika$e.x(), mouseY = paprika$e.y();
        int button = paprika$e.button();
        if (button == 0) {
            for (int i = 0; i < 2; i++) {
                int tx = px + GAP + i * (tabW() + GAP);
                if (inside(mouseX, mouseY, tx, tabY(), tabW(), TAB_H)) {
                    if (listTab != (i == 1)) {
                        listTab = i == 1;
                        scroll = 0;
                        rebuildWidgets();
                    }
                    click();
                    return true;
                }
            }
            if (!listTab) {
                for (int i = 0; i < COLORS.length; i++) {
                    if (inside(mouseX, mouseY, swatchX(i), swatchY(i), SWATCH, SWATCH)) {
                        selectedColor = COLORS[i];
                        click();
                        return true;
                    }
                }
                if (inside(mouseX, mouseY, createX(), createY(), 100, 18)) {
                    create();
                    return true;
                }
            } else {
                List<Markers.Marker> markers = Markers.current();
                int top = contentTop() - 4, bottom = py + PANEL_H - 8;
                for (int i = 0; i < markers.size(); i++) {
                    int ry = top + i * (ROW_H + 3) - scroll;
                    int ex = px + PANEL_W - GAP - 40;
                    if (inside(mouseX, mouseY, ex, ry + 2, 16, 16) && mouseY >= top && mouseY < bottom) {
                        Markers.toggleHidden(markers.get(i).name());
                        Config.save();
                        click();
                        return true;
                    }
                    int bx = px + PANEL_W - GAP - 20, by = ry + 2;
                    if (inside(mouseX, mouseY, bx, by, 16, 16) && mouseY >= top && mouseY < bottom) {
                        Markers.remove(markers.get(i).name());
                        Config.save();
                        click();
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(paprika$e, paprika$dbl);
    }

    private void create() {
        String n = name.getValue().trim().replace(' ', '_');
        if (n.isEmpty()) {
            message = "Give the marker a name first";
            messageColor = 0xFFFF5555;
            return;
        }
        int x, y, z;
        try {
            x = Integer.parseInt(xBox.getValue());
            y = Integer.parseInt(yBox.getValue());
            z = Integer.parseInt(zBox.getValue());
        } catch (NumberFormatException e) {
            message = "The position has to be 3 numbers";
            messageColor = 0xFFFF5555;
            return;
        }
        Markers.put(new Markers.Marker(n, Areas.currentDim(), x + 0.5, y, z + 0.5, selectedColor));
        Config.save();
        click();
        message = "Created '" + n + "' - see it in the List tab";
        messageColor = 0xFF55FF55;
        name.setValue("");
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double delta) {
        if (listTab) {
            scroll -= (int) (delta * (ROW_H + 3));
            clampScroll(Markers.current().size());
        }
        return true;
    }

    private void clampScroll(int count) {
        int visible = (py + PANEL_H - 8) - (contentTop() - 4);
        int max = Math.max(0, count * (ROW_H + 3) - visible);
        scroll = Math.max(0, Math.min(scroll, max));
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent paprika$k) {
        int keyCode = paprika$k.key(), scanCode = paprika$k.scancode(), modifiers = paprika$k.modifiers();

        if (!listTab && (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER || keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_KP_ENTER)) {
            create();
            return true;
        }

        boolean typing = getFocused() instanceof EditBox box && box.isFocused();
        if (!typing && com.paprika.PaprikaClient.markerKey != null && com.paprika.PaprikaClient.markerKey.matches(paprika$k)) {
            onClose();
            return true;
        }
        return super.keyPressed(paprika$k);
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private void click() {
        if (minecraft != null) {
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
        }
    }
}
