package com.paprika.module.modules;

import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.function.Predicate;

final class KillAura {
    public static final String OBVIOUS = "Obvious", LEGIT = "Legit";
    private static final int HOLD_TICKS = 6;

    private static float faceYaw, facePitch;
    private static int faceTicks;

    private KillAura() {}

    static boolean facing() {
        return faceTicks > 0;
    }

    static float faceYaw() { return faceYaw; }
    static float facePitch() { return facePitch; }

    static void keepFacing() {
        Minecraft mc = Minecraft.getInstance();
        if (faceTicks <= 0 || mc.player == null) return;
        faceTicks--;
        mc.player.yHeadRot = faceYaw;
        mc.player.yBodyRot = faceYaw;
        if (mc.getConnection() != null) {
            mc.getConnection().send(new ServerboundMovePlayerPacket.Rot(faceYaw, facePitch, mc.player.onGround(), false));
        }
    }

    static void tick(Predicate<LivingEntity> isTarget, double reach, boolean legit, RandomDelay delay, double maxDelayMs) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (mc.screen != null || mc.player.isUsingItem() || mc.player.isSpectator()) return;

        Vec3 eye = mc.player.getEyePosition();
        LivingEntity best = null;
        double bestDist = reach * reach;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity living) || e == mc.player) continue;
            if (!living.isAlive() || living.getHealth() <= 0 || !isTarget.test(living)) continue;
            if (legit && !mc.player.hasLineOfSight(living)) continue;
            double d = distanceToBox(eye, living.getBoundingBox());
            if (d <= bestDist) {
                bestDist = d;
                best = living;
            }
        }
        if (best == null) return;

        if (legit) {
            Vec3 aim = closestPoint(eye, best.getBoundingBox());
            double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
            faceYaw = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90.0F;
            facePitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * Mth.RAD_TO_DEG);
            faceTicks = HOLD_TICKS;
        }

        if (mc.player.getAttackStrengthScale(0.0F) < 1.0F) {
            delay.reset();
            return;
        }
        if (!delay.passed(maxDelayMs)) return;

        AttackClick.request(best);
    }

    private static double distanceToBox(Vec3 p, AABB box) {
        Vec3 c = closestPoint(p, box);
        return p.distanceToSqr(c);
    }

    private static Vec3 closestPoint(Vec3 p, AABB box) {
        return new Vec3(Mth.clamp(p.x, box.minX, box.maxX), Mth.clamp(p.y, box.minY, box.maxY), Mth.clamp(p.z, box.minZ, box.maxZ));
    }
}
