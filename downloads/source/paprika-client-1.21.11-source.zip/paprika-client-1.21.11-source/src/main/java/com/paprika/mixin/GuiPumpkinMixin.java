package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.NoPumpkinModule;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public abstract class GuiPumpkinMixin {
    @Inject(method = "renderTextureOverlay", at = @At("HEAD"), cancellable = true)
    private void paprika$noPumpkin(GuiGraphics graphics, Identifier texture, float alpha, CallbackInfo ci) {
        if (ModuleManager.isOn(NoPumpkinModule.class) && texture.getPath().contains("pumpkinblur")) ci.cancel();
    }
}
