package com.paprika.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import com.paprika.render.MarkerRenderer;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.LevelRenderer;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererCaptureMixin {
    @Inject(method = "renderLevel", at = @At("HEAD"))
    private void paprika$capture(GraphicsResourceAllocator allocator, DeltaTracker tracker, boolean outline, Camera camera,
                                 Matrix4f view, Matrix4f projection, Matrix4f cullProjection, GpuBufferSlice fog,
                                 Vector4f fogColor, boolean sky, CallbackInfo ci) {
        MarkerRenderer.capture(view, projection, camera.position());
    }
}
