package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class AutoEatModule extends Module {
    public final NumberSetting startAt = number("Start at", "Hunger points (out of 20) where it starts eating - you can't sprint at 6", 6, 1, 19, 1, " hunger");
    public final NumberSetting stopAt = number("Stop at", "Hunger points where it stops eating", 18, 2, 20, 1, " hunger");

    private boolean eating;
    private int previousSlot = -1;

    public AutoEatModule() {
        super("AutoEat", "Eats automatically when you get too hungry to sprint", Category.PLAYER);
    }

    @Override
    protected void onDisable() {
        stop();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.player.isCreative() || mc.player.isSpectator()) return;
        int food = mc.player.getFoodData().getFoodLevel();

        if (mc.screen != null) {
            if (eating) mc.options.keyUse.setDown(false);
            return;
        }

        if (!eating) {
            if (food > startAt.getInt()) return;
            int slot = foodSlot();
            if (slot < 0) return;
            previousSlot = mc.player.getInventory().getSelectedSlot();
            mc.player.getInventory().setSelectedSlot(slot);
            eating = true;
        }

        if (food >= stopAt.getInt() || foodSlot() < 0) {
            stop();
            return;
        }
        if (!isGoodFood(mc.player.getMainHandItem())) mc.player.getInventory().setSelectedSlot(foodSlot());
        mc.options.keyUse.setDown(true);
    }

    private void stop() {
        if (!eating) return;
        eating = false;
        mc.options.keyUse.setDown(false);
        if (mc.player != null && previousSlot >= 0) mc.player.getInventory().setSelectedSlot(previousSlot);
        previousSlot = -1;
    }

    private int foodSlot() {
        for (int i = 0; i < 9; i++) {
            if (isGoodFood(mc.player.getInventory().getItem(i))) return i;
        }
        return -1;
    }

    static boolean isGoodFood(ItemStack stack) {
        if (stack.isEmpty() || !stack.has(net.minecraft.core.component.DataComponents.FOOD)) return false;
        return !(stack.is(Items.ROTTEN_FLESH) || stack.is(Items.SPIDER_EYE) || stack.is(Items.POISONOUS_POTATO)
                || stack.is(Items.PUFFERFISH) || stack.is(Items.SUSPICIOUS_STEW) || stack.is(Items.CHORUS_FRUIT));
    }
}
