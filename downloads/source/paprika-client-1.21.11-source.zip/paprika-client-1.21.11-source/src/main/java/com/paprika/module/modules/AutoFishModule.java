package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.mixin.FishingHookAccessor;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class AutoFishModule extends Module {
    public final NumberSetting radius = number("Water range", "How far it looks for water", 8, 3, 16, 1, " blocks");

    private BlockPos water;
    private int cooldown;
    private int castTicks;
    private int dryTicks;
    private boolean warned;

    public AutoFishModule() {
        super("AutoFish", "Fishes automatically when you're near water", Category.UTILITY);
    }

    @Override
    protected void onDisable() {
        water = null;
        warned = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;

        int rod = rodSlot();
        if (rod < 0) {
            warn("You need a fishing rod in your hotbar");
            return;
        }

        FishingHook hook = mc.player.fishing;
        if (hook == null) {
            if (cooldown > 0) {
                cooldown--;
                return;
            }
            if (water == null || !isFishable(water)) water = findWater();
            if (water == null) {
                warn("No water nearby to fish in");
                return;
            }
            warned = false;
            mc.player.getInventory().setSelectedSlot(rod);
            aimAt(water);
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            mc.player.swing(InteractionHand.MAIN_HAND);
            castTicks = 0;
            dryTicks = 0;
            cooldown = 10;
            return;
        }

        castTicks++;
        boolean bite = ((FishingHookAccessor) hook).paprika$isBiting();

        BlockPos at = hook.blockPosition();
        boolean wet = hook.isInWater() || mc.level.getFluidState(at).is(FluidTags.WATER)
                || mc.level.getFluidState(at.below()).is(FluidTags.WATER);
        dryTicks = wet ? 0 : dryTicks + 1;
        boolean stuck = castTicks > 60 && dryTicks > 40;
        if (bite || stuck || castTicks > 1800) {
            mc.player.getInventory().setSelectedSlot(rod);
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            mc.player.swing(InteractionHand.MAIN_HAND);
            if (stuck) water = null;
            cooldown = 15;
        }
    }

    private void warn(String text) {
        if (warned) return;
        warned = true;
        mc.player.displayClientMessage(Component.literal("[AutoFish] ").withStyle(ChatFormatting.RED)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE)), false);
    }

    private int rodSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getItem(i).getItem() instanceof FishingRodItem) return i;
        }
        return -1;
    }

    private boolean isFishable(BlockPos p) {
        return mc.level.getFluidState(p).is(FluidTags.WATER) && mc.level.getBlockState(p.above()).isAir();
    }

    private BlockPos findWater() {
        Vec3 eye = mc.player.getEyePosition();
        BlockPos me = mc.player.blockPosition();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        int r = radius.getInt();
        for (BlockPos p : BlockPos.betweenClosed(me.offset(-r, -5, -r), me.offset(r, 2, r))) {
            if (!isFishable(p)) continue;
            Vec3 top = new Vec3(p.getX() + 0.5, p.getY() + 0.9, p.getZ() + 0.5);
            double d = eye.distanceTo(top);
            if (d < 3 || d >= bestDist) continue;
            BlockHitResult hit = mc.level.clip(new ClipContext(eye, top, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
            if (hit.getType() != HitResult.Type.MISS) continue;
            bestDist = d;
            best = p.immutable();
        }
        return best;
    }

    private void aimAt(BlockPos target) {
        Vec3 eye = mc.player.getEyePosition();
        double dx = target.getX() + 0.5 - eye.x, dz = target.getZ() + 0.5 - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        double surface = target.getY() + 0.9 - eye.y;
        float yaw = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90.0F;

        float bestPitch = 30.0F;
        double bestError = Double.MAX_VALUE;
        for (float pitch = -40.0F; pitch <= 70.0F; pitch += 1.0F) {
            double err = Math.abs(landingDistance(pitch, surface) - horizontal);
            if (err < bestError) {
                bestError = err;
                bestPitch = pitch;
            }
        }
        mc.player.setYRot(yaw);
        mc.player.setYHeadRot(yaw);
        mc.player.setXRot(bestPitch);
    }

    private static double landingDistance(float pitch, double surface) {
        float j = -Mth.cos(-pitch * Mth.DEG_TO_RAD);
        float k = Mth.sin(-pitch * Mth.DEG_TO_RAD);
        double vy = Mth.clamp(-(k / j), -5.0F, 5.0F);
        double len = Math.sqrt(1 + vy * vy);
        double scale = 0.6 / len + 0.5;
        double vh = scale, v = vy * scale;
        double x = 0, y = 0;
        for (int t = 0; t < 200; t++) {
            x += vh;
            y += v;
            if (y <= surface && v < 0) return x;
            vh *= 0.92;
            v = v * 0.92 - 0.03;
        }
        return x;
    }
}
