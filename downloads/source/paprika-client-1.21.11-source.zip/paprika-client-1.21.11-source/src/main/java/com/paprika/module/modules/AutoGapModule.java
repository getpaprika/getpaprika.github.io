package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.NumberSetting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

public class AutoGapModule extends Module {
    public final NumberSetting health = number("Health", "Eat when your health is this low or lower (20 = full, 2 = one heart)", 10, 2, 19, 1, " hp");
    public final BoolSetting enchantedFirst = bool("Enchanted first", "Eat enchanted golden apples before normal ones", true);

    private boolean eating;
    private int slot, before, ticks, cooldown;

    public AutoGapModule() {
        super("AutoGap", "Eats a golden apple (enchanted too) when your health is low", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        if (eating) finish();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.gameMode == null) {
            eating = false;
            return;
        }
        if (eating) {
            ticks++;
            boolean stillApple = isGap(mc.player.getInventory().getItem(slot).getItem());
            if (!stillApple || ticks > 45 || (ticks > 3 && !mc.player.isUsingItem())) {
                finish();
                return;
            }
            mc.player.getInventory().setSelectedSlot(slot);
            mc.options.keyUse.setDown(true);
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (mc.screen != null || mc.player.isUsingItem() || mc.player.getHealth() > health.get()) return;
        int s = findApple();
        if (s < 0) return;
        slot = s;
        before = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(slot);
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
        mc.options.keyUse.setDown(true);
        eating = true;
        ticks = 0;
    }

    private void finish() {
        mc.options.keyUse.setDown(false);
        if (mc.player != null) mc.player.getInventory().setSelectedSlot(before);
        eating = false;
        cooldown = 10;
    }

    private static boolean isGap(Item item) {
        return item == Items.GOLDEN_APPLE || item == Items.ENCHANTED_GOLDEN_APPLE;
    }

    private int findApple() {
        Item first = enchantedFirst.get() ? Items.ENCHANTED_GOLDEN_APPLE : Items.GOLDEN_APPLE;
        Item second = enchantedFirst.get() ? Items.GOLDEN_APPLE : Items.ENCHANTED_GOLDEN_APPLE;
        for (Item want : new Item[] {first, second}) {
            for (int i = 0; i < 9; i++) if (mc.player.getInventory().getItem(i).is(want)) return i;
        }
        return -1;
    }
}
