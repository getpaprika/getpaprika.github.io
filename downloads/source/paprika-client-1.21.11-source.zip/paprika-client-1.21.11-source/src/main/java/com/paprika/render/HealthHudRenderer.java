package com.paprika.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.paprika.module.ModuleManager;
import com.paprika.module.modules.HealthHudModule;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.Locale;

public final class HealthHudRenderer {
    private HealthHudRenderer() {}

    public static void render(WorldRenderContext ctx) {
        if (!ModuleManager.isOn(HealthHudModule.class)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.options.hideGui) return;

        float pt = RenderUtil.partialTick(ctx);
        Vec3 cam = Minecraft.getInstance().gameRenderer.getMainCamera().position();
        PoseStack pose = RenderUtil.worldPose(null);
        RenderUtil.beginWorld();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        Font font = mc.font;
        boolean any = false;

        for (Player p : mc.level.players()) {
            if (com.paprika.module.modules.BlinkModule.isClone(p)) continue;
            if (p == mc.player || !p.isAlive() || p.isInvisible() || p.isSpectator()) continue;
            if (p.distanceToSqr(cam) > 64 * 64) continue;

            float hp = p.getHealth() + p.getAbsorptionAmount();
            float ratio = Mth.clamp(p.getHealth() / Math.max(1.0F, p.getMaxHealth()), 0.0F, 1.0F);
            int color = ratio > 0.66F ? 0x55FF55 : ratio > 0.33F ? 0xFFFF55 : 0xFF5555;
            String text = (hp == Math.floor(hp) ? String.valueOf((int) hp) : String.format(Locale.ROOT, "%.1f", hp)) + "❤";

            double x = Mth.lerp(pt, p.xo, p.getX()) - cam.x;
            double y = Mth.lerp(pt, p.yo, p.getY()) - cam.y + p.getBbHeight() + 0.5;
            double z = Mth.lerp(pt, p.zo, p.getZ()) - cam.z;

            pose.pushPose();
            pose.translate(x, y, z);
            pose.mulPose(Minecraft.getInstance().gameRenderer.getMainCamera().rotation());
            pose.scale(-0.025F, -0.025F, 0.025F);
            Matrix4f matrix = pose.last().pose();
            float tx = font.width(p.getDisplayName()) / 2.0F + 4.0F;
            if (!p.isDiscrete()) {
                font.drawInBatch(text, tx, 0, 0x20000000 | color, false, matrix, buffers,
                        Font.DisplayMode.SEE_THROUGH, 0x20000000, LightTexture.FULL_BRIGHT);
            }
            font.drawInBatch(text, tx, 0, 0xFF000000 | color, false, matrix, buffers,
                    Font.DisplayMode.NORMAL, 0, LightTexture.FULL_BRIGHT);
            pose.popPose();
            any = true;
        }
        if (any) buffers.endBatch();
        RenderUtil.endWorld();
    }
}
