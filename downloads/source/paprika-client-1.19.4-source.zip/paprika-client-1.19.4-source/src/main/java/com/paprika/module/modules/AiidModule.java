package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.monster.Enemy;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AiidModule extends Module {
    public final NumberSetting range = number("Range", "How far away mobs are watched", 32, 8, 64, 1, " blocks");
    private static final double MIN_APPROACH = 0.02;
    private static final int MEMORY_TICKS = 10;

    private static final int SAFE_COLOR = 0xFF55FF55;
    private static final int DANGER_COLOR = 0xFFFF8800;

    private final Map<Integer, Integer> lastApproach = new HashMap<>();
    private int ticks;

    private Mob danger;
    private double dangerDistance;
    private int others;

    public AiidModule() {
        super("AIID", "Am I in danger? Warns when a hostile/neutral mob is coming at you", Category.UTILITY);
    }

    @Override
    protected void onDisable() {
        lastApproach.clear();
        danger = null;
    }

    @Override
    public void onTick() {
        ticks++;
        danger = null;
        others = 0;
        if (mc.player == null || mc.level == null) return;

        double best = Double.MAX_VALUE;
        int count = 0;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Mob mob) || !mob.isAlive()) continue;
            if (!(mob instanceof Enemy || mob instanceof NeutralMob)) continue;

            double dist = mob.distanceTo(mc.player);
            if (dist > range.get()) continue;

            double dx = mc.player.getX() - mob.getX();
            double dy = mc.player.getY() - mob.getY();
            double dz = mc.player.getZ() - mob.getZ();
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 0.001) continue;
            double vx = mob.getX() - mob.xo;
            double vy = mob.getY() - mob.yo;
            double vz = mob.getZ() - mob.zo;
            double towards = (vx * dx + vy * dy + vz * dz) / len;

            if (towards > MIN_APPROACH) lastApproach.put(mob.getId(), ticks);

            Integer last = lastApproach.get(mob.getId());
            if (last != null && ticks - last <= MEMORY_TICKS) {
                count++;
                if (dist < best) {
                    best = dist;
                    danger = mob;
                }
            }
        }

        dangerDistance = best;
        others = Math.max(0, count - 1);

        if (ticks % 200 == 0) {
            lastApproach.values().removeIf(t -> ticks - t > MEMORY_TICKS);
        }
    }

    @Override
    public int onRender(GuiGraphics graphics, int x, int y) {
        String text;
        int color;
        if (danger == null) {
            text = "AIID: Safe";
            color = SAFE_COLOR;
        } else {
            text = "AIID: " + danger.getName().getString() + " coming! "
                    + String.format(Locale.ROOT, "%.1f", dangerDistance) + "m";
            if (others > 0) text += " (+" + others + " more)";
            color = DANGER_COLOR;
        }
        graphics.drawString(mc.font, text, x, y, color, true);
        return mc.font.lineHeight + 2;
    }
}
