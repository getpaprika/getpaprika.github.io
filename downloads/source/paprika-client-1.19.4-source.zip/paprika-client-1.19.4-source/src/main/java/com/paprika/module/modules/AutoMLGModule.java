package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class AutoMLGModule extends Module {
    private static final float MIN_FALL = 3.5F;
    private static final double BUCKET_REACH = 5.0;
    private static final int GIVE_UP_TICKS = 60;

    private boolean placed;
    private int ticks;
    private int landedTicks;
    private int prevSlot;
    private float prevYaw, prevPitch;
    private InteractionHand hand;

    public AutoMLGModule() {
        super("AutoMLG", "Places water under you before you hit the ground, then picks it up", Category.UTILITY);
    }

    @Override
    protected void onDisable() {
        if (placed) restore();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.gameMode == null) {
            placed = false;
            return;
        }
        if (placed) {
            afterPlacing();
            return;
        }
        if (shouldClutch()) clutch();
    }

    private boolean shouldClutch() {
        if (mc.screen != null) return false;
        if (mc.player.isCreative() || mc.player.isSpectator()) return false;
        if (mc.player.isOnGround() || mc.player.isInWater() || mc.player.isFallFlying()
                || mc.player.getAbilities().flying || mc.player.isPassenger()) return false;
        if (mc.level.dimensionType().ultraWarm()) return false;
        if (mc.player.fallDistance < MIN_FALL) return false;
        if (mc.player.getDeltaMovement().y > -0.3) return false;
        if (findBucket() == null) return false;

        Vec3 feet = mc.player.position();
        BlockHitResult hit = mc.level.clip(new ClipContext(feet, feet.subtract(0, 20, 0),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, mc.player));
        if (hit.getType() != HitResult.Type.BLOCK) return false;
        if (!mc.level.getFluidState(hit.getBlockPos()).isEmpty()) return false;

        double groundDist = feet.y - hit.getLocation().y;
        double eyeToGround = groundDist + mc.player.getEyeHeight();

        return eyeToGround <= BUCKET_REACH - 0.3;
    }

    private void clutch() {
        hand = findBucket();
        prevSlot = mc.player.getInventory().selected;
        prevYaw = mc.player.getYRot();
        prevPitch = mc.player.getXRot();

        if (hand == InteractionHand.MAIN_HAND) {
            mc.player.getInventory().selected = bucketSlot();
        }
        mc.player.setXRot(90.0F);

        mc.gameMode.useItem(mc.player, hand);
        mc.player.swing(hand);

        placed = true;
        ticks = 0;
        landedTicks = 0;
    }

    private void afterPlacing() {
        ticks++;
        mc.player.setXRot(90.0F);

        boolean landed = mc.player.isOnGround() || mc.player.isInWater();
        if (landed) landedTicks++;

        if (landedTicks >= 2) {
            if (mc.player.getItemInHand(hand).is(Items.BUCKET)) {
                mc.gameMode.useItem(mc.player, hand);
                mc.player.swing(hand);
            }
            restore();
            return;
        }
        if (ticks > GIVE_UP_TICKS) restore();
    }

    private void restore() {
        placed = false;
        if (mc.player == null) return;
        mc.player.getInventory().selected = prevSlot;
        mc.player.setYRot(prevYaw);
        mc.player.setXRot(prevPitch);
    }

    private InteractionHand findBucket() {
        if (bucketSlot() >= 0) return InteractionHand.MAIN_HAND;
        if (mc.player.getOffhandItem().is(Items.WATER_BUCKET)) return InteractionHand.OFF_HAND;
        return null;
    }

    private int bucketSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getItem(i).is(Items.WATER_BUCKET)) return i;
        }
        return -1;
    }
}
