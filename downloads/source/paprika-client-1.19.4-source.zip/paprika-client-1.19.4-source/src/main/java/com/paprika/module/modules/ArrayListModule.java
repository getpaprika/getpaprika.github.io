package com.paprika.module.modules;

import com.paprika.gui.Theme;
import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ArrayListModule extends Module {
    public ArrayListModule() {
        super("ArrayList", "Shows the mods that are on in the top right", Category.RENDER);
    }

    @Override
    public int onRender(GuiGraphics g, int x, int y) {
        if (mc.player == null) return 0;
        List<String> names = new ArrayList<>();
        for (Module m : ModuleManager.getModules()) if (m.isEnabled() && m != this) names.add(m.getName());
        names.sort(Comparator.comparingInt((String n) -> -mc.font.width(n)).thenComparing(n -> n));

        Theme theme = Theme.current();
        int width = mc.getWindow().getGuiScaledWidth();
        int line = mc.font.lineHeight + 2;
        int ty = mc.player.getActiveEffects().isEmpty() ? 2 : 52;
        for (String name : names) {
            int w = mc.font.width(name);
            int tx = width - w - 5;
            g.fill(tx - 2, ty - 1, width, ty + line - 1, 0x60000000);
            g.fill(width - 2, ty - 1, width, ty + line - 1, theme.accentArgb(0xFF));
            g.drawString(mc.font, name, tx, ty, theme.accentArgb(0xFF), true);
            ty += line;
        }
        return 0;
    }

    @Override
    public int onRenderPreview(GuiGraphics g, int x, int y) {
        List<String> names = new ArrayList<>();
        for (Module m : ModuleManager.getModules()) if (m.isEnabled() && m != this) names.add(m.getName());
        if (names.isEmpty()) names.addAll(List.of("KillAura", "Fullbright", "ESPP"));
        names.sort(Comparator.comparingInt((String n) -> -mc.font.width(n)).thenComparing(n -> n));
        Theme theme = Theme.current();
        int width = mc.getWindow().getGuiScaledWidth();
        int line = mc.font.lineHeight + 2;
        int ty = mc.player == null || mc.player.getActiveEffects().isEmpty() ? 2 : 52;
        for (String name : names) {
            int w = mc.font.width(name);
            int tx = width - w - 5;
            g.fill(tx - 2, ty - 1, width, ty + line - 1, 0x60000000);
            g.fill(width - 2, ty - 1, width, ty + line - 1, theme.accentArgb(0xFF));
            g.drawString(mc.font, name, tx, ty, theme.accentArgb(0xFF), true);
            ty += line;
        }
        return 0;
    }
}
