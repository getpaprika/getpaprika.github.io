package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;

public class AutoCritsModule extends Module {
    private static boolean stoppedSprint;

    public AutoCritsModule() {
        super("AutoCrits", "Every sword/axe hit becomes a critical hit", Category.COMBAT);
    }

    public static void beforeAttack(Entity target) {
        stoppedSprint = false;
        if (mc.player == null || mc.getConnection() == null) return;
        if (!(target instanceof LivingEntity)) return;

        Item held = mc.player.getMainHandItem().getItem();
        if (!(held instanceof SwordItem || held instanceof AxeItem)) return;

        if (!mc.player.isOnGround() || mc.player.isInWater() || mc.player.isInLava()
                || mc.player.onClimbable() || mc.player.isPassenger()
                || mc.player.hasEffect(MobEffects.BLINDNESS)) return;

        if (mc.player.isSprinting()) {
            mc.getConnection().send(new ServerboundPlayerCommandPacket(mc.player,
                    ServerboundPlayerCommandPacket.Action.STOP_SPRINTING));
            stoppedSprint = true;
        }

        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        mc.getConnection().send(new ServerboundMovePlayerPacket.Pos(x, y + 0.0625, z, false));
        mc.getConnection().send(new ServerboundMovePlayerPacket.Pos(x, y, z, false));
    }

    public static void afterAttack() {
        if (stoppedSprint && mc.player != null && mc.getConnection() != null) {
            mc.getConnection().send(new ServerboundPlayerCommandPacket(mc.player,
                    ServerboundPlayerCommandPacket.Action.START_SPRINTING));
        }
        stoppedSprint = false;
    }
}
