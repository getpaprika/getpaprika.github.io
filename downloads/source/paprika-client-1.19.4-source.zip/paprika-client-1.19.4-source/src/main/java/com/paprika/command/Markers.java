package com.paprika.command;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class Markers {
    public record Marker(String name, String dim, double x, double y, double z, int color) {}

    private static final List<Marker> MARKERS = new ArrayList<>();

    private static final Set<String> HIDDEN = new HashSet<>();

    private Markers() {}

    public static void put(Marker marker) {
        MARKERS.removeIf(m -> m.name().equalsIgnoreCase(marker.name()));
        HIDDEN.remove(key(marker.name()));
        MARKERS.add(marker);
    }

    public static List<Marker> all() {
        return new ArrayList<>(MARKERS);
    }

    public static boolean remove(String name) {
        HIDDEN.remove(key(name));
        return MARKERS.removeIf(m -> m.name().equalsIgnoreCase(name));
    }

    public static void clear() { MARKERS.clear(); HIDDEN.clear(); }

    private static String key(String name) { return name.toLowerCase(Locale.ROOT); }

    public static boolean isHidden(Marker m) { return HIDDEN.contains(key(m.name())); }

    public static void toggleHidden(String name) {
        String k = key(name);
        if (!HIDDEN.remove(k)) HIDDEN.add(k);
    }

    public static List<Marker> current() {
        String dim = Areas.currentDim();
        List<Marker> list = new ArrayList<>();
        for (Marker m : MARKERS) if (m.dim().equals(dim)) list.add(m);
        return list;
    }

    public static JsonArray save() {
        JsonArray arr = new JsonArray();
        for (Marker m : MARKERS) {
            JsonObject o = new JsonObject();
            o.addProperty("name", m.name());
            o.addProperty("dim", m.dim());
            o.addProperty("x", m.x()); o.addProperty("y", m.y()); o.addProperty("z", m.z());
            o.addProperty("color", m.color());
            if (isHidden(m)) o.addProperty("hidden", true);
            arr.add(o);
        }
        return arr;
    }

    public static void load(JsonArray arr) {
        MARKERS.clear();
        HIDDEN.clear();
        for (JsonElement e : arr) {
            JsonObject o = e.getAsJsonObject();
            if (o.has("hidden") && o.get("hidden").getAsBoolean()) HIDDEN.add(key(o.get("name").getAsString()));
            MARKERS.add(new Marker(o.get("name").getAsString(), o.get("dim").getAsString(),
                    o.get("x").getAsDouble(), o.get("y").getAsDouble(), o.get("z").getAsDouble(),
                    o.get("color").getAsInt()));
        }
    }
}
