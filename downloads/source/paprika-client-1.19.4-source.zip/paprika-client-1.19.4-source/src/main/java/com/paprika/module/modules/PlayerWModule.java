package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.ChatFormatting;
import com.paprika.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class PlayerWModule extends Module {
    public final NumberSetting range = number("Range", "How close a player has to be to warn you", 200, 16, 512, 8, " blocks");
    private static final int RED = 0xFFFF3333;

    private final Set<UUID> inRange = new HashSet<>();
    private final List<Player> nearby = new ArrayList<>();

    public PlayerWModule() {
        super("PlayerW", "Warns you when a player is within 200 blocks", Category.UTILITY);
    }

    @Override
    protected void onDisable() {
        inRange.clear();
        nearby.clear();
    }

    @Override
    public void onTick() {
        nearby.clear();
        if (mc.player == null || mc.level == null) {
            inRange.clear();
            return;
        }

        Set<UUID> now = new HashSet<>();
        boolean newPlayer = false;
        for (Player p : mc.level.players()) {
            if (com.paprika.module.modules.BlinkModule.isClone(p)) continue;
            if (p == mc.player || p.isSpectator() || com.paprika.command.Friends.is(p)) continue;
            if (p.distanceTo(mc.player) > range.get()) continue;
            now.add(p.getUUID());
            nearby.add(p);

            if (!inRange.contains(p.getUUID())) {
                newPlayer = true;

                mc.gui.setTimes(5, 40, 10);
                mc.gui.setSubtitle(Component.literal("is near you.").withStyle(ChatFormatting.RED));
                mc.gui.setTitle(Component.literal(p.getName().getString())
                        .withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
            }
        }
        if (newPlayer) {
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.BEACON_DEACTIVATE, 1.0F));
        }
        inRange.clear();
        inRange.addAll(now);

        nearby.sort(Comparator.comparingDouble(p -> p.distanceTo(mc.player)));
    }

    public int topLines() {
        if (!isEnabled() || mc.player == null) return 0;
        int n = 0;
        for (Player p : nearby) if (p.isAlive()) n++;
        return n;
    }

    @Override
    public int onRender(GuiGraphics graphics, int x, int y) {
        if (mc.player == null || nearby.isEmpty()) return 0;
        int centerX = mc.getWindow().getGuiScaledWidth() / 2;
        int lineY = 4;
        for (Player p : nearby) {
            if (!p.isAlive()) continue;
            String text = p.getName().getString() + " - "
                    + String.format(Locale.ROOT, "%.0f", p.distanceTo(mc.player)) + "m";
            graphics.drawCenteredString(mc.font, text, centerX, lineY, RED);
            lineY += mc.font.lineHeight + 1;
        }
        return 0;
    }

    @Override
    public int onRenderPreview(GuiGraphics graphics, int x, int y) {
        if (mc.player != null && !nearby.isEmpty()) return onRender(graphics, x, y);
        int centerX = mc.getWindow().getGuiScaledWidth() / 2;
        graphics.drawCenteredString(mc.font, "Steve - 37m", centerX, 4, RED);
        graphics.drawCenteredString(mc.font, "Alex - 112m", centerX, 4 + mc.font.lineHeight + 1, RED);
        return 0;
    }
}
