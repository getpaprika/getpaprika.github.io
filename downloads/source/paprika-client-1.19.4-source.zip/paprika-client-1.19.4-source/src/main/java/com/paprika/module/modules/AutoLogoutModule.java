package com.paprika.module.modules;

import com.paprika.module.setting.BoolSetting;
import com.paprika.module.setting.NumberSetting;
import com.paprika.Config;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundDisconnectPacket;
import net.minecraft.world.entity.player.Player;

import java.util.Locale;

public class AutoLogoutModule extends Module {
    public final NumberSetting distance = number("Distance", "How close a player can get before you're logged out", 6, 1, 128, 1, " blocks");
    public final BoolSetting turnOff = bool("Turn off after", "Turn AutoLogout off after it logs you out (so you can rejoin)", true);

    public AutoLogoutModule() {
        super("AutoLogout", "Logs you out when a player gets close", Category.UTILITY);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.getConnection() == null) return;
        for (Player p : mc.level.players()) {
            if (com.paprika.module.modules.BlinkModule.isClone(p)) continue;
            if (p == mc.player || p.isSpectator() || com.paprika.command.Friends.is(p)) continue;
            double d = p.distanceTo(mc.player);
            if (d > distance.get()) continue;

            if (turnOff.get()) {
                setEnabled(false);
                Config.save();
            }
            String reason = "[AutoLogout] " + p.getName().getString() + " came within "
                    + String.format(Locale.ROOT, "%.1f", d) + " blocks of you."
                    + (turnOff.get() ? "\nAutoLogout is now off - turn it back on after you rejoin." : "");
            mc.getConnection().handleDisconnect(new ClientboundDisconnectPacket(Component.literal(reason)));
            return;
        }
    }
}
