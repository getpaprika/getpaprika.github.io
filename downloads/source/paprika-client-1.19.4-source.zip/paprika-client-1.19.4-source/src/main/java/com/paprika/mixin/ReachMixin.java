package com.paprika.mixin;

import com.paprika.module.modules.ReachModule;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MultiPlayerGameMode.class)
public abstract class ReachMixin {
    @Inject(method = "getPickRange", at = @At("RETURN"), cancellable = true)
    private void paprika$reach(CallbackInfoReturnable<Float> cir) {
        ReachModule r = ReachModule.active();
        if (r != null) cir.setReturnValue((float) Math.max(cir.getReturnValue(), Math.max(r.block.get(), r.entity.get())));
    }
}
