package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class LavaEspModule extends Module {
    private static final int MAX_SHOWN = 6000;
    private static final Direction[] FACES = {Direction.DOWN, Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};

    public final NumberSetting range = number("Range", "How far around you lava is shown", 32, 8, 64, 1, " blocks");

    public record Lava(BlockPos pos, int faces) {}

    private List<Lava> shown = List.of();
    private int timer;

    public LavaEspModule() {
        super("LavaESP", "Fills lava in see-through orange so you can see it through walls", Category.RENDER);
    }

    public List<Lava> shown() {
        return shown;
    }

    @Override
    protected void onDisable() {
        shown = List.of();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (timer-- > 0) return;
        timer = 10;

        int r = range.getInt();
        BlockPos me = mc.player.blockPosition();
        int minY = Math.max(mc.level.getMinBuildHeight(), me.getY() - r), maxY = Math.min(mc.level.getMaxBuildHeight() - 1, me.getY() + r);
        List<BlockPos> lava = new ArrayList<>();
        int c0x = (me.getX() - r) >> 4, c1x = (me.getX() + r) >> 4, c0z = (me.getZ() - r) >> 4, c1z = (me.getZ() + r) >> 4;
        for (int cx = c0x; cx <= c1x; cx++) {
            for (int cz = c0z; cz <= c1z; cz++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;
                LevelChunkSection[] sections = chunk.getSections();
                for (int s = 0; s < sections.length; s++) {
                    LevelChunkSection section = sections[s];
                    if (section == null || section.hasOnlyAir()) continue;
                    int baseY = SectionPos.sectionToBlockCoord(chunk.getSectionYFromSectionIndex(s));
                    if (baseY + 15 < minY || baseY > maxY) continue;
                    if (!section.maybeHas(st -> st.getFluidState().is(FluidTags.LAVA))) continue;
                    for (int y = 0; y < 16; y++) {
                        int wy = baseY + y;
                        if (wy < minY || wy > maxY) continue;
                        for (int z = 0; z < 16; z++) {
                            for (int x = 0; x < 16; x++) {
                                if (!section.getFluidState(x, y, z).is(FluidTags.LAVA)) continue;
                                BlockPos p = new BlockPos((cx << 4) + x, wy, (cz << 4) + z);
                                if (p.distManhattan(me) > r * 2) continue;
                                lava.add(p);
                            }
                        }
                    }
                }
            }
        }
        lava.sort(Comparator.comparingDouble(p -> p.distSqr(me)));
        if (lava.size() > MAX_SHOWN) lava = lava.subList(0, MAX_SHOWN);

        List<Lava> out = new ArrayList<>(lava.size());
        for (BlockPos p : lava) {
            int faces = 0;
            for (int i = 0; i < 6; i++) {
                if (!mc.level.getFluidState(p.relative(FACES[i])).is(FluidTags.LAVA)) faces |= 1 << i;
            }
            if (faces != 0) out.add(new Lava(p, faces));
        }
        shown = out;
    }
}
