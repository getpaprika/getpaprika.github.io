package com.paprika.mixin;

import com.paprika.module.ModuleManager;
import com.paprika.module.modules.NoPumpkinModule;
import net.minecraft.client.gui.Gui;
import com.paprika.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public abstract class GuiPumpkinMixin {
    @Inject(method = "renderTextureOverlay", at = @At("HEAD"), cancellable = true)
    private void paprika$noPumpkin(com.mojang.blaze3d.vertex.PoseStack graphics, ResourceLocation texture, float alpha, CallbackInfo ci) {
        if (ModuleManager.isOn(NoPumpkinModule.class) && texture.getPath().contains("pumpkinblur")) ci.cancel();
    }
}
