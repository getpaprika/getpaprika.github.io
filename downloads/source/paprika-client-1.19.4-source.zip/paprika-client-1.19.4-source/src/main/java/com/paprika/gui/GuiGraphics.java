package com.paprika.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

public class GuiGraphics {
    private final PoseStack pose;
    private final Minecraft mc = Minecraft.getInstance();

    public GuiGraphics(PoseStack pose) {
        this.pose = pose;
    }

    public PoseStack pose() {
        return pose;
    }

    public void fill(int x1, int y1, int x2, int y2, int color) {
        HudMeasure.add(x1, y1, x2, y2);
        GuiComponent.fill(pose, x1, y1, x2, y2, color);
    }

    public int drawString(Font font, String text, int x, int y, int color) {
        return drawString(font, text, x, y, color, true);
    }

    public int drawString(Font font, String text, int x, int y, int color, boolean shadow) {
        if (text == null) return 0;
        int end = shadow ? font.drawShadow(pose, text, x, y, color) : font.draw(pose, text, x, y, color);
        HudMeasure.add(x, y, end, y + font.lineHeight);
        return end;
    }

    public int drawString(Font font, Component text, int x, int y, int color) {
        return drawString(font, text, x, y, color, true);
    }

    public int drawString(Font font, Component text, int x, int y, int color, boolean shadow) {
        int end = shadow ? font.drawShadow(pose, text, x, y, color) : font.draw(pose, text, x, y, color);
        HudMeasure.add(x, y, end, y + font.lineHeight);
        return end;
    }

    public int drawString(Font font, FormattedCharSequence text, int x, int y, int color) {
        return drawString(font, text, x, y, color, true);
    }

    public int drawString(Font font, FormattedCharSequence text, int x, int y, int color, boolean shadow) {
        int end = shadow ? font.drawShadow(pose, text, x, y, color) : font.draw(pose, text, x, y, color);
        HudMeasure.add(x, y, end, y + font.lineHeight);
        return end;
    }

    public void drawCenteredString(Font font, String text, int x, int y, int color) {
        drawString(font, text, x - font.width(text) / 2, y, color);
    }

    public void drawCenteredString(Font font, Component text, int x, int y, int color) {
        drawString(font, text, x - font.width(text) / 2, y, color);
    }

    public void drawCenteredString(Font font, FormattedCharSequence text, int x, int y, int color) {
        drawString(font, text, x - font.width(text) / 2, y, color);
    }

    public void renderItem(ItemStack stack, int x, int y) {
        HudMeasure.add(x, y, x + 16, y + 16);
        mc.getItemRenderer().renderAndDecorateItem(pose, stack, x, y);
    }

    public void renderItemDecorations(Font font, ItemStack stack, int x, int y) {
        mc.getItemRenderer().renderGuiItemDecorations(pose, font, stack, x, y);
    }

    public void enableScissor(int x1, int y1, int x2, int y2) {
        GuiComponent.enableScissor(x1, y1, x2, y2);
    }

    public void disableScissor() {
        GuiComponent.disableScissor();
    }

    public void renderTooltip(Font font, Component text, int x, int y) {
        if (mc.screen != null) mc.screen.renderTooltip(pose, text, x, y);
    }

    public void setColor(float r, float g, float b, float a) {
        RenderSystem.setShaderColor(r, g, b, a);
    }

    public void flush() {}
}
