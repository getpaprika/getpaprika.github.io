package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.gui.GuiGraphics;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;

public class SpeedometerModule extends Module {
    private static final int SAMPLES = 5;
    private final double[] samples = new double[SAMPLES];
    private int index;
    private Vec3 last;

    public SpeedometerModule() {
        super("Speedometer", "Shows your speed in blocks per second", Category.RENDER);
    }

    @Override
    public void onTick() {
        if (mc.player == null) {
            last = null;
            return;
        }
        Vec3 now = mc.player.position();
        double perTick = last == null ? 0 : Math.sqrt(Math.pow(now.x - last.x, 2) + Math.pow(now.z - last.z, 2));
        if (perTick > 10) perTick = 0;
        samples[index++ % SAMPLES] = perTick * 20;
        last = now;
    }

    @Override
    public int onRender(GuiGraphics graphics, int x, int y) {
        double sum = 0;
        for (double s : samples) sum += s;
        graphics.drawString(mc.font, String.format(Locale.ROOT, "Speed: %.2f b/s", sum / SAMPLES), x, y, 0xFFFFFFFF, true);
        return mc.font.lineHeight + 2;
    }
}
