package com.paprika.gui;

import com.paprika.Config;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class HudEditorScreen extends Screen {
    private static final int GRID = 10;

    private final Supplier<Screen> back;
    private final Map<String, HudRenderer.Rect> rects = new HashMap<>();
    private String dragging;
    private double grabX, grabY;

    public HudEditorScreen(Supplier<Screen> back) {
        super(Component.literal("HUD Editor"));
        this.back = back;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(com.mojang.blaze3d.vertex.PoseStack paprika$ps) {
        GuiGraphics g = new GuiGraphics(paprika$ps);
    }

    private void drawBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        if (minecraft != null && minecraft.level == null) MenuBackground.panorama(partialTick);
    }
    @Override
    public void render(com.mojang.blaze3d.vertex.PoseStack paprika$ps, int mouseX, int mouseY, float partialTick) {
        GuiGraphics g = new GuiGraphics(paprika$ps);
        drawBackground(g, mouseX, mouseY, partialTick);
        Theme theme = Theme.current();

        for (int x = 0; x < width; x += GRID) g.fill(x, 0, x + 1, height, (x / GRID) % 5 == 0 ? 0x30FFFFFF : 0x14FFFFFF);
        for (int y = 0; y < height; y += GRID) g.fill(0, y, width, y + 1, (y / GRID) % 5 == 0 ? 0x30FFFFFF : 0x14FFFFFF);

        HudRenderer.render(g, true);
        rects.clear();
        rects.putAll(HudRenderer.shown());

        int spareY = 30;
        for (HudRenderer.Element el : HudRenderer.elements()) {
            if (rects.containsKey(el.id())) continue;
            String label = el.name() + (el.on() ? "" : " (off)");
            int w = font.width(label) + 8, h = 12;
            float[] pos = HudLayout.get(el.id());
            int x, y;
            if (pos != null) {
                x = Math.max(0, Math.min(width - w, Math.round(pos[0] * width)));
                y = Math.max(0, Math.min(height - h, Math.round(pos[1] * height)));
            } else {
                x = width - w - 6;
                y = spareY;
                spareY += h + 3;
            }
            g.fill(x, y, x + w, y + h, 0x90000000);
            g.drawString(font, label, x + 4, y + 2, el.on() ? 0xFFFFFFFF : 0xFF999999, false);
            rects.put(el.id(), new HudRenderer.Rect(x, y, w, h));
        }

        String hover = dragging != null ? dragging : at(mouseX, mouseY);
        for (Map.Entry<String, HudRenderer.Rect> e : rects.entrySet()) {
            HudRenderer.Rect r = e.getValue();
            boolean hot = e.getKey().equals(hover);
            outline(g, r.x() - 1, r.y() - 1, r.w() + 2, r.h() + 2, hot ? theme.accentArgb(0xFF) : theme.accentArgb(0x70));
            if (hot) g.fill(r.x(), r.y(), r.x() + r.w(), r.y() + r.h(), theme.accentArgb(0x30));
        }
        if (hover != null) {
            HudRenderer.Rect r = rects.get(hover);
            if (r != null) g.drawString(font, hoverLabel(hover), r.x(), r.y() > 11 ? r.y() - 11 : r.y() + r.h() + 2, theme.accentArgb(0xFF), true);
        }
        g.drawCenteredString(font, "Drag to move  |  Right click = normal place  |  ESC = save & exit", width / 2, height - 12, 0xFFDDDDDD);
    }

    private String at(double mx, double my) {
        String found = null;
        for (Map.Entry<String, HudRenderer.Rect> e : rects.entrySet()) if (e.getValue().contains(mx, my)) found = e.getKey();
        return found;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        String id = at(mouseX, mouseY);
        if (id == null) return false;
        if (button == 1) {
            HudLayout.reset(id);
            return true;
        }
        if (button == 0) {
            HudRenderer.Rect r = rects.get(id);
            dragging = id;
            grabX = mouseX - r.x();
            grabY = mouseY - r.y();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging == null) return false;
        HudRenderer.Rect r = rects.get(dragging);
        int w = r == null ? 10 : r.w(), h = r == null ? 10 : r.h();
        double x = Math.max(0, Math.min(width - w, mouseX - grabX));
        double y = Math.max(0, Math.min(height - h, mouseY - grabY));
        HudLayout.set(dragging, (float) (x / width), (float) (y / height));
        return true;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        Config.save();
        if (minecraft != null) minecraft.setScreen(back.get());
    }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private static String hoverLabel(String id) {
        for (HudRenderer.Element el : HudRenderer.elements()) if (el.id().equals(id)) return el.name() + (el.on() ? "" : " (off)");
        return id;
    }
}
