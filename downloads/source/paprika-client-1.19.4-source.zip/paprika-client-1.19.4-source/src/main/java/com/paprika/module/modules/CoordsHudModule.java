package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.gui.GuiGraphics;
import net.minecraft.world.level.Level;

public class CoordsHudModule extends Module {
    public CoordsHudModule() {
        super("CoordsHUD", "Shows your coordinates (and the matching Nether/Overworld ones)", Category.RENDER);
    }

    @Override
    public int onRender(GuiGraphics g, int x, int y) {
        if (mc.player == null || mc.level == null) return 0;
        int px = mc.player.getBlockX(), py = mc.player.getBlockY(), pz = mc.player.getBlockZ();

        String here;
        String other = null;
        if (mc.level.dimension() == Level.OVERWORLD) {
            here = "Overworld";
            other = "In Nether: " + Math.floorDiv(px, 8) + " " + py + " " + Math.floorDiv(pz, 8);
        } else if (mc.level.dimension() == Level.NETHER) {
            here = "Nether";
            other = "In Overworld: " + px * 8 + " " + py + " " + pz * 8;
        } else if (mc.level.dimension() == Level.END) {
            here = "End";
        } else {
            here = "XYZ";
        }

        g.drawString(mc.font, here + ": " + px + " " + py + " " + pz, x, y, 0xFFFFFFFF, true);
        int h = mc.font.lineHeight + 2;
        if (other != null) {
            g.drawString(mc.font, other, x, y + h, 0xFFAAAAAA, true);
            h *= 2;
        }
        return h;
    }

    @Override
    public int onRenderPreview(GuiGraphics g, int x, int y) {
        if (mc.player != null && mc.level != null) return onRender(g, x, y);
        int h = mc.font.lineHeight + 2;
        g.drawString(mc.font, "Overworld: 120 64 -340", x, y, 0xFFFFFFFF, true);
        g.drawString(mc.font, "In Nether: 15 64 -43", x, y + h, 0xFFAAAAAA, true);
        return h * 2;
    }
}
