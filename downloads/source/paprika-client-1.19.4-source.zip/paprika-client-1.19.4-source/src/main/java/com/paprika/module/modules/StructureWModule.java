package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.ChatFormatting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class StructureWModule extends Module {
    private static final int CHUNKS_PER_TICK = 4;
    private static final double GROUP_DISTANCE = 64.0;

    private static final class ChunkFinds {
        AABB box;
        final Map<String, Integer> counts = new HashMap<>();
        BlockPos special;
    }

    private final Map<Long, ChunkFinds> finds = new HashMap<>();
    private final Set<Long> scanned = new HashSet<>();
    private final List<Vec3> announced = new ArrayList<>();
    private final List<BlockPos> announcedSpecial = new ArrayList<>();
    private List<BaseWModule.Group> groups = new ArrayList<>();
    private ClientLevel lastLevel;
    private int timer;

    protected StructureWModule(String name, String description) {
        super(name, description, Category.UTILITY);
    }

    protected abstract Map<Block, String> types();

    protected abstract String[] order();

    protected abstract String nice(String type, int count);

    protected abstract Set<String> sureTypes();

    protected abstract String specialType();

    protected Set<String> requiredTypes() { return Set.of(); }

    protected abstract String specialMessage(BlockPos pos);

    protected abstract int minBlocks();

    protected abstract String structureName();

    protected abstract boolean scanHere();

    public abstract int fillColor();

    public abstract int outlineColor();

    public abstract int labelColor();

    public List<BaseWModule.Group> espGroups() {
        return groups;
    }

    @Override
    protected void onDisable() {
        reset();
    }

    private long lastCenter = Long.MIN_VALUE;
    private int idle;

    private void reset() {
        finds.clear();
        scanned.clear();
        announced.clear();
        announcedSpecial.clear();
        groups = new ArrayList<>();
        timer = 0;
        idle = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null) {
            lastLevel = null;
            return;
        }
        if (mc.level != lastLevel) {
            reset();
            lastLevel = mc.level;
        }
        if (!scanHere()) return;

        int radius = mc.options.getEffectiveRenderDistance() + 1;
        ChunkPos center = mc.player.chunkPosition();
        long centerKey = ChunkPos.asLong(center.x, center.z);
        if (centerKey != lastCenter) { lastCenter = centerKey; idle = 0; }
        if (idle > 0) idle--;
        else {
            int done = 0;
            for (int r = 0; r <= radius && done < CHUNKS_PER_TICK; r++) {
                int side = r == 0 ? 1 : 8 * r;
                for (int i = 0; i < side && done < CHUNKS_PER_TICK; i++) {
                    int cx, cz;
                    if (r == 0) { cx = center.x; cz = center.z; }
                    else if (i < 2 * r) { cx = center.x - r + i; cz = center.z - r; }
                    else if (i < 4 * r) { cx = center.x + r; cz = center.z - r + (i - 2 * r); }
                    else if (i < 6 * r) { cx = center.x + r - (i - 4 * r); cz = center.z + r; }
                    else { cx = center.x - r; cz = center.z + r - (i - 6 * r); }
                    long key = ChunkPos.asLong(cx, cz);
                    if (scanned.contains(key)) continue;
                    LevelChunk chunk = mc.level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
                    if (chunk == null) continue;
                    scanned.add(key);
                    scanChunk(chunk, key);
                    done++;
                }
            }
            if (done == 0) idle = 20;
        }

        if (timer-- <= 0) {
            timer = 20;
            rebuildGroups();
        }
    }

    private void scanChunk(LevelChunk chunk, long key) {
        Map<Block, String> types = types();
        ChunkFinds f = null;
        LevelChunkSection[] sections = chunk.getSections();
        int baseX = chunk.getPos().getMinBlockX(), baseZ = chunk.getPos().getMinBlockZ();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection section = sections[i];
            if (section == null || section.hasOnlyAir()) continue;
            if (!section.maybeHas(s -> types.containsKey(s.getBlock()))) continue;
            int baseY = SectionPos.sectionToBlockCoord(chunk.getSectionYFromSectionIndex(i));
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState state = section.getBlockState(x, y, z);
                        String type = types.get(state.getBlock());
                        if (type == null) continue;
                        BlockPos pos = new BlockPos(baseX + x, baseY + y, baseZ + z);
                        if (f == null) f = new ChunkFinds();
                        AABB block = new AABB(pos);
                        f.box = f.box == null ? block : f.box.minmax(block);
                        f.counts.merge(type, 1, Integer::sum);
                        if (type.equals(specialType()) && f.special == null) f.special = pos;
                    }
                }
            }
        }
        if (f != null) finds.put(key, f);
    }

    private void rebuildGroups() {
        List<ChunkFinds> nodes = new ArrayList<>(finds.values());
        int n = nodes.size();
        int[] parent = new int[n];
        for (int i = 0; i < n; i++) parent[i] = i;
        double maxSq = GROUP_DISTANCE * GROUP_DISTANCE;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (nodes.get(i).box.getCenter().distanceToSqr(nodes.get(j).box.getCenter()) <= maxSq) union(parent, i, j);
            }
        }

        Map<Integer, AABB> boxes = new HashMap<>();
        Map<Integer, Map<String, Integer>> counts = new HashMap<>();
        Map<Integer, BlockPos> specials = new HashMap<>();
        for (int i = 0; i < n; i++) {
            int root = find(parent, i);
            ChunkFinds f = nodes.get(i);
            boxes.merge(root, f.box, AABB::minmax);
            Map<String, Integer> c = counts.computeIfAbsent(root, k -> new HashMap<>());
            f.counts.forEach((k, v) -> c.merge(k, v, Integer::sum));
            if (f.special != null) specials.putIfAbsent(root, f.special);
        }

        List<BaseWModule.Group> result = new ArrayList<>();
        for (Map.Entry<Integer, AABB> e : boxes.entrySet()) {
            Map<String, Integer> c = counts.get(e.getKey());
            int total = c.values().stream().mapToInt(Integer::intValue).sum();
            boolean sure = false;
            for (String t : sureTypes()) if (c.containsKey(t)) sure = true;
            if (!sure && total < minBlocks()) continue;
            boolean proven = requiredTypes().isEmpty();
            for (String t : requiredTypes()) if (c.containsKey(t)) proven = true;
            if (!proven) continue;

            List<String> parts = new ArrayList<>();
            for (String type : order()) {
                Integer count = c.get(type);
                if (count != null) parts.add(nice(type, count));
            }
            String what = String.join(", ", parts);
            AABB box = e.getValue().inflate(1.0);
            result.add(new BaseWModule.Group(box, structureName() + ": " + what));
            announce(box, what, specials.get(e.getKey()));
        }
        groups = result;
    }

    private void announce(AABB box, String what, BlockPos special) {
        boolean known = false;
        for (Vec3 v : announced) if (box.contains(v)) { known = true; break; }
        if (!known) {
            Vec3 c = box.getCenter();
            announced.add(c);
            say("Detected " + structureName().toLowerCase() + " at " + (int) c.x + ", " + (int) c.y + ", " + (int) c.z + " (" + what + ")");
        }
        if (special != null) {
            for (BlockPos p : announcedSpecial) if (box.contains(Vec3.atCenterOf(p))) return;
            announcedSpecial.add(special);
            say(specialMessage(special));
        }
    }

    private void say(String text) {
        mc.player.displayClientMessage(Component.literal("[" + getName() + "] ").withStyle(ChatFormatting.RED)
                .append(Component.literal(text).withStyle(ChatFormatting.WHITE)), false);
        mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.BEACON_ACTIVATE, 1.0F));
    }

    private static int find(int[] parent, int i) {
        while (parent[i] != i) {
            parent[i] = parent[parent[i]];
            i = parent[i];
        }
        return i;
    }

    private static void union(int[] parent, int a, int b) {
        parent[find(parent, a)] = find(parent, b);
    }
}
