package com.paprika.gui;

import com.paprika.Config;
import com.paprika.command.CrackedAccounts;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.List;

public class CrackedScreen extends Screen {
    private static final int ROW_W = 220, ROW_H = 20, WHITE = 0xFFFFFFFF, GRAY = 0xFF9A9A9A;

    private final Screen parent;
    private Button exitButton;
    private int scroll;

    public CrackedScreen(Screen parent) {
        super(Component.literal("Cracked accounts"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        addRenderableWidget(Button.builder(Component.literal("New account"),
                b -> minecraft.setScreen(new CrackedNewScreen(this))).bounds(cx - 110, 46, 108, 20).build());
        exitButton = addRenderableWidget(Button.builder(Component.literal("Exit cracked"), b -> {
            CrackedAccounts.exit();
            updateButtons();
        }).bounds(cx + 2, 46, 108, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(cx - 100, height - 28, 200, 20).build());
        updateButtons();
    }

    private void updateButtons() {
        if (exitButton != null) exitButton.active = CrackedAccounts.active() != null;
    }

    private int listTop() { return 76; }
    private int listBottom() { return height - 36; }
    private int rowX() { return width / 2 - ROW_W / 2; }
    private int rowY(int i) { return listTop() + i * (ROW_H + 2) - scroll; }
    private int trashX() { return rowX() + ROW_W - 18; }

    private int maxScroll() {
        int content = CrackedAccounts.all().size() * (ROW_H + 2);
        return Math.max(0, content - (listBottom() - listTop()));
    }

    @Override
    public void render(com.mojang.blaze3d.vertex.PoseStack paprika$ps, int mouseX, int mouseY, float partialTick) {
        GuiGraphics g = new GuiGraphics(paprika$ps);
        renderBackground(g.pose());
        scroll = Math.max(0, Math.min(scroll, maxScroll()));
        g.drawCenteredString(font, title, width / 2, 16, WHITE);
        String active = CrackedAccounts.active();
        g.drawCenteredString(font, active == null ? "Playing as your real account" : "Playing as " + active + " (cracked)",
                width / 2, 30, active == null ? GRAY : 0xFF55FF55);

        List<String> names = CrackedAccounts.all();
        if (names.isEmpty()) {
            g.drawCenteredString(font, "No accounts, create one!", width / 2, listTop() + 10, GRAY);
        }
        g.enableScissor(0, listTop(), width, listBottom());
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            int x = rowX(), y = rowY(i);
            if (y + ROW_H < listTop() || y > listBottom()) continue;
            boolean inUse = name.equals(active);
            boolean overRow = inList(mouseY) && inside(mouseX, mouseY, x, y, ROW_W, ROW_H);
            boolean overTrash = overRow && inside(mouseX, mouseY, trashX(), y + 4, 12, 12);
            int bg = inUse ? (overRow && !overTrash ? 0xC033D45A : 0xA033D45A) : (overRow && !overTrash ? 0x90000000 : 0x70000000);
            g.fill(x, y, x + ROW_W, y + ROW_H, bg);
            if (inUse) outline(g, x, y, ROW_W, ROW_H, 0xFF55FF55);
            g.drawString(font, name, x + 8, y + 6, WHITE, true);
            if (inUse) g.drawString(font, "in use", trashX() - 4 - font.width("in use"), y + 6, 0xFFCCFFCC, false);
            trash(g, trashX(), y + 4, overTrash);
        }
        g.disableScissor();
        super.render(g.pose(), mouseX, mouseY, partialTick);
    }

    private static void trash(GuiGraphics g, int x, int y, boolean hover) {
        int c = hover ? 0xFFFF5555 : 0xFFDD2222;
        g.fill(x + 4, y, x + 8, y + 1, c);
        g.fill(x + 1, y + 1, x + 11, y + 3, c);
        g.fill(x + 2, y + 3, x + 10, y + 4, c);
        g.fill(x + 2, y + 4, x + 3, y + 12, c);
        g.fill(x + 9, y + 4, x + 10, y + 12, c);
        g.fill(x + 2, y + 11, x + 10, y + 12, c);
        g.fill(x + 4, y + 5, x + 5, y + 10, c);
        g.fill(x + 7, y + 5, x + 8, y + 10, c);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        if (button != 0 || !inList(mouseY)) return false;
        List<String> names = CrackedAccounts.all();
        for (int i = 0; i < names.size(); i++) {
            int x = rowX(), y = rowY(i);
            if (!inside(mouseX, mouseY, x, y, ROW_W, ROW_H)) continue;
            String name = names.get(i);
            if (inside(mouseX, mouseY, trashX(), y + 4, 12, 12)) {
                CrackedAccounts.remove(name);
            } else if (!name.equals(CrackedAccounts.active())) {
                CrackedAccounts.use(name);
            }
            Config.save();
            updateButtons();
            click();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        scroll -= (int) (delta * (ROW_H + 2));
        return true;
    }
    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    private boolean inList(double mouseY) {
        return mouseY >= listTop() && mouseY < listBottom();
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private void click() {
        minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }
}
