package com.paprika.mixin;

import com.mojang.authlib.GameProfile;
import com.paprika.command.OrgSkins;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerInfo.class)
public abstract class PlayerInfoMixin {
    @Shadow public abstract GameProfile getProfile();

    @Unique
    private OrgSkins.Skin paprika$realSkin() {
        if (!OrgSkins.enabled) return null;
        GameProfile profile = getProfile();
        if (profile.getProperties().containsKey("textures")) return null;
        return OrgSkins.get(profile.getName());
    }

    @Inject(method = "getSkinLocation", at = @At("HEAD"), cancellable = true)
    private void paprika$skin(CallbackInfoReturnable<ResourceLocation> cir) {
        OrgSkins.Skin skin = paprika$realSkin();
        if (skin != null) cir.setReturnValue(skin.texture());
    }

    @Inject(method = "getModelName", at = @At("HEAD"), cancellable = true)
    private void paprika$model(CallbackInfoReturnable<String> cir) {
        OrgSkins.Skin skin = paprika$realSkin();
        if (skin != null) cir.setReturnValue(skin.slim() ? "slim" : "default");
    }
}
