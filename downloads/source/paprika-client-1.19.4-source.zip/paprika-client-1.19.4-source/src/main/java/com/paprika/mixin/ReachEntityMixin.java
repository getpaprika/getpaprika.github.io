package com.paprika.mixin;

import com.paprika.module.modules.ReachModule;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(GameRenderer.class)
public abstract class ReachEntityMixin {
    @ModifyConstant(method = "pick", constant = @Constant(doubleValue = 9.0), require = 0)
    private double paprika$entityReach(double original) {
        ReachModule r = ReachModule.active();
        return r == null ? original : r.entity.get() * r.entity.get();
    }
}
