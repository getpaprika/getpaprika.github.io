package com.paprika.network;

import com.paprika.module.modules.BlinkModule;
import com.paprika.module.modules.FakeLagModule;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundChatCommandPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.game.ServerboundPongPacket;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public final class PacketQueue {
    private record Held(Packet<?> packet, long time) {}

    private static final Deque<Held> LAGGED = new ArrayDeque<>();
    private static final List<Packet<?>> BLINKED = new ArrayList<>();
    private static boolean sending;

    private PacketQueue() {}

    public static synchronized boolean intercept(Connection connection, Packet<?> packet) {
        if (sending) return false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.getConnection() == null || connection != mc.getConnection().getConnection()) return false;
        if (BlinkModule.active() && !alwaysSend(packet)) {
            BLINKED.add(packet);
            return true;
        }
        if (FakeLagModule.active()) {
            LAGGED.add(new Held(packet, System.currentTimeMillis()));
            return true;
        }
        return false;
    }

    private static boolean alwaysSend(Packet<?> p) {
        return p instanceof ServerboundKeepAlivePacket || p instanceof ServerboundPongPacket
                || p instanceof ServerboundChatPacket || p instanceof ServerboundChatCommandPacket;
    }

    public static int blinkedCount() {
        return BLINKED.size();
    }

    public static synchronized void flushLag(long delayMs, boolean force) {
        long now = System.currentTimeMillis();
        while (!LAGGED.isEmpty() && (force || now - LAGGED.peekFirst().time() >= delayMs)) send(LAGGED.pollFirst().packet());
    }

    public static synchronized void releaseBlink() {
        for (Packet<?> p : BLINKED) send(p);
        BLINKED.clear();
    }

    public static synchronized void clear() {
        LAGGED.clear();
        BLINKED.clear();
    }

    private static void send(Packet<?> packet) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getConnection() == null) return;
        sending = true;
        try {
            mc.getConnection().getConnection().send(packet);
        } finally {
            sending = false;
        }
    }
}
