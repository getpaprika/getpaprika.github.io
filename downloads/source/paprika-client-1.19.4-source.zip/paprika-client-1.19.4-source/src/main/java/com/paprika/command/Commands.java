package com.paprika.command;

import com.paprika.Config;
import com.paprika.PaprikaClient;
import com.paprika.module.modules.BaritoneModule;
import com.paprika.module.modules.BoatFlyModule;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.util.Arrays;
import java.util.Locale;

public final class Commands {
    private Commands() {}

    public static boolean onChat(String message) {
        String msg = message.trim();
        if (!msg.startsWith("#")) return false;
        String[] a = msg.split("\\s+");
        String cmd = a[0].toLowerCase(Locale.ROOT);
        switch (cmd) {
            case "#b" -> {
                if (!BaritoneModule.onChat(msg)) {
                    Chat.invalid("Baritone", "Baritone is off - turn it on in the menu first");
                }
            }
            case "#c" -> config(a);
            case "#m" -> math(msg.substring(a[0].length()).trim());
            case "#a" -> area(a);
            case "#marker" -> marker(a);
            case "#friend" -> friend(a);
            case "#orgskin" -> {
                OrgSkins.enabled = !OrgSkins.enabled;
                if (OrgSkins.enabled) OrgSkins.retryMisses();
                Config.save();
                Chat.send("Paprika", "orgSkin is " + (OrgSkins.enabled ? "ON - real skins load in a few seconds" : "OFF"));
            }
            case "#help" -> help();
            default -> {
                if (net.minecraft.client.Minecraft.getInstance().player != null) {
                    net.minecraft.client.Minecraft.getInstance().player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                            "Whoopie! Sounds like you entered a wrong command! Dont worry, we got you covered, so you dont get exposed, so it didnt get sent.")
                            .withStyle(net.minecraft.ChatFormatting.YELLOW), false);
                }
            }
        }
        return true;
    }

    private static void config(String[] a) {
        if (a.length < 2) {
            Chat.invalid("Paprika", "#c waterMark (mod settings are now in the menu: the pencil next to a mod)");
            return;
        }
        switch (a[1].toLowerCase(Locale.ROOT)) {
            case "watermark" -> {
                PaprikaClient.watermark = !PaprikaClient.watermark;
                Config.save();
                Chat.send("Paprika", "waterMark is " + (PaprikaClient.watermark ? "ON" : "OFF"));
            }
            default -> Chat.invalid("Paprika", "unknown setting '" + a[1] + "' - mod settings are now in the menu (pencil next to a mod)");
        }
    }

    private static void math(String expression) {
        if (expression.isEmpty()) {
            Chat.invalid("Math", "#m [equation], e.g. #m 28+6x9");
            return;
        }
        try {
            Chat.send("Math", MathEval.format(MathEval.eval(expression)));
        } catch (MathEval.MathException e) {
            Chat.invalid("Math", e.getMessage());
        }
    }

    private static void area(String[] a) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (a.length == 2 && a[1].equalsIgnoreCase("deleteall")) {
            Areas.clear();
            Config.save();
            Chat.send("Area", "Deleted all areas");
            return;
        }

        BlockPos me = mc.player.blockPosition();
        String[] c = Arrays.copyOfRange(a, 1, a.length);
        BlockPos start, end;
        try {
            if (c.length == 6) {
                start = parse(c, 0, me);
                end = parse(c, 3, me);
            } else if (c.length == 4 && c[0].equals("~")) {
                start = me;
                end = parse(c, 1, me);
            } else if (c.length == 3) {
                start = me;
                end = parse(c, 0, me);
            } else {
                Chat.invalid("Area", "#a x1 y1 z1 x2 y2 z2  or  #a ~ x y z");
                return;
            }
        } catch (NumberFormatException e) {
            Chat.invalid("Area", "coordinates must be numbers or ~");
            return;
        }

        Areas.Area area = Areas.Area.of(Areas.currentDim(), start, end);
        Areas.add(area);
        Config.save();
        Chat.send("Area", "Created area from " + area.minX() + " " + area.minY() + " " + area.minZ()
                + " to " + area.maxX() + " " + area.maxY() + " " + area.maxZ()
                + " (" + (area.maxX() - area.minX() + 1) + "x" + (area.maxY() - area.minY() + 1)
                + "x" + (area.maxZ() - area.minZ() + 1) + ")");
    }

    private static BlockPos parse(String[] c, int i, BlockPos me) {
        return new BlockPos(coord(c[i], me.getX()), coord(c[i + 1], me.getY()), coord(c[i + 2], me.getZ()));
    }

    private static int coord(String s, int mine) {
        if (s.startsWith("~")) {
            String rest = s.substring(1);
            return rest.isEmpty() ? mine : mine + (int) Math.floor(Double.parseDouble(rest));
        }
        return (int) Math.floor(Double.parseDouble(s));
    }

    private static void marker(String[] a) {
        Chat.send("Marker", "Markers have their own menu now - press M (you can change the key in Controls)");
    }

    private static void friend(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "add" -> {
                if (a.length != 3) {
                    Chat.invalid("Friends", "#friend add [name]");
                } else if (Friends.add(a[2])) {
                    Config.save();
                    Chat.send("Friends", "Added " + a[2] + " to your friends");
                } else {
                    Chat.invalid("Friends", a[2] + " is already your friend");
                }
            }
            case "remove" -> {
                if (a.length != 3) {
                    Chat.invalid("Friends", "#friend remove [name]");
                } else if (Friends.remove(a[2])) {
                    Config.save();
                    Chat.send("Friends", "Removed " + a[2] + " from your friends");
                } else {
                    Chat.invalid("Friends", a[2] + " isn't on your friends list");
                }
            }
            case "list" -> {
                java.util.List<String> all = Friends.all();
                Chat.send("Friends", all.isEmpty() ? "You have no friends added yet" : all.size() + ": " + String.join(", ", all));
            }
            default -> Chat.invalid("Friends", "#friend add [name], #friend remove [name] or #friend list");
        }
    }

    private static void help() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Chat.send("Paprika", "Commands:");
        line("#c waterMark", "toggles the red dye and watermark in the top left");
        line("#m [equation]", "does math, supports x + - / and ^ or @ for powers");
        line("#a [coordinates]", "draws an area: #a x1 y1 z1 x2 y2 z2, or #a ~ x y z to start where you stand");
        line("#a deleteall", "deletes all areas");
        line("#b minea", "Baritone mines everything in the areas (Baritone must be on)");
        line("#b fillawith [block]", "Baritone fills the areas with a block from your inventory");
        line("#b gotomarker [name]", "Baritone walks to one of your markers");
        line("#friend add [name]", "adds a friend (kill auras, CrystalAura, BowAimbot, AutoLogout and PlayerW ignore them)");
        line("#friend remove [name]", "removes a friend");
        line("#friend list", "shows your friends");
        line("#orgskin", "on cracked servers, shows players' real skins (only for you)");
        line("M key", "opens the marker menu (create, color, hide and delete markers)");
        line("#help", "shows this list");
    }

    private static void line(String cmd, String what) {
        Minecraft.getInstance().player.displayClientMessage(Component.literal(cmd).withStyle(ChatFormatting.AQUA)
                .append(Component.literal(" - " + what).withStyle(ChatFormatting.WHITE)), false);
    }
}
