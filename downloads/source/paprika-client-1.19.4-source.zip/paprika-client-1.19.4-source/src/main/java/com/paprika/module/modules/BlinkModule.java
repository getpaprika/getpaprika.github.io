package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.network.PacketQueue;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.entity.Entity;

public class BlinkModule extends Module {
    public static final int CLONE_ID = -1_337_420;

    private RemotePlayer clone;
    private ClientLevel cloneLevel;

    public BlinkModule() {
        super("Blink", "Server thinks you stand still while you move, a clone shows where it thinks you are", Category.MOVEMENT);
    }

    @Override
    public boolean shouldSave() {
        return false;
    }

    public static boolean active() {
        return ModuleManager.isOn(BlinkModule.class) && mc.player != null;
    }

    public static boolean isClone(Entity e) {
        return e != null && e.getId() == CLONE_ID;
    }

    @Override
    protected void onEnable() {
        spawnClone();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.getConnection() == null) {
            PacketQueue.clear();
            clone = null;
            return;
        }
        if (cloneLevel != mc.level) {
            PacketQueue.clear();
            spawnClone();
        }
    }

    @Override
    protected void onDisable() {
        PacketQueue.releaseBlink();
        removeClone();
    }

    private void spawnClone() {
        removeClone();
        if (mc.player == null || mc.level == null) return;
        clone = new RemotePlayer(mc.level, mc.player.getGameProfile());
        clone.setId(CLONE_ID);
        clone.copyPosition(mc.player);
        clone.yHeadRot = mc.player.yHeadRot;
        clone.yBodyRot = mc.player.yBodyRot;
        clone.setPose(mc.player.getPose());
        clone.setShiftKeyDown(mc.player.isShiftKeyDown());
        clone.getInventory().replaceWith(mc.player.getInventory());
        mc.level.addPlayer(CLONE_ID, clone);
        cloneLevel = mc.level;
    }

    private void removeClone() {
        if (clone != null && cloneLevel != null && cloneLevel == mc.level) {
            cloneLevel.removeEntity(CLONE_ID, Entity.RemovalReason.DISCARDED);
        }
        clone = null;
        cloneLevel = null;
    }
}
