package com.paprika.gui;

import com.paprika.Config;
import com.paprika.command.CrackedAccounts;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class CrackedNewScreen extends Screen {
    private final Screen parent;
    private EditBox name;
    private String error = "";

    public CrackedNewScreen(Screen parent) {
        super(Component.literal("New account"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2, cy = height / 2;
        String old = name == null ? "" : name.getValue();
        name = new EditBox(font, cx - 100, cy - 20, 200, 20, Component.literal("Account name"));
        name.setMaxLength(16);
        name.setValue(old);
        name.setHint(Component.literal("Account name").withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
        name.setResponder(t -> error = "");
        addRenderableWidget(name);
        setInitialFocus(name);
        addRenderableWidget(Button.builder(Component.literal("Create"), b -> create()).bounds(cx - 100, cy + 10, 98, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose()).bounds(cx + 2, cy + 10, 98, 20).build());
    }

    private void create() {
        String n = name.getValue().trim();
        if (!CrackedAccounts.validName(n)) {
            error = "3-16 letters, numbers or _";
            return;
        }
        if (!CrackedAccounts.add(n)) {
            error = "You already have that account";
            return;
        }
        Config.save();
        onClose();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            create();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(com.mojang.blaze3d.vertex.PoseStack paprika$ps, int mouseX, int mouseY, float partialTick) {
        GuiGraphics g = new GuiGraphics(paprika$ps);
        renderBackground(g.pose());
        g.drawCenteredString(font, title, width / 2, height / 2 - 50, 0xFFFFFFFF);
        g.drawCenteredString(font, "Name of the account:", width / 2, height / 2 - 34, 0xFFAAAAAA);
        if (!error.isEmpty()) g.drawCenteredString(font, error, width / 2, height / 2 + 36, 0xFFFF5555);
        super.render(g.pose(), mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
