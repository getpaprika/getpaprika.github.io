package com.paprika.module.modules;

import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public class ElytraFlyModule extends Module {
    private static boolean gliding;
    private boolean jumpWasDown;
    private int lastJumpTick = -100;
    private int ticks;

    public ElytraFlyModule() {
        super("ElytraFly", "Double jump to glide like with an elytra, hold Ctrl to boost", Category.MOVEMENT);
    }

    public static boolean isGliding() {
        return gliding && ModuleManager.isOn(ElytraFlyModule.class);
    }

    @Override
    protected void onDisable() {
        gliding = false;
    }

    @Override
    public void onTick() {
        ticks++;
        if (mc.player == null) {
            gliding = false;
            return;
        }
        if (mc.player.isOnGround() || mc.player.isInWater() || mc.player.isInLava() || mc.player.isPassenger()
                || mc.player.getAbilities().flying) {
            gliding = false;
        }

        boolean jump = mc.options.keyJump.isDown() && mc.screen == null;
        if (jump && !jumpWasDown) {
            if (ticks - lastJumpTick <= 7 && !mc.player.isOnGround() && !mc.player.isInWater()) {
                gliding = !gliding;
                lastJumpTick = -100;
            } else {
                lastJumpTick = ticks;
            }
        }
        jumpWasDown = jump;
    }

    public static Vec3 glide(Vec3 vel, Vec3 look, float pitchDeg, boolean boost) {
        double gravity = 0.08;
        float pitch = pitchDeg * Mth.DEG_TO_RAD;
        double hLook = Math.sqrt(look.x * look.x + look.z * look.z);
        double hVel = vel.horizontalDistance();
        double lookLen = look.length();
        double cos = Math.cos(pitch);
        cos = cos * cos * Math.min(1.0, lookLen / 0.4);

        vel = vel.add(0.0, gravity * (-1.0 + cos * 0.75), 0.0);
        if (vel.y < 0.0 && hLook > 0.0) {
            double d = vel.y * -0.1 * cos;
            vel = vel.add(look.x * d / hLook, d, look.z * d / hLook);
        }
        if (pitch < 0.0F && hLook > 0.0) {
            double d = hVel * -Math.sin(pitch) * 0.04;
            vel = vel.add(-look.x * d / hLook, d * 3.2, -look.z * d / hLook);
        }
        if (hLook > 0.0) {
            vel = vel.add((look.x / hLook * hVel - vel.x) * 0.1, 0.0, (look.z / hLook * hVel - vel.z) * 0.1);
        }
        if (boost) {
            vel = vel.add(look.x * 0.1 + (look.x * 1.5 - vel.x) * 0.5,
                    look.y * 0.1 + (look.y * 1.5 - vel.y) * 0.5,
                    look.z * 0.1 + (look.z * 1.5 - vel.z) * 0.5);
        }
        return vel.multiply(0.99, 0.98, 0.99);
    }
}
