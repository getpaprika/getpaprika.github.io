package com.paprika.mixin;

import com.paprika.gui.MenuBackground;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class MenuFrameMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void paprika$newFrame(float partialTicks, long nanoTime, boolean renderLevel, CallbackInfo ci) {
        MenuBackground.newFrame();
    }
}
