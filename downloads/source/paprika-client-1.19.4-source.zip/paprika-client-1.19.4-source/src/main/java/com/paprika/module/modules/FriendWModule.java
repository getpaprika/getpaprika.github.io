package com.paprika.module.modules;

import com.paprika.command.Friends;
import com.paprika.module.Category;
import com.paprika.module.Module;
import com.paprika.module.ModuleManager;
import com.paprika.module.setting.NumberSetting;
import com.paprika.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class FriendWModule extends Module {
    public final NumberSetting range = number("Range", "How close a friend has to be", 200, 16, 512, 8, " blocks");
    private static final int CYAN = 0xFF55FFFF;

    private final Set<UUID> inRange = new HashSet<>();
    private final List<Player> nearby = new ArrayList<>();

    public FriendWModule() {
        super("FriendW", "Tells you when a friend is near (cyan, under PlayerW)", Category.UTILITY);
    }

    @Override
    protected void onDisable() {
        inRange.clear();
        nearby.clear();
    }

    @Override
    public void onTick() {
        nearby.clear();
        if (mc.player == null || mc.level == null) {
            inRange.clear();
            return;
        }
        Set<UUID> now = new HashSet<>();
        boolean newFriend = false;
        for (Player p : mc.level.players()) {
            if (com.paprika.module.modules.BlinkModule.isClone(p)) continue;
            if (p == mc.player || p.isSpectator() || !Friends.is(p)) continue;
            if (p.distanceTo(mc.player) > range.get()) continue;
            now.add(p.getUUID());
            nearby.add(p);
            if (!inRange.contains(p.getUUID())) newFriend = true;
        }
        if (newFriend) mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.VILLAGER_YES, 1.0F));
        inRange.clear();
        inRange.addAll(now);
        nearby.sort(Comparator.comparingDouble(p -> p.distanceTo(mc.player)));
    }

    @Override
    public int onRender(GuiGraphics graphics, int x, int y) {
        if (mc.player == null || nearby.isEmpty()) return 0;
        int centerX = mc.getWindow().getGuiScaledWidth() / 2;
        PlayerWModule playerW = ModuleManager.get(PlayerWModule.class);
        int lineY = 4 + (playerW == null ? 0 : playerW.topLines()) * (mc.font.lineHeight + 1);
        for (Player p : nearby) {
            if (!p.isAlive()) continue;
            String text = "Friend " + p.getName().getString() + " is near! "
                    + String.format(Locale.ROOT, "%.0f", p.distanceTo(mc.player)) + "m";
            graphics.drawCenteredString(mc.font, text, centerX, lineY, CYAN);
            lineY += mc.font.lineHeight + 1;
        }
        return 0;
    }

    @Override
    public int onRenderPreview(GuiGraphics graphics, int x, int y) {
        if (mc.player != null && !nearby.isEmpty()) return onRender(graphics, x, y);
        int centerX = mc.getWindow().getGuiScaledWidth() / 2;
        graphics.drawCenteredString(mc.font, "Friend Steve is near! 24m", centerX, 4 + 2 * (mc.font.lineHeight + 1), CYAN);
        return 0;
    }
}
