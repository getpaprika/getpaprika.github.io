package com.paprika.module.modules;

import com.paprika.module.setting.NumberSetting;
import com.paprika.module.Category;
import com.paprika.module.Module;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.phys.Vec3;

public class BowAimbotModule extends Module {
    public final NumberSetting maxDistance = number("Range", "How far away targets can be", 100, 10, 200, 5, " blocks");
    public final NumberSetting maxAngle = number("Aim angle", "How far from your crosshair a target can be", 60, 10, 180, 5, "\u00b0");

    public BowAimbotModule() {
        super("BowAimbot", "Aims your bow at players and hostile mobs", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.level == null || mc.screen != null) return;

        ItemStack stack = mc.player.getMainHandItem();
        double speed;
        if (stack.getItem() instanceof BowItem && mc.player.isUsingItem()) {
            speed = Math.max(BowItem.getPowerForTime(mc.player.getTicksUsingItem()), 0.1F) * 3.0;
        } else if (stack.getItem() instanceof CrossbowItem && CrossbowItem.isCharged(stack)) {
            speed = 3.15;
        } else if (stack.getItem() instanceof TridentItem && mc.player.isUsingItem()) {
            speed = 2.5;
        } else {
            return;
        }

        LivingEntity target = findTarget();
        if (target == null) return;

        Vec3 eye = mc.player.getEyePosition();

        Vec3 aim = target.getBoundingBox().getCenter();
        Vec3 motion = new Vec3(target.getX() - target.xo, target.getY() - target.yo, target.getZ() - target.zo);
        double flightTicks = eye.distanceTo(aim) / speed;
        aim = aim.add(motion.x * flightTicks, target.isOnGround() ? 0 : motion.y * flightTicks, motion.z * flightTicks);

        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90.0F;
        Float pitch = solvePitch(speed, horizontal, dy);
        if (pitch == null) return;

        mc.player.setYRot(yaw);
        mc.player.setYHeadRot(yaw);
        mc.player.setXRot(pitch);
    }

    private static Float solvePitch(double speed, double horizontal, double height) {
        Float bestPitch = null;
        double bestError = 1.5;
        for (float pitch = 60.0F; pitch >= -60.0F; pitch -= 0.25F) {
            double rad = Math.toRadians(-pitch);
            double vx = Math.cos(rad) * speed, vy = Math.sin(rad) * speed;
            double x = 0, y = 0;
            for (int t = 0; t < 200; t++) {
                double nx = x + vx, ny = y + vy;
                if (nx >= horizontal) {
                    double f = (horizontal - x) / (nx - x);
                    double yAt = y + (ny - y) * f;
                    double error = Math.abs(yAt - height);
                    if (error < bestError) {
                        bestError = error;
                        bestPitch = pitch;
                    } else if (bestPitch != null && error > bestError + 1.0) {
                        return bestPitch;
                    }
                    break;
                }
                x = nx;
                y = ny;
                vx *= 0.99;
                vy = vy * 0.99 - 0.05;
                if (y < height - 60) break;
            }
            if (bestPitch != null && bestError < 0.05) break;
        }
        return bestPitch;
    }

    private LivingEntity findTarget() {
        Vec3 eye = mc.player.getEyePosition();
        Vec3 look = mc.player.getLookAngle();
        LivingEntity best = null;
        double bestAngle = maxAngle.get();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity living) || e == mc.player || BlinkModule.isClone(e) || !living.isAlive()) continue;
            if (living instanceof Player p) {
                if (p.isCreative() || p.isSpectator() || com.paprika.command.Friends.is(p)) continue;
            } else if (!(living instanceof Enemy)) {
                continue;
            }
            Vec3 to = living.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > maxDistance.get() || dist < 1.0) continue;
            if (!mc.player.hasLineOfSight(living)) continue;
            double angle = Math.toDegrees(Math.acos(Mth.clamp(to.normalize().dot(look), -1.0, 1.0)));
            if (angle < bestAngle) {
                bestAngle = angle;
                best = living;
            }
        }
        return best;
    }
}
