# Paprika Client (Fabric 1.20 / 1.20.1)

## Build the jar
1. Install **JDK 21** (e.g. from adoptium.net).
2. Open a terminal in this folder and run:
   - Windows: `gradlew.bat build`
   - Mac/Linux: `./gradlew build`
3. The jar is in `build/libs/paprika-client-1.0.0.jar` (ignore the `-sources` one if it appears).
4. Put it in your `.minecraft/mods` folder together with **Fabric API** for your Minecraft version.

## In game
- Top left: red dye + "Paprika Client" in red.
- Press **DELETE** to open/close the menu (rebindable in Controls).
- Blue = off, green = on. Hover a mod to see what it does.

## Adding a mod
1. Make a class in `src/main/java/com/paprika/module/modules/` that extends `Module`.
2. Register it in `ModuleManager.init()`.
3. New tab? Add it to `Category.java`.
